package com.example.studyvault.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Renders the Study Vault diagonal watermark both:
 * 1) As a tiled screen overlay on top of the protected viewer (WatermarkOverlayView), and
 * 2) Baked directly into each rendered PDF page Bitmap (stampBitmapWithWatermark),
 * matching the behavior of view-manuscript.php + assets/js/viewer.js.
 */
public class WatermarkOverlayView extends View {

    private final List<String> watermarkLines = new ArrayList<>();
    private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public WatermarkOverlayView(Context context) {
        super(context);
        init();
    }

    public WatermarkOverlayView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public WatermarkOverlayView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setClickable(false);
        setFocusable(false);

        float density = getResources().getDisplayMetrics().density;

        titlePaint.setColor(Color.argb(32, 23, 73, 47));
        titlePaint.setTextSize(12f * density);
        titlePaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        titlePaint.setTextAlign(Paint.Align.CENTER);

        linePaint.setColor(Color.argb(28, 23, 73, 47));
        linePaint.setTextSize(10.5f * density);
        linePaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        linePaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setWatermarkLines(List<String> lines) {
        watermarkLines.clear();
        if (lines != null) {
            watermarkLines.addAll(lines);
        }
        invalidate();
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        if (watermarkLines.isEmpty()) return;

        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float density = getResources().getDisplayMetrics().density;
        float lineHeight = 15f * density;
        float tileW = 240f * density;
        float tileH = lineHeight * (watermarkLines.size() + 3);

        canvas.save();
        canvas.translate(w / 2f, h / 2f);
        canvas.rotate(-28f);

        float span = (float) Math.sqrt((double) w * w + (double) h * h);
        int row = 0;
        for (float y = -span / 2f; y < span / 2f; y += tileH, row++) {
            float offsetX = (row % 2 != 0) ? (tileW / 2f) : 0f;
            for (float x = -span / 2f + offsetX; x < span / 2f; x += tileW) {
                for (int i = 0; i < watermarkLines.size(); i++) {
                    String text = watermarkLines.get(i);
                    Paint p = (i == 0) ? titlePaint : linePaint;
                    canvas.drawText(text, x, y + i * lineHeight, p);
                }
            }
        }
        canvas.restore();
    }

    /**
     * Stamps the personalized watermark directly into a rendered PDF page Bitmap
     * (mirrors stampCanvas(canvas) in study-vault/assets/js/viewer.js).
     */
    public static void stampBitmapWithWatermark(Bitmap bitmap, List<String> lines) {
        if (bitmap == null || !bitmap.isMutable() || lines == null || lines.isEmpty()) {
            return;
        }

        Canvas canvas = new Canvas(bitmap);
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();

        float textSize = Math.max(14f, w / 38f);
        float lineHeight = textSize * 1.38f;
        float tileW = textSize * 19f;
        float tileH = lineHeight * (lines.size() + 3);

        Paint boldPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        boldPaint.setColor(Color.argb(30, 23, 73, 47)); // #17492F @ ~12% alpha
        boldPaint.setTextSize(textSize);
        boldPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        boldPaint.setTextAlign(Paint.Align.CENTER);

        Paint normalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        normalPaint.setColor(Color.argb(28, 23, 73, 47));
        normalPaint.setTextSize(textSize * 0.92f);
        normalPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        normalPaint.setTextAlign(Paint.Align.CENTER);

        canvas.save();
        canvas.translate(w / 2f, h / 2f);
        canvas.rotate(-30f);

        float span = (float) Math.sqrt((double) w * w + (double) h * h);
        int row = 0;
        for (float y = -span / 2f; y < span / 2f; y += tileH, row++) {
            float offsetX = (row % 2 != 0) ? (tileW / 2f) : 0f;
            for (float x = -span / 2f + offsetX; x < span / 2f; x += tileW) {
                for (int i = 0; i < lines.size(); i++) {
                    String ln = lines.get(i);
                    if (ln != null) {
                        canvas.drawText(ln, x, y + i * lineHeight, i == 0 ? boldPaint : normalPaint);
                    }
                }
            }
        }
        canvas.restore();
    }
}
