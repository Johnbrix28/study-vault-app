package com.example.studyvault.api;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    // ⚠️ Emulator: 10.0.2.2 = your PC's localhost
    // ⚠️ Real device: use your PC's LAN IP e.g. http://192.168.1.10/study-vault/api/
    // private static final String BASE_URL = "http://10.0.2.2/study-vault/api/";

    //private static final String BASE_URL = "http://192.168.100.197/study-vault/api/";

    private static final String BASE_URL = "http://192.168.100.197/study-vault/api/";
    private static Retrofit retrofit;

    public static Retrofit getRetrofit() {
        if (retrofit == null) {
            HttpLoggingInterceptor log = new HttpLoggingInterceptor();
            log.setLevel(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(log)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

    public static ApiService getService() {
        return getRetrofit().create(ApiService.class);
    }
}