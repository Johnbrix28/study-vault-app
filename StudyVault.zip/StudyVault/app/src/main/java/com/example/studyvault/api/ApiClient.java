package com.example.studyvault.api;

import android.content.Context;

import androidx.annotation.NonNull;

import com.example.studyvault.utils.SessionManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Retrofit & OkHttp configuration for Study Vault.
 * - Emulator default: http://10.0.2.2/study-vault/api/
 * - Physical phone LAN default: http://192.168.100.197/study-vault/api/ (configurable in UI)
 * - Attaches revocable Bearer token and maintains session cookies.
 * - Never logs passwords, verification codes, or authentication tokens.
 */
public class ApiClient {

    private static Retrofit retrofit;
    private static String currentBaseUrl;
    private static Context appContext;

    private static final Map<String, List<Cookie>> cookieStore = new HashMap<>();

    public static synchronized void init(Context context) {
        if (context != null) {
            appContext = context.getApplicationContext();
        }
    }

    public static synchronized void resetClient() {
        retrofit = null;
        currentBaseUrl = null;
    }

    public static synchronized void clearCookies() {
        cookieStore.clear();
    }

    public static synchronized Retrofit getRetrofit(Context context) {
        if (context != null && appContext == null) {
            appContext = context.getApplicationContext();
        }

        String resolvedBaseUrl = SessionManager.isRunningOnEmulator()
                ? SessionManager.EMULATOR_BASE_URL
                : SessionManager.DEFAULT_LAN_BASE_URL;

        if (appContext != null) {
            SessionManager sm = new SessionManager(appContext);
            resolvedBaseUrl = sm.getBaseUrl();
        }

        if (retrofit == null || !resolvedBaseUrl.equals(currentBaseUrl)) {
            currentBaseUrl = resolvedBaseUrl;

            Interceptor authInterceptor = chain -> {
                Request original = chain.request();
                Request.Builder builder = original.newBuilder()
                        .header("Accept", "application/json");

                if (appContext != null) {
                    SessionManager sm = new SessionManager(appContext);
                    String token = sm.getToken();
                    if (token != null && !token.isEmpty()) {
                        builder.header("Authorization", "Bearer " + token);
                        builder.header("X-Auth-Token", token);
                    }
                }
                return chain.proceed(builder.build());
            };

            CookieJar sessionCookieJar = new CookieJar() {
                @Override
                public synchronized void saveFromResponse(@NonNull HttpUrl url, @NonNull List<Cookie> cookies) {
                    List<Cookie> hostCookies = cookieStore.get(url.host());
                    if (hostCookies == null) {
                        hostCookies = new ArrayList<>();
                    }
                    for (Cookie incoming : cookies) {
                        hostCookies.removeIf(existing -> existing.name().equals(incoming.name()));
                        hostCookies.add(incoming);
                    }
                    cookieStore.put(url.host(), hostCookies);
                }

                @NonNull
                @Override
                public synchronized List<Cookie> loadForRequest(@NonNull HttpUrl url) {
                    List<Cookie> cookies = cookieStore.get(url.host());
                    return cookies != null ? new ArrayList<>(cookies) : Collections.emptyList();
                }
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .cookieJar(sessionCookieJar)
                    .addInterceptor(authInterceptor)
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(25, TimeUnit.SECONDS)
                    .writeTimeout(20, TimeUnit.SECONDS)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(currentBaseUrl)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

    public static ApiService getService(Context context) {
        return getRetrofit(context).create(ApiService.class);
    }

    public static ApiService getService() {
        return getRetrofit(appContext).create(ApiService.class);
    }
}
