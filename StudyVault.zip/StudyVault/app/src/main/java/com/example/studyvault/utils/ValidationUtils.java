package com.example.studyvault.utils;

import java.util.regex.Pattern;

/**
 * Reusable validation helpers matching Study Vault backend rules
 * (includes/verification.php and includes/functions.php).
 */
public final class ValidationUtils {

    private static final Pattern STUDENT_ID_PATTERN = Pattern.compile("^[A-Za-z0-9._-]{3,50}$");
    private static final Pattern CODE_PATTERN = Pattern.compile("^\\d{6}$");
    private static final Pattern HAS_LETTER = Pattern.compile("[A-Za-z]");
    private static final Pattern HAS_DIGIT = Pattern.compile("\\d");

    private ValidationUtils() {}

    public static String normalizeStudentId(String input) {
        if (input == null) return "";
        return input.replaceAll("\\s+", "").trim();
    }

    public static boolean isValidStudentId(String input) {
        String cleaned = normalizeStudentId(input);
        return STUDENT_ID_PATTERN.matcher(cleaned).matches();
    }

    public static boolean isValidVerificationCode(String input) {
        if (input == null) return false;
        return CODE_PATTERN.matcher(input.trim()).matches();
    }

    /**
     * Returns null when valid, or a user-facing error message matching the backend.
     */
    public static String validatePassword(String password, String confirmPassword) {
        if (password == null || password.length() < 8) {
            return "Password must be at least 8 characters.";
        }
        if (!HAS_LETTER.matcher(password).find() || !HAS_DIGIT.matcher(password).find()) {
            return "Password must contain at least one letter and one number.";
        }
        if (confirmPassword != null && !password.equals(confirmPassword)) {
            return "Passwords do not match.";
        }
        return null;
    }
}
