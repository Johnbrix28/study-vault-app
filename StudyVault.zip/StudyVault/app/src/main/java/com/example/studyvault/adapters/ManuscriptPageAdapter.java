package com.example.studyvault.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.R;
import com.example.studyvault.utils.WatermarkOverlayView;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Renders PDF pages using Android's native PdfRenderer on a background thread and stamps
 * each page bitmap with the authorized student's Study Vault watermark.
 */
public class ManuscriptPageAdapter extends RecyclerView.Adapter<ManuscriptPageAdapter.ViewHolder> {

    private final Context context;
    private final PdfRenderer pdfRenderer;
    private final Object rendererLock = new Object();
    private final List<String> watermarkLines;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> bitmapCache;

    private float zoomScale = 1.0f;

    public ManuscriptPageAdapter(Context context, PdfRenderer pdfRenderer, List<String> watermarkLines) {
        this.context = context;
        this.pdfRenderer = pdfRenderer;
        this.watermarkLines = watermarkLines;

        int maxMemoryKb = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheSizeKb = Math.max(4096, maxMemoryKb / 8);
        this.bitmapCache = new LruCache<String, Bitmap>(cacheSizeKb) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };
    }

    public void setZoomScale(float scale) {
        float clamped = Math.max(0.6f, Math.min(2.2f, scale));
        if (Math.abs(clamped - this.zoomScale) > 0.04f) {
            this.zoomScale = clamped;
            bitmapCache.evictAll();
            notifyDataSetChanged();
        }
    }

    public float getZoomScale() {
        return zoomScale;
    }

    public void shutdown() {
        executor.shutdownNow();
        bitmapCache.evictAll();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_manuscript_page, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        int totalPages = getItemCount();
        holder.boundPageIndex = position;
        holder.tvPageLabel.setText(String.format(
                Locale.US, "Page %d of %d  ·  Protected Watermarked Copy", position + 1, totalPages));

        String cacheKey = position + "@" + String.format(Locale.US, "%.2f", zoomScale);
        Bitmap cached = bitmapCache.get(cacheKey);
        if (cached != null && !cached.isRecycled()) {
            holder.progressPage.setVisibility(View.GONE);
            holder.ivPdfPage.setImageBitmap(cached);
            return;
        }

        holder.ivPdfPage.setImageBitmap(null);
        holder.progressPage.setVisibility(View.VISIBLE);

        final int targetPage = position;
        final float targetScale = zoomScale;
        final int screenW = context.getResources().getDisplayMetrics().widthPixels;

        executor.execute(() -> {
            Bitmap rendered = null;
            synchronized (rendererLock) {
                try {
                    if (pdfRenderer != null && targetPage >= 0 && targetPage < pdfRenderer.getPageCount()) {
                        PdfRenderer.Page page = pdfRenderer.openPage(targetPage);
                        int baseWidth = Math.max(720, Math.min(1600, (int) (screenW * targetScale)));
                        int height = Math.max(1, (int) ((float) baseWidth / page.getWidth() * page.getHeight()));

                        rendered = Bitmap.createBitmap(baseWidth, height, Bitmap.Config.ARGB_8888);
                        rendered.eraseColor(Color.WHITE);
                        page.render(rendered, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        page.close();

                        WatermarkOverlayView.stampBitmapWithWatermark(rendered, watermarkLines);
                        bitmapCache.put(cacheKey, rendered);
                    }
                } catch (Exception ignored) {
                }
            }

            final Bitmap finalBitmap = rendered;
            mainHandler.post(() -> {
                if (holder.boundPageIndex == targetPage) {
                    holder.progressPage.setVisibility(View.GONE);
                    if (finalBitmap != null) {
                        holder.ivPdfPage.setImageBitmap(finalBitmap);
                    }
                }
            });
        });
    }

    @Override
    public int getItemCount() {
        synchronized (rendererLock) {
            try {
                return pdfRenderer != null ? pdfRenderer.getPageCount() : 0;
            } catch (Exception e) {
                return 0;
            }
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivPdfPage;
        final ProgressBar progressPage;
        final TextView tvPageLabel;
        int boundPageIndex = -1;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPdfPage = itemView.findViewById(R.id.ivPdfPage);
            progressPage = itemView.findViewById(R.id.progressPage);
            tvPageLabel = itemView.findViewById(R.id.tvPageNumberLabel);
        }
    }
}
