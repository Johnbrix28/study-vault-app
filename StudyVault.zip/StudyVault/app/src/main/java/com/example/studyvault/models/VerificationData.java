package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class VerificationData implements Serializable {
    @SerializedName("step")
    public int step;

    @SerializedName("verification_token")
    public String verificationToken;

    @SerializedName("masked_email")
    public String maskedEmail;

    @SerializedName("resend_wait")
    public int resendWait;

    @SerializedName("ttl_minutes")
    public int ttlMinutes = 10;

    @SerializedName("student_preview")
    public StudentPreview studentPreview;

    @SerializedName("student_number")
    public String studentNumber;

    @SerializedName("full_name")
    public String fullName;

    @SerializedName("account_status")
    public String accountStatus;

    @SerializedName("requires_approval")
    public boolean requiresApproval;

    public static class StudentPreview implements Serializable {
        @SerializedName("student_id")
        public String studentId;

        @SerializedName("full_name")
        public String fullName;

        @SerializedName("masked_email")
        public String maskedEmail;

        @SerializedName("program")
        public String program;

        @SerializedName("section")
        public String section;

        @SerializedName("user_type")
        public String userType;

        @SerializedName("user_type_label")
        public String userTypeLabel;

        @SerializedName("graduation_year")
        public Integer graduationYear;
    }
}
