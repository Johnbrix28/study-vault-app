package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class ManuscriptMeta implements Serializable {
    @SerializedName("research_id")
    public int researchId;

    @SerializedName("title")
    public String title;

    @SerializedName("year")
    public int year;

    @SerializedName("category_name")
    public String categoryName;

    @SerializedName("authorized_user")
    public String authorizedUser;

    @SerializedName("student_number")
    public String studentNumber;

    @SerializedName("timestamp")
    public String timestamp;

    @SerializedName("watermark_lines")
    public List<String> watermarkLines;

    @SerializedName("subscription_plan")
    public String subscriptionPlan;

    @SerializedName("subscription_expires_at")
    public String subscriptionExpiresAt;
}
