package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class HomeData implements Serializable {
    @SerializedName("student")
    public Student student;

    @SerializedName("has_full_access")
    public boolean hasFullAccess;

    @SerializedName("active_subscription")
    public Subscription activeSubscription;

    @SerializedName("expired_subscription")
    public Subscription expiredSubscription;

    @SerializedName("stats")
    public Stats stats;

    @SerializedName("categories")
    public List<Category> categories;

    @SerializedName("years")
    public List<Integer> years;

    @SerializedName("recent_research")
    public List<Research> recentResearch;

    public static class Stats implements Serializable {
        @SerializedName("total_approved_research")
        public int totalApprovedResearch;

        @SerializedName("total_categories")
        public int totalCategories;
    }
}
