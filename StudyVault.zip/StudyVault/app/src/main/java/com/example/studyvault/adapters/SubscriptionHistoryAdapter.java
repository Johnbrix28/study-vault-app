package com.example.studyvault.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.R;
import com.example.studyvault.models.Subscription;

import java.util.List;
import java.util.Locale;

/**
 * Adapter rendering student subscription history on the Profile screen.
 */
public class SubscriptionHistoryAdapter extends RecyclerView.Adapter<SubscriptionHistoryAdapter.ViewHolder> {

    private final Context context;
    private final List<Subscription> list;

    public SubscriptionHistoryAdapter(Context context, List<Subscription> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_subscription_history, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Subscription s = list.get(position);

        String title = (s.planName != null ? s.planName : "Access Plan")
                + (s.amountFormatted != null ? " (" + s.amountFormatted + ")" : "");
        holder.tvPlanName.setText(title);

        String status = s.status != null ? s.status.toLowerCase(Locale.US) : "expired";
        String label = status.substring(0, 1).toUpperCase(Locale.US) + status.substring(1);
        holder.tvStatus.setText(label);

        if ("active".equals(status)) {
            holder.tvStatus.setBackgroundResource(R.drawable.bg_badge_green);
            holder.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.sv_green));
        } else if ("pending".equals(status)) {
            holder.tvStatus.setBackgroundResource(R.drawable.bg_badge_amber);
            holder.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.sv_amber));
        } else {
            holder.tvStatus.setBackgroundResource(R.drawable.bg_badge_red);
            holder.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.sv_red));
        }

        String ref = (s.referenceCode != null && !s.referenceCode.isEmpty())
                ? "Reference: " + s.referenceCode
                : "Reference: —";
        holder.tvReference.setText(ref);

        String start = s.startDateFormatted != null ? s.startDateFormatted : "—";
        String end = s.expirationDateFormatted != null ? s.expirationDateFormatted : "—";
        holder.tvDates.setText("Start: " + start + "  ·  Expires: " + end);
    }

    @Override
    public int getItemCount() {
        return list != null ? list.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView tvPlanName;
        final TextView tvStatus;
        final TextView tvReference;
        final TextView tvDates;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPlanName = itemView.findViewById(R.id.tvSubPlanName);
            tvStatus = itemView.findViewById(R.id.tvSubStatus);
            tvReference = itemView.findViewById(R.id.tvSubReference);
            tvDates = itemView.findViewById(R.id.tvSubDates);
        }
    }
}
