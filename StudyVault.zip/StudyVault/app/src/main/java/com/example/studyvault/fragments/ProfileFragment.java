package com.example.studyvault.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.studyvault.activities.LoginActivity;
import com.example.studyvault.databinding.FragmentProfileBinding;
import com.example.studyvault.utils.SessionManager;

public class ProfileFragment extends Fragment {

    private FragmentProfileBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        SessionManager session = new SessionManager(requireContext());

        String name = session.getName();
        String number = session.getNumber();

        // Handle empty
        if (name == null || name.trim().isEmpty()) {
            name = "Student";
        }
        if (number == null || number.trim().isEmpty()) {
            number = "--";
        }

        // Top section
        binding.tvName.setText(name);
        binding.tvNumber.setText("Student ID: " + number);

        // Info card
        binding.tvInfoName.setText(name);
        binding.tvInfoNumber.setText(number);

        // Logout
        binding.btnLogout.setOnClickListener(v -> {
            session.logout();
            Intent intent = new Intent(requireContext(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            requireActivity().finish();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}