package com.example.studyvault.fragments;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.studyvault.R;
import com.example.studyvault.activities.LoginActivity;
import com.example.studyvault.activities.MainActivity;
import com.example.studyvault.adapters.SubscriptionHistoryAdapter;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.ProfileData;
import com.example.studyvault.models.Student;
import com.example.studyvault.models.Subscription;
import com.example.studyvault.repository.StudyVaultRepository;
import com.example.studyvault.utils.ServerConfigDialog;
import com.example.studyvault.utils.SessionManager;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Profile Screen matching study-vault/profile.php and api/profile.php.
 */
public class ProfileFragment extends Fragment {

    private SwipeRefreshLayout swipeRefreshProfile;
    private TextView tvVerifiedBadge;
    private TextView tvProfileInitial;
    private TextView tvName;
    private TextView tvProgramAndType;
    private TextView tvNumber;

    private TextView tvInfoName;
    private TextView tvInfoEmail;
    private TextView tvInfoNumber;
    private TextView tvInfoUserType;
    private TextView tvInfoProgram;
    private TextView tvInfoStatus;

    private TextView tvProfilePlanBadge;
    private TextView tvProfilePlanName;
    private TextView tvProfilePlanExpiry;
    private MaterialButton btnProfilePlans;

    private TextView tvHistoryCount;
    private TextView tvHistoryEmpty;
    private RecyclerView rvSubscriptionHistory;

    private MaterialButton btnProfileServerSettings;
    private MaterialButton btnLogout;

    private SessionManager session;
    private final List<Subscription> historyList = new ArrayList<>();
    private SubscriptionHistoryAdapter historyAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        session = new SessionManager(requireContext());
        bindViews(view);
        setupAdapter();
        bindCachedSession();
        loadProfileData();

        return view;
    }

    private void bindViews(View view) {
        swipeRefreshProfile = view.findViewById(R.id.swipeRefreshProfile);
        tvVerifiedBadge = view.findViewById(R.id.tvVerifiedBadge);
        tvProfileInitial = view.findViewById(R.id.tvProfileInitial);
        tvName = view.findViewById(R.id.tvName);
        tvProgramAndType = view.findViewById(R.id.tvProgramAndType);
        tvNumber = view.findViewById(R.id.tvNumber);

        tvInfoName = view.findViewById(R.id.tvInfoName);
        tvInfoEmail = view.findViewById(R.id.tvInfoEmail);
        tvInfoNumber = view.findViewById(R.id.tvInfoNumber);
        tvInfoUserType = view.findViewById(R.id.tvInfoUserType);
        tvInfoProgram = view.findViewById(R.id.tvInfoProgram);
        tvInfoStatus = view.findViewById(R.id.tvInfoStatus);

        tvProfilePlanBadge = view.findViewById(R.id.tvProfilePlanBadge);
        tvProfilePlanName = view.findViewById(R.id.tvProfilePlanName);
        tvProfilePlanExpiry = view.findViewById(R.id.tvProfilePlanExpiry);
        btnProfilePlans = view.findViewById(R.id.btnProfilePlans);

        tvHistoryCount = view.findViewById(R.id.tvHistoryCount);
        tvHistoryEmpty = view.findViewById(R.id.tvHistoryEmpty);
        rvSubscriptionHistory = view.findViewById(R.id.rvSubscriptionHistory);

        btnProfileServerSettings = view.findViewById(R.id.btnProfileServerSettings);
        btnLogout = view.findViewById(R.id.btnLogout);

        swipeRefreshProfile.setColorSchemeResources(R.color.sv_forest_800, R.color.sv_gold);
        swipeRefreshProfile.setOnRefreshListener(this::loadProfileData);

        btnProfilePlans.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).openAccessPlans();
            }
        });

        btnProfileServerSettings.setOnClickListener(v -> ServerConfigDialog.show(requireContext()));
        btnLogout.setOnClickListener(v -> confirmLogout());
    }

    private void setupAdapter() {
        rvSubscriptionHistory.setLayoutManager(new LinearLayoutManager(getContext()));
        historyAdapter = new SubscriptionHistoryAdapter(requireContext(), historyList);
        rvSubscriptionHistory.setAdapter(historyAdapter);
    }

    private void bindCachedSession() {
        String name = session.getName();
        tvName.setText(!name.isEmpty() ? name : "Student Researcher");
        tvProfileInitial.setText(extractInitials(name));
        tvNumber.setText("STUDENT ID: " + session.getNumber());
        tvProgramAndType.setText(session.getProgramName() + " · " + session.getUserTypeLabel());

        tvInfoName.setText(!name.isEmpty() ? name : "—");
        tvInfoEmail.setText(!session.getEmail().isEmpty() ? session.getEmail() : "—");
        tvInfoNumber.setText(!session.getNumber().isEmpty() ? session.getNumber() : "—");
        tvInfoUserType.setText(session.getUserTypeLabel());
        tvInfoProgram.setText(session.getProgramName());
    }

    private void loadProfileData() {
        ApiClient.getService(requireContext()).getProfile().enqueue(new Callback<ApiResponse<ProfileData>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<ProfileData>> call,
                                   @NonNull Response<ApiResponse<ProfileData>> response) {
                if (!isAdded()) return;
                swipeRefreshProfile.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null
                        && response.body().success && response.body().data != null) {
                    ProfileData data = response.body().data;

                    if (data.student != null) {
                        session.saveStudentSession(data.student, session.getToken());
                        bindStudentDetails(data.student);
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).refreshTopBarUserPill();
                        }
                    }
                    session.updateSubscriptionStatus(data.hasFullAccess, data.activeSubscription);
                    bindPlanSummary(data.hasFullAccess, data.activeSubscription);

                    historyList.clear();
                    if (data.subscriptions != null) {
                        historyList.addAll(data.subscriptions);
                    }
                    historyAdapter.notifyDataSetChanged();

                    int count = historyList.size();
                    tvHistoryCount.setText(count + (count == 1 ? " record" : " records"));
                    tvHistoryEmpty.setVisibility(historyList.isEmpty() ? View.VISIBLE : View.GONE);
                    rvSubscriptionHistory.setVisibility(historyList.isEmpty() ? View.GONE : View.VISIBLE);
                } else {
                    ApiResponse<ProfileData> err = StudyVaultRepository.parseErrorResponse(
                            response, ProfileData.class);
                    if (StudyVaultRepository.isAuthExpired(response, err)
                            && getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).handleSessionExpired(err != null ? err.message : null);
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<ProfileData>> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                swipeRefreshProfile.setRefreshing(false);
            }
        });
    }

    private void bindStudentDetails(Student s) {
        String name = s.fullName != null ? s.fullName : session.getName();
        tvName.setText(name);
        tvProfileInitial.setText(extractInitials(name));
        tvNumber.setText("STUDENT ID: " + (s.studentNumber != null ? s.studentNumber : session.getNumber()));

        String typeLabel = s.userTypeLabel != null ? s.userTypeLabel : session.getUserTypeLabel();
        if (s.graduationYear != null && s.graduationYear > 0) {
            typeLabel = typeLabel + " (Class of " + s.graduationYear + ")";
        }

        String prog = s.programName != null && !s.programName.isEmpty()
                ? s.programName : "Bachelor of Science in Information Technology";

        tvProgramAndType.setText(prog + " · " + typeLabel);

        tvInfoName.setText(name);
        tvInfoEmail.setText(s.email != null ? s.email : "—");
        tvInfoNumber.setText(s.studentNumber != null ? s.studentNumber : "—");
        tvInfoUserType.setText(typeLabel);
        tvInfoProgram.setText(prog);

        String status = s.status != null ? s.status : "approved";
        tvInfoStatus.setText(capitalize(status));

        if ("verified".equalsIgnoreCase(s.verificationStatus)) {
            tvVerifiedBadge.setText("✓ Verified ISU Account");
        } else {
            tvVerifiedBadge.setText("Unverified");
        }
    }

    private void bindPlanSummary(boolean hasFullAccess, Subscription active) {
        if (hasFullAccess && active != null) {
            tvProfilePlanName.setText(active.planName != null ? active.planName : "Research Access");
            tvProfilePlanBadge.setText("Active");
            tvProfilePlanBadge.setBackgroundResource(R.drawable.bg_badge_green);
            tvProfilePlanBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.sv_green));
            tvProfilePlanExpiry.setText("Full manuscript viewing unlocked until "
                    + (active.expirationDateFormatted != null ? active.expirationDateFormatted : active.expirationDate)
                    + "\nReference: " + (active.referenceCode != null ? active.referenceCode : "—"));
            btnProfilePlans.setText("Extend or Switch Plan →");
        } else {
            tvProfilePlanName.setText("Free Access");
            tvProfilePlanBadge.setText("Free");
            tvProfilePlanBadge.setBackgroundResource(R.drawable.bg_badge_gray);
            tvProfilePlanBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.sv_gray));
            tvProfilePlanExpiry.setText(
                    "You can search the archive and read research abstracts. Choose an access plan to view complete manuscripts.");
            btnProfilePlans.setText(R.string.manage_or_upgrade_plan);
        }
    }

    private void confirmLogout() {
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.logout_confirm_title)
                .setMessage(R.string.logout_confirm_message)
                .setPositiveButton(R.string.logout_confirm_yes, (dialog, which) -> executeLogout())
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void executeLogout() {
        ApiClient.getService(requireContext()).logout().enqueue(new Callback<ApiResponse<Object>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<Object>> call,
                                   @NonNull Response<ApiResponse<Object>> response) {
                finalizeLocalLogout();
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<Object>> call, @NonNull Throwable t) {
                finalizeLocalLogout();
            }
        });
    }

    private void finalizeLocalLogout() {
        if (!isAdded()) return;
        session.logout();
        ApiClient.clearCookies();

        Intent intent = new Intent(requireContext(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        if (getActivity() != null) {
            getActivity().finish();
        }
    }

    private static String extractInitials(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) return "SV";
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) {
            return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase(Locale.US);
        }
        String first = parts[0].substring(0, 1);
        String last = parts[parts.length - 1].substring(0, 1);
        return (first + last).toUpperCase(Locale.US);
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return "";
        return s.substring(0, 1).toUpperCase(Locale.US) + s.substring(1).toLowerCase(Locale.US);
    }
}
