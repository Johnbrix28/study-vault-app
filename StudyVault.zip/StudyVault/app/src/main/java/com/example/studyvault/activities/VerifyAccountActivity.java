package com.example.studyvault.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.studyvault.R;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.VerificationData;
import com.example.studyvault.repository.StudyVaultRepository;
import com.example.studyvault.utils.ValidationUtils;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * 3-Step Student ID Email Verification & Password Creation Screen
 * matching study-vault/verify.php and api/verify.php.
 */
public class VerifyAccountActivity extends AppCompatActivity {

    private ImageView btnBackTop;
    private TextView tvStepKicker;
    private TextView tvVerifyBanner;

    private LinearLayout step1Container, step2Container, step3Container;
    private TextView tvStep1Num, tvStep2Num, tvStep3Num;
    private TextView tvStep1Label, tvStep2Label, tvStep3Label;

    // Step 1
    private LinearLayout layoutStep1;
    private TextInputEditText etVerifyStudentId;
    private MaterialButton btnSendCode;

    // Step 2
    private LinearLayout layoutStep2;
    private TextView tvMaskedEmailInfo;
    private TextView tvStep2StudentName;
    private TextView tvStep2StudentMeta;
    private EditText etVerificationCode;
    private MaterialButton btnVerifyCode;
    private TextView btnResendCode;
    private TextView btnChangeStudentId;

    // Step 3
    private LinearLayout layoutStep3;
    private TextView tvStep3Welcome;
    private TextView tvStep3Subtitle;
    private TextView tvStep3AccountDetails;
    private TextInputEditText etCreatePassword;
    private TextInputEditText etConfirmPassword;
    private MaterialButton btnCreateAccount;

    // Step 4 (Completion card)
    private LinearLayout layoutStep4;
    private TextView tvCompleteBadge;
    private TextView tvCompleteTitle;
    private TextView tvCompleteMessage;
    private MaterialButton btnProceedToLogin;

    private ProgressBar progressVerify;
    private TextView tvBackToLogin;

    private String verificationToken = "";
    private String currentStudentId = "";
    private CountDownTimer resendTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_account);

        ApiClient.init(this);
        bindViews();

        Intent incoming = getIntent();
        if (incoming != null) {
            String prefill = incoming.getStringExtra("prefill_student_id");
            if (prefill != null && !prefill.isEmpty()) {
                etVerifyStudentId.setText(prefill);
            }
        }

        btnBackTop.setOnClickListener(v -> finish());
        tvBackToLogin.setOnClickListener(v -> finish());

        btnSendCode.setOnClickListener(v -> submitSendCode());
        btnVerifyCode.setOnClickListener(v -> submitVerifyCode());
        btnResendCode.setOnClickListener(v -> submitResendCode());
        btnChangeStudentId.setOnClickListener(v -> restartVerification());
        btnCreateAccount.setOnClickListener(v -> submitCreateAccount());
        btnProceedToLogin.setOnClickListener(v -> {
            Intent intent = new Intent(VerifyAccountActivity.this, LoginActivity.class);
            intent.putExtra("prefill_student_id", currentStudentId);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        updateStepUi(1);
    }

    private void bindViews() {
        btnBackTop = findViewById(R.id.btnBackTop);
        tvStepKicker = findViewById(R.id.tvStepKicker);
        tvVerifyBanner = findViewById(R.id.tvVerifyBanner);

        step1Container = findViewById(R.id.step1Container);
        step2Container = findViewById(R.id.step2Container);
        step3Container = findViewById(R.id.step3Container);
        tvStep1Num = findViewById(R.id.tvStep1Num);
        tvStep2Num = findViewById(R.id.tvStep2Num);
        tvStep3Num = findViewById(R.id.tvStep3Num);
        tvStep1Label = findViewById(R.id.tvStep1Label);
        tvStep2Label = findViewById(R.id.tvStep2Label);
        tvStep3Label = findViewById(R.id.tvStep3Label);

        layoutStep1 = findViewById(R.id.layoutStep1);
        etVerifyStudentId = findViewById(R.id.etVerifyStudentId);
        btnSendCode = findViewById(R.id.btnSendCode);

        layoutStep2 = findViewById(R.id.layoutStep2);
        tvMaskedEmailInfo = findViewById(R.id.tvMaskedEmailInfo);
        tvStep2StudentName = findViewById(R.id.tvStep2StudentName);
        tvStep2StudentMeta = findViewById(R.id.tvStep2StudentMeta);
        etVerificationCode = findViewById(R.id.etVerificationCode);
        btnVerifyCode = findViewById(R.id.btnVerifyCode);
        btnResendCode = findViewById(R.id.btnResendCode);
        btnChangeStudentId = findViewById(R.id.btnChangeStudentId);

        layoutStep3 = findViewById(R.id.layoutStep3);
        tvStep3Welcome = findViewById(R.id.tvStep3Welcome);
        tvStep3Subtitle = findViewById(R.id.tvStep3Subtitle);
        tvStep3AccountDetails = findViewById(R.id.tvStep3AccountDetails);
        etCreatePassword = findViewById(R.id.etCreatePassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        layoutStep4 = findViewById(R.id.layoutStep4);
        tvCompleteBadge = findViewById(R.id.tvCompleteBadge);
        tvCompleteTitle = findViewById(R.id.tvCompleteTitle);
        tvCompleteMessage = findViewById(R.id.tvCompleteMessage);
        btnProceedToLogin = findViewById(R.id.btnProceedToLogin);

        progressVerify = findViewById(R.id.progressVerify);
        tvBackToLogin = findViewById(R.id.tvBackToLogin);
    }

    private void submitSendCode() {
        hideAlert();
        String studentId = ValidationUtils.normalizeStudentId(getText(etVerifyStudentId));
        if (studentId.isEmpty()) {
            etVerifyStudentId.setError("Please enter your Student ID.");
            etVerifyStudentId.requestFocus();
            return;
        }
        if (!ValidationUtils.isValidStudentId(studentId)) {
            etVerifyStudentId.setError("Enter a valid Student ID (e.g. 23-11420).");
            etVerifyStudentId.requestFocus();
            return;
        }

        currentStudentId = studentId;
        setLoading(true);

        ApiClient.getService(this)
                .verifyStudentId("send_code", studentId, "", "", "", "")
                .enqueue(new Callback<ApiResponse<VerificationData>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<VerificationData>> call,
                                           @NonNull Response<ApiResponse<VerificationData>> response) {
                        setLoading(false);
                        ApiResponse<VerificationData> body = response.isSuccessful()
                                ? response.body()
                                : StudyVaultRepository.parseErrorResponse(response, VerificationData.class);

                        if (body != null && body.success && body.data != null) {
                            VerificationData d = body.data;
                            if (d.verificationToken != null) {
                                verificationToken = d.verificationToken;
                            }
                            String masked = d.maskedEmail != null ? d.maskedEmail : "your school email";
                            tvMaskedEmailInfo.setText(String.format(
                                    Locale.US,
                                    "Enter the 6-digit code sent to %s. It is valid for %d minutes.",
                                    masked,
                                    d.ttlMinutes > 0 ? d.ttlMinutes : 10
                            ));
                            populateStep2Preview(d.studentPreview);
                            etVerificationCode.setText("");
                            updateStepUi(2);
                            showAlert(body.message != null ? body.message
                                    : "A 6-digit verification code was sent to " + masked + ".", false);
                            startResendCooldown(d.resendWait > 0 ? d.resendWait : 60);
                        } else {
                            String msg = (body != null && body.message != null)
                                    ? body.message
                                    : "Could not verify Student ID.";
                            showAlert(msg, true);

                            if (body != null && (body.showLogin || "already_linked".equals(body.code))) {
                                offerSignInRedirect(studentId, msg);
                            }
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<VerificationData>> call, @NonNull Throwable t) {
                        setLoading(false);
                        showAlert(getString(R.string.error_network), true);
                    }
                });
    }

    private void submitVerifyCode() {
        hideAlert();
        String code = etVerificationCode.getText() != null
                ? etVerificationCode.getText().toString().replaceAll("\\D", "") : "";
        if (!ValidationUtils.isValidVerificationCode(code)) {
            etVerificationCode.setError("Please enter the 6-digit verification code.");
            etVerificationCode.requestFocus();
            return;
        }

        setLoading(true);
        ApiClient.getService(this)
                .verifyStudentId("verify_code", currentStudentId, verificationToken, code, "", "")
                .enqueue(new Callback<ApiResponse<VerificationData>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<VerificationData>> call,
                                           @NonNull Response<ApiResponse<VerificationData>> response) {
                        setLoading(false);
                        ApiResponse<VerificationData> body = response.isSuccessful()
                                ? response.body()
                                : StudyVaultRepository.parseErrorResponse(response, VerificationData.class);

                        if (body != null && body.success && body.data != null) {
                            VerificationData d = body.data;
                            if (d.verificationToken != null) {
                                verificationToken = d.verificationToken;
                            }
                            populateStep3Preview(d.studentPreview);
                            updateStepUi(3);
                            showAlert(body.message != null ? body.message
                                    : "Email verified. Create your password to finish setting up your account.", false);
                        } else {
                            String msg = (body != null && body.message != null)
                                    ? body.message
                                    : "Incorrect verification code.";
                            showAlert(msg, true);
                            if (body != null && body.restart) {
                                updateStepUi(1);
                            }
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<VerificationData>> call, @NonNull Throwable t) {
                        setLoading(false);
                        showAlert(getString(R.string.error_network), true);
                    }
                });
    }

    private void submitResendCode() {
        hideAlert();
        setLoading(true);

        ApiClient.getService(this)
                .verifyStudentId("resend", currentStudentId, verificationToken, "", "", "")
                .enqueue(new Callback<ApiResponse<VerificationData>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<VerificationData>> call,
                                           @NonNull Response<ApiResponse<VerificationData>> response) {
                        setLoading(false);
                        ApiResponse<VerificationData> body = response.isSuccessful()
                                ? response.body()
                                : StudyVaultRepository.parseErrorResponse(response, VerificationData.class);

                        if (body != null && body.success && body.data != null) {
                            VerificationData d = body.data;
                            if (d.verificationToken != null) {
                                verificationToken = d.verificationToken;
                            }
                            showAlert(body.message != null ? body.message
                                    : "A new verification code was sent.", false);
                            startResendCooldown(d.resendWait > 0 ? d.resendWait : 60);
                        } else {
                            String msg = (body != null && body.message != null)
                                    ? body.message
                                    : "Could not resend verification code.";
                            showAlert(msg, true);
                            if (body != null && body.data != null && body.data.resendWait > 0) {
                                startResendCooldown(body.data.resendWait);
                            }
                            if (body != null && body.restart) {
                                updateStepUi(1);
                            }
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<VerificationData>> call, @NonNull Throwable t) {
                        setLoading(false);
                        showAlert(getString(R.string.error_network), true);
                    }
                });
    }

    private void submitCreateAccount() {
        hideAlert();
        String password = etCreatePassword.getText() != null ? etCreatePassword.getText().toString() : "";
        String confirm = etConfirmPassword.getText() != null ? etConfirmPassword.getText().toString() : "";

        String validationError = ValidationUtils.validatePassword(password, confirm);
        if (validationError != null) {
            showAlert(validationError, true);
            return;
        }

        setLoading(true);
        ApiClient.getService(this)
                .verifyStudentId("create_account", currentStudentId, verificationToken, "", password, confirm)
                .enqueue(new Callback<ApiResponse<VerificationData>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<VerificationData>> call,
                                           @NonNull Response<ApiResponse<VerificationData>> response) {
                        setLoading(false);
                        ApiResponse<VerificationData> body = response.isSuccessful()
                                ? response.body()
                                : StudyVaultRepository.parseErrorResponse(response, VerificationData.class);

                        if (body != null && body.success) {
                            String msg = body.message != null ? body.message
                                    : "Your Study Vault account has been verified and activated.";
                            if (body.data != null && body.data.studentNumber != null) {
                                currentStudentId = body.data.studentNumber;
                            }
                            boolean requiresApproval = body.data != null && body.data.requiresApproval;
                            tvCompleteBadge.setText(requiresApproval ? "Pending Approval" : "Verified & Active");
                            tvCompleteTitle.setText(requiresApproval ? "Account Submitted" : "Account Ready");
                            tvCompleteMessage.setText(msg);
                            updateStepUi(4);
                        } else {
                            String msg = (body != null && body.message != null)
                                    ? body.message
                                    : "Could not complete account setup.";
                            showAlert(msg, true);
                            if (body != null && body.restart) {
                                updateStepUi(1);
                            }
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<VerificationData>> call, @NonNull Throwable t) {
                        setLoading(false);
                        showAlert(getString(R.string.error_network), true);
                    }
                });
    }

    private void restartVerification() {
        if (resendTimer != null) {
            resendTimer.cancel();
        }
        verificationToken = "";
        hideAlert();
        updateStepUi(1);
        ApiClient.getService(this)
                .verifyStudentId("restart", "", "", "", "", "")
                .enqueue(new Callback<ApiResponse<VerificationData>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<VerificationData>> call,
                                           @NonNull Response<ApiResponse<VerificationData>> response) {
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<VerificationData>> call, @NonNull Throwable t) {
                    }
                });
    }

    private void populateStep2Preview(VerificationData.StudentPreview preview) {
        if (preview == null) return;
        tvStep2StudentName.setText(preview.fullName != null ? preview.fullName : "Verified Student");
        String prog = preview.program != null ? preview.program : "BSIT";
        String role = preview.userTypeLabel != null ? preview.userTypeLabel : "Enrolled IT Student";
        tvStep2StudentMeta.setText(preview.studentId + " • " + prog + " • " + role);
    }

    private void populateStep3Preview(VerificationData.StudentPreview preview) {
        if (preview == null) return;
        tvStep3Welcome.setText("Welcome, " + (preview.fullName != null ? preview.fullName : "Student") + "!");
        tvStep3Subtitle.setText("Your school email (" + preview.maskedEmail + ") is verified. Create a password to finish setting up your Study Vault account.");

        String prog = preview.program != null ? preview.program : "BSIT";
        if (preview.section != null && !preview.section.isEmpty()) {
            prog = prog + " (Section " + preview.section + ")";
        }
        String role = preview.userTypeLabel != null ? preview.userTypeLabel : "Enrolled IT Student";
        if (preview.graduationYear != null && preview.graduationYear > 0) {
            role = role + " · Class of " + preview.graduationYear;
        }

        String details = "Student ID: " + (preview.studentId != null ? preview.studentId : currentStudentId)
                + "\nProgram: " + prog
                + "\nRole: " + role;
        tvStep3AccountDetails.setText(details);
    }

    private void updateStepUi(int step) {
        layoutStep1.setVisibility(step == 1 ? View.VISIBLE : View.GONE);
        layoutStep2.setVisibility(step == 2 ? View.VISIBLE : View.GONE);
        layoutStep3.setVisibility(step == 3 ? View.VISIBLE : View.GONE);
        layoutStep4.setVisibility(step == 4 ? View.VISIBLE : View.GONE);

        int headerStep = Math.min(3, step);
        tvStepKicker.setText("SECURE ACCOUNT SETUP / STEP " + headerStep + " OF 3");

        styleStepBox(step1Container, tvStep1Num, tvStep1Label, 1, step);
        styleStepBox(step2Container, tvStep2Num, tvStep2Label, 2, step);
        styleStepBox(step3Container, tvStep3Num, tvStep3Label, 3, step);
    }

    private void styleStepBox(LinearLayout box, TextView tvNum, TextView tvLabel, int index, int activeStep) {
        if (index < activeStep) {
            box.setBackgroundResource(R.drawable.bg_step_done);
            tvNum.setText("✓");
            tvNum.setTextColor(ContextCompat.getColor(this, R.color.sv_green));
            tvLabel.setTextColor(ContextCompat.getColor(this, R.color.sv_green));
        } else if (index == activeStep) {
            box.setBackgroundResource(R.drawable.bg_step_active);
            tvNum.setText(String.format(Locale.US, "%02d", index));
            tvNum.setTextColor(ContextCompat.getColor(this, R.color.white));
            tvLabel.setTextColor(ContextCompat.getColor(this, R.color.white));
        } else {
            box.setBackgroundResource(R.drawable.bg_step_inactive);
            tvNum.setText(String.format(Locale.US, "%02d", index));
            tvNum.setTextColor(ContextCompat.getColor(this, R.color.sv_muted));
            tvLabel.setTextColor(ContextCompat.getColor(this, R.color.sv_muted));
        }
    }

    private void startResendCooldown(int seconds) {
        if (resendTimer != null) {
            resendTimer.cancel();
        }
        btnResendCode.setEnabled(false);
        btnResendCode.setAlpha(0.55f);
        resendTimer = new CountDownTimer(seconds * 1000L, 1000L) {
            @Override
            public void onTick(long millisUntilFinished) {
                long sec = Math.max(1L, millisUntilFinished / 1000L);
                btnResendCode.setText("Resend code (" + sec + "s)");
            }

            @Override
            public void onFinish() {
                btnResendCode.setEnabled(true);
                btnResendCode.setAlpha(1.0f);
                btnResendCode.setText(R.string.resend_code_btn);
            }
        }.start();
    }

    private void offerSignInRedirect(String studentId, String message) {
        new AlertDialog.Builder(this)
                .setTitle("Account Already Verified")
                .setMessage(message)
                .setPositiveButton("Go to Sign In", (d, w) -> {
                    Intent intent = new Intent(VerifyAccountActivity.this, LoginActivity.class);
                    intent.putExtra("prefill_student_id", studentId);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("Stay Here", null)
                .show();
    }

    private void setLoading(boolean loading) {
        progressVerify.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnSendCode.setEnabled(!loading);
        btnVerifyCode.setEnabled(!loading);
        btnCreateAccount.setEnabled(!loading);
    }

    private void showAlert(String message, boolean isError) {
        tvVerifyBanner.setText(message);
        tvVerifyBanner.setBackgroundResource(isError ? R.drawable.bg_badge_red : R.drawable.bg_badge_green);
        tvVerifyBanner.setTextColor(ContextCompat.getColor(this,
                isError ? R.color.sv_red : R.color.sv_green));
        tvVerifyBanner.setVisibility(View.VISIBLE);
    }

    private void hideAlert() {
        tvVerifyBanner.setVisibility(View.GONE);
    }

    private static String getText(TextInputEditText et) {
        return et != null && et.getText() != null ? et.getText().toString().trim() : "";
    }

    @Override
    protected void onDestroy() {
        if (resendTimer != null) {
            resendTimer.cancel();
        }
        super.onDestroy();
    }
}
