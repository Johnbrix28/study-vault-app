package com.example.studyvault.adapters;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.R;
import com.example.studyvault.models.AccessPlan;
import com.example.studyvault.models.Subscription;
import com.google.android.material.button.MaterialButton;

import java.util.List;

/**
 * Adapter rendering Study Vault access plans matching includes/plan-options.php.
 */
public class PlanAdapter extends RecyclerView.Adapter<PlanAdapter.ViewHolder> {

    public interface OnPlanSelectListener {
        void onSelectPlan(AccessPlan plan);
    }

    private final Context context;
    private final List<AccessPlan> list;
    private Subscription activeSubscription;
    private final OnPlanSelectListener listener;

    public PlanAdapter(Context context, List<AccessPlan> list, Subscription activeSubscription, OnPlanSelectListener listener) {
        this.context = context;
        this.list = list;
        this.activeSubscription = activeSubscription;
        this.listener = listener;
    }

    public void setActiveSubscription(Subscription activeSubscription) {
        this.activeSubscription = activeSubscription;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_plan, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AccessPlan plan = list.get(position);

        // Ribbon
        if (plan.isCurrent) {
            holder.tvRibbon.setVisibility(View.VISIBLE);
            holder.tvRibbon.setText(R.string.current_plan);
            holder.tvRibbon.setBackgroundResource(R.drawable.bg_badge_green);
            holder.tvRibbon.setTextColor(ContextCompat.getColor(context, R.color.sv_green));
        } else if (plan.fullAccess) {
            holder.tvRibbon.setVisibility(View.VISIBLE);
            holder.tvRibbon.setText(R.string.full_text_access);
            holder.tvRibbon.setBackgroundResource(R.drawable.bg_gold_ribbon);
            holder.tvRibbon.setTextColor(ContextCompat.getColor(context, R.color.sv_forest_950));
        } else {
            holder.tvRibbon.setVisibility(View.GONE);
        }

        holder.tvName.setText(plan.planName != null ? plan.planName : "Access Plan");
        holder.tvPrice.setText(plan.priceFormatted != null ? plan.priceFormatted : "₱0");

        if (plan.durationDays > 0) {
            holder.tvDuration.setText("/ " + plan.durationDays + " days");
        } else {
            holder.tvDuration.setText("/ no expiry");
        }

        holder.tvDesc.setText(plan.description != null ? plan.description : "");

        // Features list
        holder.layoutFeatures.removeAllViews();
        if (plan.features != null) {
            float density = context.getResources().getDisplayMetrics().density;
            for (String feat : plan.features) {
                TextView tvFeat = new TextView(context);
                tvFeat.setText("✓  " + feat);
                tvFeat.setTextColor(ContextCompat.getColor(context, R.color.sv_ink));
                tvFeat.setTextSize(12f);
                tvFeat.setPadding(0, (int) (3 * density), 0, (int) (3 * density));
                holder.layoutFeatures.addView(tvFeat);
            }
        }

        // Action button state (matches plan-options.php)
        if (plan.isCurrent) {
            holder.btnSelect.setEnabled(false);
            if (!plan.isFree && activeSubscription != null && activeSubscription.expirationDateFormatted != null) {
                holder.btnSelect.setText("Active until " + activeSubscription.expirationDateFormatted);
            } else {
                holder.btnSelect.setText("Active plan");
            }
            holder.btnSelect.setBackgroundTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(context, R.color.sv_forest_100)));
            holder.btnSelect.setTextColor(ContextCompat.getColor(context, R.color.sv_forest_800));
            holder.btnSelect.setOnClickListener(null);
        } else if (plan.isFree) {
            holder.btnSelect.setEnabled(false);
            holder.btnSelect.setText(activeSubscription != null
                    ? "Switch happens automatically on expiry"
                    : "Included with every account");
            holder.btnSelect.setBackgroundTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(context, R.color.sv_forest_050)));
            holder.btnSelect.setTextColor(ContextCompat.getColor(context, R.color.sv_muted));
            holder.btnSelect.setOnClickListener(null);
        } else {
            holder.btnSelect.setEnabled(true);
            holder.btnSelect.setText(activeSubscription != null
                    ? "Extend / switch plan →"
                    : "Get this plan →");
            holder.btnSelect.setBackgroundTintList(
                    ColorStateList.valueOf(ContextCompat.getColor(context, R.color.sv_forest_800)));
            holder.btnSelect.setTextColor(ContextCompat.getColor(context, R.color.white));
            holder.btnSelect.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onSelectPlan(plan);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return list != null ? list.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final LinearLayout cardRoot;
        final TextView tvRibbon;
        final TextView tvName;
        final TextView tvPrice;
        final TextView tvDuration;
        final TextView tvDesc;
        final LinearLayout layoutFeatures;
        final MaterialButton btnSelect;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardRoot = itemView.findViewById(R.id.cardPlanRoot);
            tvRibbon = itemView.findViewById(R.id.tvPlanRibbon);
            tvName = itemView.findViewById(R.id.tvPlanName);
            tvPrice = itemView.findViewById(R.id.tvPlanPrice);
            tvDuration = itemView.findViewById(R.id.tvPlanDuration);
            tvDesc = itemView.findViewById(R.id.tvPlanDesc);
            layoutFeatures = itemView.findViewById(R.id.layoutPlanFeatures);
            btnSelect = itemView.findViewById(R.id.btnSelectPlan);
        }
    }
}
