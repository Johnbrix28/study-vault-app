package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Category implements Serializable {
    @SerializedName("category_id")
    public int categoryId;

    @SerializedName("category_name")
    public String categoryName;

    @SerializedName("description")
    public String description;

    @SerializedName("total")
    public int total;

    public Category() {}

    public Category(int categoryId, String categoryName, String description, int total) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.description = description;
        this.total = total;
    }
}
