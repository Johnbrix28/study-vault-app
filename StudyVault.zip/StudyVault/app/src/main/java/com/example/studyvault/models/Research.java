package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class Research implements Serializable {
    @SerializedName("research_id")
    public int researchId;

    @SerializedName("title")
    public String title;

    @SerializedName("abstract")
    public String abstractText;

    @SerializedName("excerpt")
    public String excerpt;

    @SerializedName("year")
    public int year;

    @SerializedName("published_date")
    public String publishedDate;

    @SerializedName("published_date_formatted")
    public String publishedDateFormatted;

    @SerializedName("keywords")
    public String keywords;

    @SerializedName("keyword_list")
    public List<String> keywordList;

    @SerializedName("category_id")
    public int categoryId;

    @SerializedName("category_name")
    public String categoryName;

    @SerializedName("program_name")
    public String programName;

    @SerializedName("researchers")
    public String researchers;

    @SerializedName("has_manuscript")
    public boolean hasManuscript;

    @SerializedName("can_view_manuscript")
    public boolean canViewManuscript;

    @SerializedName("access_code")
    public String accessCode;

    @SerializedName("access_reason")
    public String accessReason;

    @SerializedName("manuscript_url")
    public String manuscriptUrl;

    @SerializedName("related")
    public List<RelatedResearch> related;
}
