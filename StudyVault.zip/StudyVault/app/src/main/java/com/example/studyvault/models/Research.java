package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class Research implements Serializable {
    @SerializedName("research_id")     public int researchId;
    @SerializedName("title")           public String title;
    @SerializedName("abstract")        public String abstractText;
    @SerializedName("year")            public int year;
    @SerializedName("published_date")  public String publishedDate;
    @SerializedName("keywords")        public String keywords;
    @SerializedName("category_id")     public int categoryId;
    @SerializedName("category_name")   public String categoryName;
    @SerializedName("researchers")     public String researchers;
    @SerializedName("file_path")       public String filePath;
    @SerializedName("related")         public List<RelatedResearch> related;   // ⭐ NEW
}