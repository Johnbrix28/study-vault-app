package com.example.studyvault.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.R;

import java.util.List;

public class SuggestionAdapter extends RecyclerView.Adapter<SuggestionAdapter.VH> {

    public interface OnSuggestionClick {
        void onClick(String suggestion);
    }

    private final List<String> data;
    private final OnSuggestionClick listener;

    public SuggestionAdapter(List<String> data, OnSuggestionClick listener) {
        this.data = data;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_suggestion, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        String suggestion = data.get(position);
        holder.tvSuggestion.setText(suggestion);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(suggestion);
        });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView tvSuggestion;
        VH(View v) {
            super(v);
            tvSuggestion = v.findViewById(R.id.tvSuggestion);
        }
    }
}