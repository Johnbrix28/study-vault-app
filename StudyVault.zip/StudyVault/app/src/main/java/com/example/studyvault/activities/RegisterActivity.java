package com.example.studyvault.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.studyvault.api.ApiClient;
import com.example.studyvault.databinding.ActivityRegisterBinding;
import com.example.studyvault.models.ApiResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnRegister.setOnClickListener(v -> doRegister());
        binding.tvBack.setOnClickListener(v -> finish());
    }

    private void doRegister() {
        String number    = binding.etStudentId.getText().toString().trim();
        String firstName = binding.etFirstName.getText().toString().trim();
        String lastName  = binding.etLastName.getText().toString().trim();
        String password  = binding.etPassword.getText().toString().trim();
        String confirm   = binding.etConfirm.getText().toString().trim();

        if (number.isEmpty() || firstName.isEmpty() || lastName.isEmpty()
                || password.isEmpty() || confirm.isEmpty()) {
            Toast.makeText(this, "Complete all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!password.equals(confirm)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        binding.progress.setVisibility(View.VISIBLE);

        ApiClient.getService().register(number, firstName, lastName, password)
                .enqueue(new Callback<ApiResponse<Object>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Object>> call,
                                           Response<ApiResponse<Object>> response) {
                        binding.progress.setVisibility(View.GONE);
                        if (response.isSuccessful() && response.body() != null
                                && response.body().success) {
                            Toast.makeText(RegisterActivity.this,
                                    "Account created! Please log in.",
                                    Toast.LENGTH_LONG).show();
                            finish();
                        } else {
                            String msg = response.body() != null
                                    ? response.body().message : "Registration failed";
                            Toast.makeText(RegisterActivity.this, msg, Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Object>> call, Throwable t) {
                        binding.progress.setVisibility(View.GONE);
                        Toast.makeText(RegisterActivity.this,
                                "Network error: " + t.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }
}