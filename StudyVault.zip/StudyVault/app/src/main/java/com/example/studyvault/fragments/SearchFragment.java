package com.example.studyvault.fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.R;
import com.example.studyvault.activities.MainActivity;
import com.example.studyvault.adapters.ResearchAdapter;
import com.example.studyvault.adapters.SuggestionAdapter;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.Category;
import com.example.studyvault.models.Research;
import com.example.studyvault.repository.StudyVaultRepository;
import com.google.android.material.button.MaterialButton;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Research Archive & Search Screen matching study-vault/research.php and api/research-list.php.
 */
public class SearchFragment extends Fragment {

    private static final String ARG_QUERY = "arg_query";
    private static final String ARG_CATEGORY_ID = "arg_category_id";

    private TextView tvTotalCountBadge;
    private EditText etSearch;
    private TextView btnClearSearch;
    private MaterialButton btnDoSearch;
    private CardView suggestionsCard;
    private RecyclerView rvSuggestions;

    private Spinner spinnerCategory;
    private Spinner spinnerYear;

    private TextView tvCount;
    private TextView tvClearFilters;
    private TextView tvSort;

    private RecyclerView rvResults;
    private ProgressBar progressBar;
    private LinearLayout layoutEmpty;
    private TextView tvEmpty;
    private LinearLayout layoutSearchError;
    private TextView tvSearchError;
    private MaterialButton btnRetrySearch;

    private LinearLayout layoutPagination;
    private MaterialButton btnPrevPage;
    private TextView tvPageIndicator;
    private MaterialButton btnNextPage;

    private final List<Research> researchList = new ArrayList<>();
    private final List<String> suggestionList = new ArrayList<>();
    private final List<Category> dynamicCategories = new ArrayList<>();
    private final List<Integer> dynamicYears = new ArrayList<>();

    private ResearchAdapter researchAdapter;
    private SuggestionAdapter suggestionAdapter;

    private String currentQuery = "";
    private Integer selectedCategoryId = null;
    private Integer selectedYear = null;
    private String selectedSort = "recent";
    private int currentPage = 1;
    private int totalPages = 1;
    private boolean filtersInitialized = false;
    private boolean suppressSpinnerEvents = false;

    private final Handler searchHandler = new Handler(Looper.getMainLooper());
    private Runnable searchRunnable;

    public static SearchFragment newInstance(String initialQuery, int initialCategoryId) {
        SearchFragment fragment = new SearchFragment();
        Bundle args = new Bundle();
        if (initialQuery != null) {
            args.putString(ARG_QUERY, initialQuery);
        }
        if (initialCategoryId > 0) {
            args.putInt(ARG_CATEGORY_ID, initialCategoryId);
        }
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            String q = getArguments().getString(ARG_QUERY, "");
            if (q != null && !q.isEmpty()) {
                currentQuery = q;
            }
            int catId = getArguments().getInt(ARG_CATEGORY_ID, 0);
            if (catId > 0) {
                selectedCategoryId = catId;
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        bindViews(view);
        setupAdapters();
        setupSearchListeners();

        if (!currentQuery.isEmpty()) {
            etSearch.setText(currentQuery);
            btnClearSearch.setVisibility(View.VISIBLE);
        }

        fetchResearchPage(1);
        return view;
    }

    private void bindViews(View view) {
        tvTotalCountBadge = view.findViewById(R.id.tvTotalCountBadge);
        etSearch = view.findViewById(R.id.etSearch);
        btnClearSearch = view.findViewById(R.id.btnClearSearch);
        btnDoSearch = view.findViewById(R.id.btnDoSearch);
        suggestionsCard = view.findViewById(R.id.suggestionsCard);
        rvSuggestions = view.findViewById(R.id.rvSuggestions);

        spinnerCategory = view.findViewById(R.id.spinnerCategory);
        spinnerYear = view.findViewById(R.id.spinnerYear);

        tvCount = view.findViewById(R.id.tvCount);
        tvClearFilters = view.findViewById(R.id.tvClearFilters);
        tvSort = view.findViewById(R.id.tvSort);

        rvResults = view.findViewById(R.id.rvResults);
        progressBar = view.findViewById(R.id.progress);
        layoutEmpty = view.findViewById(R.id.layoutEmpty);
        tvEmpty = view.findViewById(R.id.tvEmpty);
        layoutSearchError = view.findViewById(R.id.layoutSearchError);
        tvSearchError = view.findViewById(R.id.tvSearchError);
        btnRetrySearch = view.findViewById(R.id.btnRetrySearch);

        layoutPagination = view.findViewById(R.id.layoutPagination);
        btnPrevPage = view.findViewById(R.id.btnPrevPage);
        tvPageIndicator = view.findViewById(R.id.tvPageIndicator);
        btnNextPage = view.findViewById(R.id.btnNextPage);

        btnRetrySearch.setOnClickListener(v -> fetchResearchPage(currentPage));
        btnPrevPage.setOnClickListener(v -> {
            if (currentPage > 1) {
                fetchResearchPage(currentPage - 1);
            }
        });
        btnNextPage.setOnClickListener(v -> {
            if (currentPage < totalPages) {
                fetchResearchPage(currentPage + 1);
            }
        });

        tvClearFilters.setOnClickListener(v -> resetAllFilters());
        tvSort.setOnClickListener(v -> showSortDialog());
    }

    private void setupAdapters() {
        rvResults.setLayoutManager(new LinearLayoutManager(getContext()));
        researchAdapter = new ResearchAdapter(getContext(), researchList);
        rvResults.setAdapter(researchAdapter);

        rvSuggestions.setLayoutManager(new LinearLayoutManager(getContext()));
        suggestionAdapter = new SuggestionAdapter(getContext(), suggestionList, suggestion -> {
            etSearch.setText(suggestion);
            etSearch.setSelection(suggestion.length());
            suggestionsCard.setVisibility(View.GONE);
            currentQuery = suggestion;
            fetchResearchPage(1);
        });
        rvSuggestions.setAdapter(suggestionAdapter);
    }

    private void showSortDialog() {
        String[] labels = new String[]{
                getString(R.string.sort_recent),
                getString(R.string.sort_oldest),
                getString(R.string.sort_title)
        };
        String[] values = new String[]{"recent", "oldest", "title"};

        new AlertDialog.Builder(requireContext())
                .setTitle("Sort Research Archive")
                .setItems(labels, (dialog, which) -> {
                    selectedSort = values[which];
                    tvSort.setText(labels[which] + " ▾");
                    fetchResearchPage(1);
                })
                .show();
    }

    private void populateDynamicFilterSpinners(ApiResponse.FilterOptions filters) {
        if (filters == null || filtersInitialized || !isAdded()) return;
        filtersInitialized = true;
        suppressSpinnerEvents = true;

        dynamicCategories.clear();
        List<String> catNames = new ArrayList<>();
        catNames.add(getString(R.string.all_categories));
        int preselectedCatPos = 0;

        if (filters.categories != null) {
            for (int i = 0; i < filters.categories.size(); i++) {
                Category c = filters.categories.get(i);
                dynamicCategories.add(c);
                catNames.add(c.categoryName + " (" + c.total + ")");
                if (selectedCategoryId != null && selectedCategoryId == c.categoryId) {
                    preselectedCatPos = i + 1;
                }
            }
        }

        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(
                requireContext(), android.R.layout.simple_spinner_dropdown_item, catNames);
        spinnerCategory.setAdapter(catAdapter);
        spinnerCategory.setSelection(preselectedCatPos, false);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (suppressSpinnerEvents) return;
                Integer nextCat = (position == 0) ? null : dynamicCategories.get(position - 1).categoryId;
                if ((nextCat == null && selectedCategoryId != null)
                        || (nextCat != null && !nextCat.equals(selectedCategoryId))) {
                    selectedCategoryId = nextCat;
                    fetchResearchPage(1);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        dynamicYears.clear();
        List<String> yearLabels = new ArrayList<>();
        yearLabels.add(getString(R.string.all_years));
        if (filters.years != null) {
            for (Integer y : filters.years) {
                if (y != null && y > 0) {
                    dynamicYears.add(y);
                    yearLabels.add(String.valueOf(y));
                }
            }
        }

        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(
                requireContext(), android.R.layout.simple_spinner_dropdown_item, yearLabels);
        spinnerYear.setAdapter(yearAdapter);
        spinnerYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (suppressSpinnerEvents) return;
                Integer nextYear = (position == 0) ? null : dynamicYears.get(position - 1);
                if ((nextYear == null && selectedYear != null)
                        || (nextYear != null && !nextYear.equals(selectedYear))) {
                    selectedYear = nextYear;
                    fetchResearchPage(1);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        suppressSpinnerEvents = false;
    }

    private void setupSearchListeners() {
        btnClearSearch.setOnClickListener(v -> {
            etSearch.setText("");
            suggestionsCard.setVisibility(View.GONE);
            currentQuery = "";
            fetchResearchPage(1);
        });

        btnDoSearch.setOnClickListener(v -> {
            suggestionsCard.setVisibility(View.GONE);
            currentQuery = etSearch.getText() != null ? etSearch.getText().toString().trim() : "";
            fetchResearchPage(1);
        });

        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                suggestionsCard.setVisibility(View.GONE);
                currentQuery = etSearch.getText().toString().trim();
                fetchResearchPage(1);
                return true;
            }
            return false;
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString().trim();
                btnClearSearch.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);

                if (searchRunnable != null) {
                    searchHandler.removeCallbacks(searchRunnable);
                }
                searchRunnable = () -> {
                    currentQuery = text;
                    fetchResearchPage(1);
                    if (text.length() >= 2) {
                        fetchSuggestions(text);
                    } else {
                        suggestionsCard.setVisibility(View.GONE);
                    }
                };
                searchHandler.postDelayed(searchRunnable, 350L);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void fetchSuggestions(String query) {
        ApiClient.getService(requireContext()).getSuggestions(query).enqueue(new Callback<List<String>>() {
            @Override
            public void onResponse(@NonNull Call<List<String>> call,
                                   @NonNull Response<List<String>> response) {
                if (!isAdded()) return;
                if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                    suggestionList.clear();
                    suggestionList.addAll(response.body());
                    suggestionAdapter.notifyDataSetChanged();
                    suggestionsCard.setVisibility(View.VISIBLE);
                } else {
                    suggestionsCard.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<String>> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                suggestionsCard.setVisibility(View.GONE);
            }
        });
    }

    private void fetchResearchPage(int page) {
        progressBar.setVisibility(View.VISIBLE);
        layoutSearchError.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.GONE);

        updateClearFiltersVisibility();

        ApiClient.getService(requireContext())
                .getResearchList(
                        currentQuery.isEmpty() ? null : currentQuery,
                        selectedCategoryId,
                        selectedYear,
                        selectedSort,
                        page,
                        10
                )
                .enqueue(new Callback<ApiResponse<List<Research>>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<List<Research>>> call,
                                           @NonNull Response<ApiResponse<List<Research>>> response) {
                        if (!isAdded()) return;
                        progressBar.setVisibility(View.GONE);

                        if (response.isSuccessful() && response.body() != null && response.body().success) {
                            ApiResponse<List<Research>> body = response.body();
                            populateDynamicFilterSpinners(body.filters);

                            researchList.clear();
                            if (body.data != null) {
                                researchList.addAll(body.data);
                            }
                            researchAdapter.notifyDataSetChanged();

                            currentPage = (body.meta != null) ? body.meta.page : page;
                            int total = (body.meta != null) ? body.meta.total : researchList.size();
                            totalPages = (body.meta != null) ? Math.max(1, body.meta.totalPages) : 1;

                            tvTotalCountBadge.setText(String.valueOf(total));
                            tvCount.setText(String.format(
                                    Locale.US,
                                    "Showing %d of %d approved %s",
                                    researchList.size(),
                                    total,
                                    total == 1 ? "record" : "records"
                            ));

                            if (totalPages > 1) {
                                layoutPagination.setVisibility(View.VISIBLE);
                                tvPageIndicator.setText("Page " + currentPage + " of " + totalPages);
                                btnPrevPage.setEnabled(currentPage > 1);
                                btnNextPage.setEnabled(currentPage < totalPages);
                            } else {
                                layoutPagination.setVisibility(View.GONE);
                            }

                            if (researchList.isEmpty()) {
                                layoutEmpty.setVisibility(View.VISIBLE);
                                tvEmpty.setText("No approved research matched your search or filter criteria.");
                            } else {
                                layoutEmpty.setVisibility(View.GONE);
                            }
                        } else {
                            Type listType = new TypeToken<List<Research>>() {}.getType();
                            ApiResponse<List<Research>> err = StudyVaultRepository.parseErrorResponse(
                                    response, listType);
                            if (StudyVaultRepository.isAuthExpired(response, err)
                                    && getActivity() instanceof MainActivity) {
                                ((MainActivity) getActivity()).handleSessionExpired(err != null ? err.message : null);
                                return;
                            }
                            showError(err != null && err.message != null
                                    ? err.message : "Failed to load research archive.");
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<List<Research>>> call, @NonNull Throwable t) {
                        if (!isAdded()) return;
                        progressBar.setVisibility(View.GONE);
                        showError(getString(R.string.error_network));
                    }
                });
    }

    private void resetAllFilters() {
        suppressSpinnerEvents = true;
        currentQuery = "";
        selectedCategoryId = null;
        selectedYear = null;
        selectedSort = "recent";
        tvSort.setText(getString(R.string.sort_recent) + " ▾");
        etSearch.setText("");
        suggestionsCard.setVisibility(View.GONE);
        if (spinnerCategory.getAdapter() != null && spinnerCategory.getAdapter().getCount() > 0) {
            spinnerCategory.setSelection(0, false);
        }
        if (spinnerYear.getAdapter() != null && spinnerYear.getAdapter().getCount() > 0) {
            spinnerYear.setSelection(0, false);
        }
        suppressSpinnerEvents = false;
        fetchResearchPage(1);
    }

    private void updateClearFiltersVisibility() {
        boolean hasFilters = !currentQuery.isEmpty()
                || selectedCategoryId != null
                || selectedYear != null
                || !"recent".equals(selectedSort);
        tvClearFilters.setVisibility(hasFilters ? View.VISIBLE : View.GONE);
    }

    private void showError(String message) {
        layoutSearchError.setVisibility(View.VISIBLE);
        tvSearchError.setText(message);
    }
}
