package com.example.studyvault.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.studyvault.adapters.ResearchAdapter;
import com.example.studyvault.adapters.SuggestionAdapter;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.databinding.FragmentSearchBinding;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.Research;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchFragment extends Fragment {

    private FragmentSearchBinding binding;
    private ResearchAdapter adapter;
    private SuggestionAdapter suggestionAdapter;

    private String selectedYear = null;
    private Integer selectedCategoryId = null;
    private boolean isNewestFirst = true;

    private List<Research> currentResults = new ArrayList<>();

    private final Handler searchHandler = new Handler(Looper.getMainLooper());
    private Runnable suggestionRunnable;

    private static final int SUGGEST_DELAY = 200;

    private final String[] years = {"All Years", "2025", "2024", "2023", "2022"};

    private final String[] categories = {
            "All Categories",
            "Web and Mobile App Dev",
            "Networking Security"
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentSearchBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        // Results adapter
        adapter = new ResearchAdapter(new ArrayList<>(), requireContext());
        binding.rvResults.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvResults.setAdapter(adapter);

        // Suggestions adapter
        suggestionAdapter = new SuggestionAdapter(new ArrayList<>(), suggestion -> {
            binding.etSearch.setText(suggestion);
            binding.etSearch.setSelection(suggestion.length());
            hideSuggestions();
            doSearch();
        });
        binding.rvSuggestions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvSuggestions.setAdapter(suggestionAdapter);

        setupFilters();

        // Keyboard Search
        binding.etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                hideSuggestions();
                doSearch();
                return true;
            }
            return false;
        });

        // Typing → suggestions only
        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().trim();

                searchHandler.removeCallbacks(suggestionRunnable);

                if (query.isEmpty()) {
                    hideSuggestions();
                    doSearch();
                    return;
                }

                suggestionRunnable = () -> loadSuggestions(query);
                searchHandler.postDelayed(suggestionRunnable, SUGGEST_DELAY);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        binding.tvSort.setOnClickListener(v -> toggleSort());
        binding.rvResults.setOnClickListener(v -> hideSuggestions());

        handleArguments();
    }

    private void loadSuggestions(String query) {
        if (binding == null || query.length() < 1) {
            hideSuggestions();
            return;
        }

        ApiClient.getService().getSuggestions(query)
                .enqueue(new Callback<List<String>>() {
                    @Override
                    public void onResponse(Call<List<String>> call,
                                           Response<List<String>> response) {
                        if (binding == null) return;

                        if (response.isSuccessful() && response.body() != null
                                && !response.body().isEmpty()) {
                            suggestionAdapter = new SuggestionAdapter(
                                    response.body(),
                                    suggestion -> {
                                        binding.etSearch.setText(suggestion);
                                        binding.etSearch.setSelection(suggestion.length());
                                        hideSuggestions();
                                        doSearch();
                                    });
                            binding.rvSuggestions.setAdapter(suggestionAdapter);
                            binding.suggestionsCard.setVisibility(View.VISIBLE);
                        } else {
                            hideSuggestions();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<String>> call, Throwable t) {
                        hideSuggestions();
                    }
                });
    }

    private void hideSuggestions() {
        if (binding != null) {
            binding.suggestionsCard.setVisibility(View.GONE);
        }
    }

    private void toggleSort() {
        isNewestFirst = !isNewestFirst;
        binding.tvSort.setText(isNewestFirst ? "Newest First ▾" : "Oldest First ▾");

        if (currentResults.isEmpty()) return;

        List<Research> sorted = new ArrayList<>(currentResults);
        Collections.sort(sorted, (a, b) -> isNewestFirst
                ? Integer.compare(b.year, a.year)
                : Integer.compare(a.year, b.year));

        adapter.setData(sorted);
    }

    private void handleArguments() {
        if (getArguments() == null) return;

        String query = getArguments().getString("search_query", "");
        int categoryId = getArguments().getInt("category_id", 0);

        if (categoryId > 0 && categoryId <= 2) {
            binding.spinnerCategory.setSelection(categoryId);
            selectedCategoryId = categoryId;
        }

        if (query != null && !query.isEmpty()) {
            binding.etSearch.setText(query);
        }

        // Initial search trigger (delayed para tapos muna setup)
        binding.getRoot().postDelayed(() -> doSearch(), 300);
    }

    // ============================================================
    // SPINNERS — AUTO-SEARCH pagka-pili
    // ============================================================
    private void setupFilters() {
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<String>(
                requireContext(), android.R.layout.simple_spinner_item, years) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) {
                    ((TextView) v).setTextColor(Color.parseColor("#15251D"));
                    ((TextView) v).setTextSize(12);
                }
                return v;
            }
        };
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerYear.setAdapter(yearAdapter);
        binding.spinnerYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                selectedYear = pos == 0 ? null : years[pos];
                doSearch();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {}
        });

        ArrayAdapter<String> catAdapter = new ArrayAdapter<String>(
                requireContext(), android.R.layout.simple_spinner_item, categories) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) {
                    ((TextView) v).setTextColor(Color.parseColor("#15251D"));
                    ((TextView) v).setTextSize(11);
                }
                return v;
            }
        };
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerCategory.setAdapter(catAdapter);
        binding.spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                selectedCategoryId = pos == 0 ? null : pos;
                doSearch();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {}
        });
    }

    // ============================================================
    // SEARCH
    // ============================================================
    private void doSearch() {
        if (binding == null) return;

        String combinedQuery = binding.etSearch.getText().toString().trim();

        binding.progress.setVisibility(View.VISIBLE);
        binding.tvEmpty.setVisibility(View.GONE);
        binding.tvCount.setText("Showing 0 results");

        Integer yearInt = selectedYear != null ? Integer.parseInt(selectedYear) : null;
        String queryParam = combinedQuery.isEmpty() ? null : combinedQuery;

        ApiClient.getService().getResearchList(queryParam, selectedCategoryId, yearInt)
                .enqueue(new Callback<ApiResponse<List<Research>>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<List<Research>>> call,
                                           Response<ApiResponse<List<Research>>> response) {
                        if (binding == null) return;
                        binding.progress.setVisibility(View.GONE);

                        if (response.isSuccessful() && response.body() != null
                                && response.body().data != null) {

                            List<Research> list = response.body().data;

                            if (list.isEmpty()) {
                                currentResults = new ArrayList<>();
                                binding.tvCount.setText("Showing 0 results");
                                binding.tvEmpty.setVisibility(View.VISIBLE);
                                adapter.setData(new ArrayList<>());
                            } else {
                                List<Research> sorted = new ArrayList<>(list);
                                Collections.sort(sorted, (a, b) -> isNewestFirst
                                        ? Integer.compare(b.year, a.year)
                                        : Integer.compare(a.year, b.year));

                                currentResults = sorted;
                                binding.tvCount.setText("Showing " + list.size() + " results");
                                binding.tvEmpty.setVisibility(View.GONE);
                                adapter.setData(sorted);
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<List<Research>>> call, Throwable t) {
                        if (binding == null) return;
                        binding.progress.setVisibility(View.GONE);
                    }
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}