package com.example.studyvault.repository;

import android.content.Context;

import com.example.studyvault.api.ApiClient;
import com.example.studyvault.api.ApiService;
import com.example.studyvault.models.ApiResponse;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;

import okhttp3.ResponseBody;
import retrofit2.Response;

/**
 * Data access & API communication helper separating networking details and error
 * body parsing from UI components.
 */
public class StudyVaultRepository {

    private final ApiService service;
    private static final Gson GSON = new Gson();

    public StudyVaultRepository(Context context) {
        ApiClient.init(context);
        this.service = ApiClient.getService(context);
    }

    public ApiService getService() {
        return service;
    }

    /**
     * Parses an unsuccessful HTTP response (400/401/403/404/409/429/500) into an ApiResponse
     * so the exact server-side validation message and error code are preserved.
     */
    public static <T> ApiResponse<T> parseErrorResponse(Response<ApiResponse<T>> response, Type dataType) {
        if (response != null && response.body() != null) {
            return response.body();
        }
        ApiResponse<T> fallback = new ApiResponse<>();
        fallback.success = false;

        if (response != null && response.errorBody() != null) {
            try {
                ResponseBody errBody = response.errorBody();
                String raw = errBody.string();
                if (raw != null && !raw.trim().isEmpty()) {
                    Type type = dataType != null
                            ? TypeToken.getParameterized(ApiResponse.class, dataType).getType()
                            : new TypeToken<ApiResponse<Object>>() {}.getType();
                    ApiResponse<T> parsed = GSON.fromJson(raw, type);
                    if (parsed != null && (parsed.message != null || parsed.code != null)) {
                        return parsed;
                    }
                }
            } catch (Exception ignored) {
            }
        }

        if (response != null) {
            int code = response.code();
            if (code == 401) {
                fallback.code = "unauthenticated";
                fallback.message = "Your session has expired. Please sign in again.";
            } else if (code == 403) {
                fallback.code = "forbidden";
                fallback.message = "You do not have permission to perform this action.";
            } else if (code == 404) {
                fallback.code = "not_found";
                fallback.message = "The requested record was not found.";
            } else if (code == 429) {
                fallback.code = "throttled";
                fallback.message = "Too many attempts. Please wait a moment and try again.";
            } else {
                fallback.message = "Request could not be completed (HTTP " + code + ").";
            }
        } else {
            fallback.message = "Unable to reach the Study Vault server.";
        }
        return fallback;
    }

    public static boolean isAuthExpired(Response<?> response, ApiResponse<?> parsed) {
        if (response != null && response.code() == 401) {
            return true;
        }
        if (parsed != null && parsed.code != null) {
            return "unauthenticated".equals(parsed.code)
                    || "session_expired".equals(parsed.code)
                    || "account_inactive".equals(parsed.code);
        }
        return false;
    }
}
