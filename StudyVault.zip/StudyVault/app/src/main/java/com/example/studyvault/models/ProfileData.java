package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class ProfileData implements Serializable {
    @SerializedName("student")
    public Student student;

    @SerializedName("has_full_access")
    public boolean hasFullAccess;

    @SerializedName("active_subscription")
    public Subscription activeSubscription;

    @SerializedName("subscriptions")
    public List<Subscription> subscriptions;
}
