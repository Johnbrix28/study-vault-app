package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class PlansData implements Serializable {
    @SerializedName("plans")
    public List<AccessPlan> plans;

    @SerializedName("has_full_access")
    public boolean hasFullAccess;

    @SerializedName("active_subscription")
    public Subscription activeSubscription;

    @SerializedName("expired_subscription")
    public Subscription expiredSubscription;

    @SerializedName("payment_mode")
    public String paymentMode;

    @SerializedName("demo_notice")
    public String demoNotice;
}
