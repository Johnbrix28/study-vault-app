package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Subscription implements Serializable {
    @SerializedName("subscription_id")
    public int subscriptionId;

    @SerializedName("plan_id")
    public int planId;

    @SerializedName("plan_name")
    public String planName;

    @SerializedName("status")
    public String status;

    @SerializedName("reference_code")
    public String referenceCode;

    @SerializedName("amount_paid")
    public double amountPaid;

    @SerializedName("amount_formatted")
    public String amountFormatted;

    @SerializedName("payment_mode")
    public String paymentMode;

    @SerializedName("duration_days")
    public int durationDays;

    @SerializedName("start_date")
    public String startDate;

    @SerializedName("start_date_formatted")
    public String startDateFormatted;

    @SerializedName("expiration_date")
    public String expirationDate;

    @SerializedName("expiration_date_formatted")
    public String expirationDateFormatted;
}
