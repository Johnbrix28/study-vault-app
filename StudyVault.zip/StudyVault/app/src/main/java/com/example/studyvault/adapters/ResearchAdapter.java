package com.example.studyvault.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.R;
import com.example.studyvault.activities.ResearchDetailActivity;
import com.example.studyvault.models.Research;

import java.util.List;

/**
 * Adapter rendering approved research cards matching includes/research-card.php.
 */
public class ResearchAdapter extends RecyclerView.Adapter<ResearchAdapter.ViewHolder> {

    private final Context context;
    private final List<Research> list;

    public ResearchAdapter(Context context, List<Research> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_research, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Research r = list.get(position);

        holder.tvTitle.setText(r.title != null ? r.title : "Untitled Research");
        holder.tvCategory.setText(r.categoryName != null && !r.categoryName.isEmpty()
                ? r.categoryName : "Uncategorized");
        holder.tvYear.setText(r.year > 0 ? String.valueOf(r.year) : "N/A");

        String authors = (r.researchers != null && !r.researchers.trim().isEmpty())
                ? "By " + r.researchers.trim()
                : "Researchers not listed";
        holder.tvAuthors.setText(authors);

        String preview = (r.excerpt != null && !r.excerpt.trim().isEmpty())
                ? r.excerpt.trim()
                : (r.abstractText != null ? r.abstractText.trim() : "");
        holder.tvAbstract.setText(preview);

        if (r.hasManuscript) {
            holder.tvTagType.setText(R.string.manuscript_available);
            holder.tvTagType.setBackgroundResource(R.drawable.bg_badge_green);
            holder.tvTagType.setTextColor(ContextCompat.getColor(context, R.color.sv_green));
        } else {
            holder.tvTagType.setText(R.string.abstract_only);
            holder.tvTagType.setBackgroundResource(R.drawable.bg_badge_amber);
            holder.tvTagType.setTextColor(ContextCompat.getColor(context, R.color.sv_amber));
        }

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ResearchDetailActivity.class);
            intent.putExtra("research_id", r.researchId);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return list != null ? list.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView tvTitle;
        final TextView tvAuthors;
        final TextView tvYear;
        final TextView tvCategory;
        final TextView tvAbstract;
        final TextView tvTagType;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvAuthors = itemView.findViewById(R.id.tvAuthors);
            tvYear = itemView.findViewById(R.id.tvYear);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvAbstract = itemView.findViewById(R.id.tvAbstract);
            tvTagType = itemView.findViewById(R.id.tvTagType);
        }
    }
}
