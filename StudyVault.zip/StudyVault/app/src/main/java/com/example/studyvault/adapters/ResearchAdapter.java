package com.example.studyvault.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.activities.ResearchDetailActivity;
import com.example.studyvault.databinding.ItemResearchBinding;
import com.example.studyvault.models.Research;

import java.util.List;

public class ResearchAdapter extends RecyclerView.Adapter<ResearchAdapter.VH> {

    private final List<Research> data;
    private final Context context;

    public ResearchAdapter(List<Research> data, Context context) {
        this.data = data;
        this.context = context;
    }

    public void setData(List<Research> newData) {
        data.clear();
        data.addAll(newData);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemResearchBinding binding = ItemResearchBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new VH(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Research r = data.get(position);

        holder.binding.tvTitle.setText(r.title);
        holder.binding.tvAuthors.setText(r.researchers != null ? r.researchers : "Not recorded");
        holder.binding.tvYear.setText(String.valueOf(r.year));
        holder.binding.tvCategory.setText(r.categoryName != null ? r.categoryName : "Uncategorized");
        holder.binding.tvTagType.setText("Thesis");

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ResearchDetailActivity.class);
            intent.putExtra("research", r);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final ItemResearchBinding binding;
        VH(ItemResearchBinding b) { super(b.getRoot()); binding = b; }
    }
}