package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class RelatedResearch implements Serializable {
    @SerializedName("research_id")   public int researchId;
    @SerializedName("title")         public String title;
    @SerializedName("year")          public int year;
    @SerializedName("category_name") public String categoryName;
}