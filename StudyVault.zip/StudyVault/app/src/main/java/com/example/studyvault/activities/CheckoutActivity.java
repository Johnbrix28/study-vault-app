package com.example.studyvault.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.studyvault.R;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.AccessPlan;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.Subscription;
import com.example.studyvault.repository.StudyVaultRepository;
import com.example.studyvault.utils.SessionManager;
import com.google.android.material.button.MaterialButton;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Prototype / Demonstration Checkout Screen matching study-vault/checkout.php and api/checkout.php.
 */
public class CheckoutActivity extends AppCompatActivity {

    private ImageView btnBackCheckout;
    private LinearLayout layoutCheckoutForm;
    private TextView tvCheckoutPlanName;
    private TextView tvReceiptPlan;
    private TextView tvReceiptDuration;
    private TextView tvReceiptPrice;
    private CheckBox cbConfirmDemo;
    private TextView tvCheckoutError;
    private MaterialButton btnCancelCheckout;
    private MaterialButton btnActivateDemoPlan;
    private ProgressBar progressCheckout;

    private LinearLayout layoutCheckoutSuccess;
    private TextView tvActivatedSummary;
    private TextView tvActivatedRefCode;
    private TextView tvActivatedStart;
    private TextView tvActivatedExpires;
    private MaterialButton btnCheckoutBrowseResearch;
    private MaterialButton btnCheckoutViewProfile;

    private SessionManager session;
    private AccessPlan selectedPlan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        ApiClient.init(this);
        session = new SessionManager(this);

        bindViews();
        btnBackCheckout.setOnClickListener(v -> finish());
        btnCancelCheckout.setOnClickListener(v -> finish());

        Object extra = getIntent().getSerializableExtra("access_plan");
        if (extra instanceof AccessPlan) {
            selectedPlan = (AccessPlan) extra;
        }

        if (selectedPlan == null || selectedPlan.planId <= 0 || selectedPlan.isFree) {
            Toast.makeText(this, "Please select a valid paid access plan.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        populatePlanDetails(selectedPlan);
        btnActivateDemoPlan.setOnClickListener(v -> submitDemoActivation());

        btnCheckoutBrowseResearch.setOnClickListener(v -> {
            setResult(RESULT_OK);
            Intent intent = new Intent(CheckoutActivity.this, MainActivity.class);
            intent.putExtra("open_tab", "search");
            startActivity(intent);
            finish();
        });

        btnCheckoutViewProfile.setOnClickListener(v -> {
            setResult(RESULT_OK);
            Intent intent = new Intent(CheckoutActivity.this, MainActivity.class);
            intent.putExtra("open_tab", "profile");
            startActivity(intent);
            finish();
        });
    }

    private void bindViews() {
        btnBackCheckout = findViewById(R.id.btnBackCheckout);
        layoutCheckoutForm = findViewById(R.id.layoutCheckoutForm);
        tvCheckoutPlanName = findViewById(R.id.tvCheckoutPlanName);
        tvReceiptPlan = findViewById(R.id.tvReceiptPlan);
        tvReceiptDuration = findViewById(R.id.tvReceiptDuration);
        tvReceiptPrice = findViewById(R.id.tvReceiptPrice);
        cbConfirmDemo = findViewById(R.id.cbConfirmDemo);
        tvCheckoutError = findViewById(R.id.tvCheckoutError);
        btnCancelCheckout = findViewById(R.id.btnCancelCheckout);
        btnActivateDemoPlan = findViewById(R.id.btnActivateDemoPlan);
        progressCheckout = findViewById(R.id.progressCheckout);

        layoutCheckoutSuccess = findViewById(R.id.layoutCheckoutSuccess);
        tvActivatedSummary = findViewById(R.id.tvActivatedSummary);
        tvActivatedRefCode = findViewById(R.id.tvActivatedRefCode);
        tvActivatedStart = findViewById(R.id.tvActivatedStart);
        tvActivatedExpires = findViewById(R.id.tvActivatedExpires);
        btnCheckoutBrowseResearch = findViewById(R.id.btnCheckoutBrowseResearch);
        btnCheckoutViewProfile = findViewById(R.id.btnCheckoutViewProfile);
    }

    private void populatePlanDetails(AccessPlan plan) {
        String name = plan.planName != null ? plan.planName : "Research Access";
        String price = plan.priceFormatted != null ? plan.priceFormatted : "₱99";
        tvCheckoutPlanName.setText(name);
        tvReceiptPlan.setText(name);
        tvReceiptDuration.setText(plan.durationDays + " days");
        tvReceiptPrice.setText(price);
        btnActivateDemoPlan.setText("Activate Plan (Demo)");
    }

    private void submitDemoActivation() {
        tvCheckoutError.setVisibility(View.GONE);

        if (!cbConfirmDemo.isChecked()) {
            showError("Please check the confirmation box to continue with the demo checkout.");
            return;
        }

        btnActivateDemoPlan.setEnabled(false);
        progressCheckout.setVisibility(View.VISIBLE);

        ApiClient.getService(this)
                .activateDemoPlan(selectedPlan.planId, 1)
                .enqueue(new Callback<ApiResponse<Subscription>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<Subscription>> call,
                                           @NonNull Response<ApiResponse<Subscription>> response) {
                        progressCheckout.setVisibility(View.GONE);

                        if (response.isSuccessful() && response.body() != null
                                && response.body().success && response.body().data != null) {
                            ApiResponse<Subscription> body = response.body();
                            Subscription sub = body.data;

                            session.updateSubscriptionStatus(true, sub);
                            setResult(RESULT_OK);

                            layoutCheckoutForm.setVisibility(View.GONE);
                            layoutCheckoutSuccess.setVisibility(View.VISIBLE);

                            tvActivatedSummary.setText(body.message != null
                                    ? body.message
                                    : selectedPlan.planName + " is now active on your account.");
                            tvActivatedRefCode.setText(sub.referenceCode != null ? sub.referenceCode : "—");
                            tvActivatedStart.setText(sub.startDateFormatted != null
                                    ? sub.startDateFormatted : sub.startDate);
                            tvActivatedExpires.setText(sub.expirationDateFormatted != null
                                    ? sub.expirationDateFormatted : sub.expirationDate);
                        } else {
                            btnActivateDemoPlan.setEnabled(true);
                            ApiResponse<Subscription> err = StudyVaultRepository.parseErrorResponse(
                                    response, Subscription.class);
                            showError(err != null && err.message != null
                                    ? err.message : "Could not activate plan.");
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<Subscription>> call, @NonNull Throwable t) {
                        progressCheckout.setVisibility(View.GONE);
                        btnActivateDemoPlan.setEnabled(true);
                        showError(getString(R.string.error_network));
                    }
                });
    }

    private void showError(String message) {
        tvCheckoutError.setText(message);
        tvCheckoutError.setVisibility(View.VISIBLE);
    }
}
