package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;

public class Student {
    @SerializedName("student_id")     public int studentId;
    @SerializedName("student_number") public String studentNumber;
    @SerializedName("first_name")     public String firstName;
    @SerializedName("last_name")      public String lastName;
    @SerializedName("name")           public String fullName;
}