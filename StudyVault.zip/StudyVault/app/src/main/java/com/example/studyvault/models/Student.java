package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Student implements Serializable {
    @SerializedName("student_id")
    public int studentId;

    @SerializedName("student_number")
    public String studentNumber;

    @SerializedName("full_name")
    public String fullName;

    @SerializedName("email")
    public String email;

    @SerializedName("user_type")
    public String userType;

    @SerializedName("user_type_label")
    public String userTypeLabel;

    @SerializedName("program_id")
    public Integer programId;

    @SerializedName("program_name")
    public String programName;

    @SerializedName("status")
    public String status;

    @SerializedName("verification_status")
    public String verificationStatus;

    @SerializedName("graduation_year")
    public Integer graduationYear;

    @SerializedName("created_at")
    public String createdAt;

    @SerializedName("created_at_formatted")
    public String createdAtFormatted;

    @SerializedName("has_full_access")
    public boolean hasFullAccess;

    @SerializedName("subscription")
    public Subscription subscription;

    @SerializedName("token")
    public String token;
}
