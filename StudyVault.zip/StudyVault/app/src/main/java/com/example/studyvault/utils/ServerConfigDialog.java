package com.example.studyvault.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.studyvault.api.ApiClient;

/**
 * Dialog that lets students/developers configure the XAMPP backend URL
 * when switching between Android Emulator (10.0.2.2) and a physical Android phone on LAN.
 */
public final class ServerConfigDialog {

    private ServerConfigDialog() {}

    public static void show(Context context) {
        SessionManager session = new SessionManager(context);

        LinearLayout container = new LinearLayout(context);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * context.getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad / 2, pad, 0);

        TextView helper = new TextView(context);
        helper.setText(
                "• Android Emulator (XAMPP on PC):\n  " + SessionManager.EMULATOR_BASE_URL + "\n\n" +
                "• Physical Phone on Wi-Fi LAN:\n  http://<Your-PC-LAN-IP>/study-vault/api/\n  (e.g. " + SessionManager.DEFAULT_LAN_BASE_URL + ")"
        );
        helper.setTextSize(12f);
        container.addView(helper);

        EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(session.getBaseUrl());
        input.setSelection(input.getText().length());
        container.addView(input);

        new AlertDialog.Builder(context)
                .setTitle("Server Connection (XAMPP)")
                .setView(container)
                .setPositiveButton("Save", (d, which) -> {
                    String entered = input.getText().toString().trim();
                    session.setBaseUrl(entered);
                    ApiClient.resetClient();
                    Toast.makeText(context, "Server URL updated: " + session.getBaseUrl(), Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("Use Emulator (10.0.2.2)", (d, which) -> {
                    session.setBaseUrl(SessionManager.EMULATOR_BASE_URL);
                    ApiClient.resetClient();
                    Toast.makeText(context, "Set to Emulator: " + SessionManager.EMULATOR_BASE_URL, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
