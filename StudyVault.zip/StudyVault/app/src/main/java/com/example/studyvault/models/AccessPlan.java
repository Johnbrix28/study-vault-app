package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class AccessPlan implements Serializable {
    @SerializedName("plan_id")
    public int planId;

    @SerializedName("plan_name")
    public String planName;

    @SerializedName("description")
    public String description;

    @SerializedName("price")
    public double price;

    @SerializedName("price_formatted")
    public String priceFormatted;

    @SerializedName("duration_days")
    public int durationDays;

    @SerializedName("full_access")
    public boolean fullAccess;

    @SerializedName("is_free")
    public boolean isFree;

    @SerializedName("is_current")
    public boolean isCurrent;

    @SerializedName("is_featured")
    public boolean isFeatured;

    @SerializedName("sort_order")
    public int sortOrder;

    @SerializedName("features")
    public List<String> features;
}
