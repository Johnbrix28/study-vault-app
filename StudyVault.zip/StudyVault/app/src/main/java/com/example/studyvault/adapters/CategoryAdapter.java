package com.example.studyvault.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.databinding.ItemCategoryBinding;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.VH> {

    public static class CategoryItem {
        public int id;
        public String name;
        public int count;

        public CategoryItem(int id, String name, int count) {
            this.id = id;
            this.name = name;
            this.count = count;
        }
    }

    public interface OnCategoryClick {
        void onClick(CategoryItem item);
    }

    private final List<CategoryItem> data;
    private final OnCategoryClick listener;

    public CategoryAdapter(List<CategoryItem> data, OnCategoryClick listener) {
        this.data = data;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemCategoryBinding binding = ItemCategoryBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new VH(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        CategoryItem item = data.get(position);

        holder.binding.tvCategoryName.setText(item.name);
        holder.binding.tvCategoryCount.setText(item.count + " record" + (item.count == 1 ? "" : "s"));

        // First letter as icon
        String initial = item.name.substring(0, 1).toUpperCase();
        holder.binding.tvCategoryInitial.setText(initial);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(item);
        });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final ItemCategoryBinding binding;
        VH(ItemCategoryBinding b) { super(b.getRoot()); binding = b; }
    }
}