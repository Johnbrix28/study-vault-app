package com.example.studyvault.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.R;
import com.example.studyvault.models.Category;

import java.util.List;
import java.util.Locale;

/**
 * Adapter rendering subject-area tiles matching index.php and categories.php.
 */
public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    public interface OnCategoryClickListener {
        void onCategoryClick(Category category);
    }

    private final Context context;
    private final List<Category> list;
    private final OnCategoryClickListener listener;

    public CategoryAdapter(Context context, List<Category> list, OnCategoryClickListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Category c = list.get(position);

        holder.tvInitial.setText(String.format(Locale.US, "%02d", position + 1));
        holder.tvName.setText(c.categoryName != null ? c.categoryName : "Subject Area");

        String desc = (c.description != null && !c.description.trim().isEmpty())
                ? c.description.trim()
                : "Approved studies and research works in this subject area.";
        holder.tvDesc.setText(desc);

        String countLabel = c.total + (c.total == 1 ? " record" : " records");
        holder.tvCount.setText(countLabel);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onCategoryClick(c);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list != null ? list.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView tvInitial;
        final TextView tvName;
        final TextView tvDesc;
        final TextView tvCount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvInitial = itemView.findViewById(R.id.tvCategoryInitial);
            tvName = itemView.findViewById(R.id.tvCategoryName);
            tvDesc = itemView.findViewById(R.id.tvCategoryDesc);
            tvCount = itemView.findViewById(R.id.tvCategoryCount);
        }
    }
}
