package com.example.studyvault.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.studyvault.R;
import com.example.studyvault.databinding.ActivityMainBinding;
import com.example.studyvault.fragments.HomeFragment;
import com.example.studyvault.fragments.ProfileFragment;
import com.example.studyvault.fragments.SearchFragment;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Load home initially
        if (savedInstanceState == null) {
            loadFragment(new HomeFragment());
        }

        binding.bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment fragment;

            if (id == R.id.nav_home) {
                fragment = new HomeFragment();
            } else if (id == R.id.nav_search) {
                fragment = new SearchFragment();
            } else {
                fragment = new ProfileFragment();
            }

            loadFragment(fragment);
            return true;
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }

    /**
     * Navigate to Search with a query — called from Home hero search
     */
    public void switchToSearchWithQuery(String query) {
        SearchFragment searchFragment = new SearchFragment();
        Bundle args = new Bundle();
        args.putString("search_query", query != null ? query : "");
        searchFragment.setArguments(args);

        // Update bottom nav selection WITHOUT triggering listener
        binding.bottomNav.setOnItemSelectedListener(null);
        binding.bottomNav.setSelectedItemId(R.id.nav_search);
        restoreBottomNavListener();

        // Now load the fragment
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, searchFragment)
                .commit();
    }

    /**
     * Navigate to Search with a category — called from Home category click
     */
    public void switchToSearchWithCategory(int categoryId) {
        SearchFragment searchFragment = new SearchFragment();
        Bundle args = new Bundle();
        args.putInt("category_id", categoryId);
        searchFragment.setArguments(args);

        // Update bottom nav selection WITHOUT triggering listener
        binding.bottomNav.setOnItemSelectedListener(null);
        binding.bottomNav.setSelectedItemId(R.id.nav_search);
        restoreBottomNavListener();

        // Now load the fragment
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, searchFragment)
                .commit();
    }

    /**
     * Re-attach the bottom nav listener after programmatic selection change
     */
    private void restoreBottomNavListener() {
        binding.bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment fragment;

            if (id == R.id.nav_home) {
                fragment = new HomeFragment();
            } else if (id == R.id.nav_search) {
                fragment = new SearchFragment();
            } else {
                fragment = new ProfileFragment();
            }

            loadFragment(fragment);
            return true;
        });
    }
}