package com.example.studyvault.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.studyvault.R;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.fragments.HomeFragment;
import com.example.studyvault.fragments.PlansFragment;
import com.example.studyvault.fragments.ProfileFragment;
import com.example.studyvault.fragments.SearchFragment;
import com.example.studyvault.utils.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Locale;

/**
 * Primary authenticated workspace with 4 bottom navigation destinations:
 * 1) Home
 * 2) Research Archive & Search
 * 3) Access Plans
 * 4) Profile
 */
public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private LinearLayout layoutUserPill;
    private TextView tvUserInitial;
    private TextView tvUserShortName;
    private SessionManager session;

    private String pendingSearchQuery = null;
    private int pendingCategoryId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ApiClient.init(this);
        session = new SessionManager(this);

        if (!session.isLoggedIn()) {
            redirectToLogin(null);
            return;
        }

        bottomNav = findViewById(R.id.bottomNav);
        layoutUserPill = findViewById(R.id.layoutUserPill);
        tvUserInitial = findViewById(R.id.tvUserInitial);
        tvUserShortName = findViewById(R.id.tvUserShortName);

        refreshTopBarUserPill();

        if (layoutUserPill != null) {
            layoutUserPill.setOnClickListener(v -> bottomNav.setSelectedItemId(R.id.nav_profile));
        }

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selected = null;
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                selected = new HomeFragment();
            } else if (id == R.id.nav_search) {
                SearchFragment sf = SearchFragment.newInstance(pendingSearchQuery, pendingCategoryId);
                pendingSearchQuery = null;
                pendingCategoryId = 0;
                selected = sf;
            } else if (id == R.id.nav_plans) {
                selected = new PlansFragment();
            } else if (id == R.id.nav_profile) {
                selected = new ProfileFragment();
            }

            if (selected != null) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentContainer, selected)
                        .commit();
                return true;
            }
            return false;
        });

        handleIncomingNavigationIntent(getIntent(), savedInstanceState == null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTopBarUserPill();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingNavigationIntent(intent, false);
    }

    public void refreshTopBarUserPill() {
        if (session == null) return;
        String name = session.getName();
        if (tvUserInitial != null) {
            String initial = (!name.isEmpty()) ? name.substring(0, 1).toUpperCase(Locale.US) : "S";
            tvUserInitial.setText(initial);
        }
        if (tvUserShortName != null) {
            String first = (!name.isEmpty()) ? name.split("\\s+")[0] : "Student";
            tvUserShortName.setText(first);
        }
    }

    private void handleIncomingNavigationIntent(Intent intent, boolean isInitialCreate) {
        if (intent != null) {
            String tab = intent.getStringExtra("open_tab");
            if ("plans".equalsIgnoreCase(tab)) {
                bottomNav.setSelectedItemId(R.id.nav_plans);
                return;
            } else if ("search".equalsIgnoreCase(tab)) {
                pendingSearchQuery = intent.getStringExtra("search_query");
                pendingCategoryId = intent.getIntExtra("category_id", 0);
                bottomNav.setSelectedItemId(R.id.nav_search);
                return;
            } else if ("profile".equalsIgnoreCase(tab)) {
                bottomNav.setSelectedItemId(R.id.nav_profile);
                return;
            }
        }
        if (isInitialCreate) {
            bottomNav.setSelectedItemId(R.id.nav_home);
        }
    }

    public void openSearchWithFilter(String query, int categoryId) {
        this.pendingSearchQuery = query;
        this.pendingCategoryId = categoryId;
        if (bottomNav != null) {
            bottomNav.setSelectedItemId(R.id.nav_search);
        }
    }

    public void openAccessPlans() {
        if (bottomNav != null) {
            bottomNav.setSelectedItemId(R.id.nav_plans);
        }
    }

    public void handleSessionExpired(String message) {
        if (session != null) {
            session.logout();
        }
        ApiClient.clearCookies();
        redirectToLogin(message != null ? message : getString(R.string.session_expired_msg));
    }

    private void redirectToLogin(String notice) {
        Intent intent = new Intent(this, LoginActivity.class);
        if (notice != null && !notice.isEmpty()) {
            intent.putExtra("login_notice", notice);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
