package com.example.studyvault.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.studyvault.api.ApiClient;
import com.example.studyvault.databinding.ActivityLoginBinding;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.utils.SessionManager;
import com.google.gson.internal.LinkedTreeMap;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        session = new SessionManager(this);

        binding.btnLogin.setOnClickListener(v -> doLogin());
        binding.tvRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void doLogin() {
        String number = binding.etStudentId.getText().toString().trim();
        String password = binding.etPassword.getText().toString().trim();

        if (number.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter Student ID and password", Toast.LENGTH_SHORT).show();
            return;
        }

        binding.progress.setVisibility(View.VISIBLE);
        binding.btnLogin.setEnabled(false);

        ApiClient.getService().login(number, password)
                .enqueue(new Callback<ApiResponse<Object>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Object>> call,
                                           Response<ApiResponse<Object>> response) {
                        binding.progress.setVisibility(View.GONE);
                        binding.btnLogin.setEnabled(true);

                        if (response.isSuccessful() && response.body() != null
                                && response.body().success) {

                            // Parse student data
                            int studentId = 0;
                            String studentNumber = number;
                            String firstName = "";
                            String lastName = "";
                            String fullName = "";

                            try {
                                if (response.body().data instanceof LinkedTreeMap) {
                                    LinkedTreeMap<?, ?> map = (LinkedTreeMap<?, ?>) response.body().data;

                                    Object idObj = map.get("student_id");
                                    Object numObj = map.get("student_number");
                                    Object fnObj = map.get("first_name");
                                    Object lnObj = map.get("last_name");
                                    Object nameObj = map.get("name");

                                    if (idObj != null) studentId = ((Number) idObj).intValue();
                                    if (numObj != null) studentNumber = numObj.toString();
                                    if (fnObj != null) firstName = fnObj.toString();
                                    if (lnObj != null) lastName = lnObj.toString();
                                    if (nameObj != null) fullName = nameObj.toString();
                                }
                            } catch (Exception e) {
                                // Fallback
                                fullName = "Student";
                            }

                            // Save full session
                            session.saveSession(studentId, studentNumber, firstName, lastName, "");

                            Toast.makeText(LoginActivity.this,
                                    "Welcome, " + fullName + "!",
                                    Toast.LENGTH_SHORT).show();

                            startActivity(new Intent(LoginActivity.this, MainActivity.class));
                            finish();
                        } else {
                            Toast.makeText(LoginActivity.this,
                                    "Invalid Student ID or password",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Object>> call, Throwable t) {
                        binding.progress.setVisibility(View.GONE);
                        binding.btnLogin.setEnabled(true);
                        Toast.makeText(LoginActivity.this,
                                "Network error: " + t.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }
}