package com.example.studyvault.activities;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.studyvault.R;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.Student;
import com.example.studyvault.repository.StudyVaultRepository;
import com.example.studyvault.utils.ServerConfigDialog;
import com.example.studyvault.utils.SessionManager;
import com.example.studyvault.utils.ValidationUtils;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Student & Alumni Login Screen matching study-vault/login.php and api/login.php.
 */
public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etStudentId;
    private TextInputEditText etPassword;
    private MaterialButton btnLogin;
    private ProgressBar progressBar;
    private TextView tvRegisterLink;
    private TextView tvAlertBanner;
    private TextView btnServerConfig;

    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ApiClient.init(this);
        session = new SessionManager(this);

        if (session.isLoggedIn()) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        etStudentId = findViewById(R.id.etStudentId);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        progressBar = findViewById(R.id.progress);
        tvRegisterLink = findViewById(R.id.tvRegister);
        tvAlertBanner = findViewById(R.id.tvAlertBanner);
        btnServerConfig = findViewById(R.id.btnServerConfig);

        Intent incoming = getIntent();
        if (incoming != null) {
            String prefillId = incoming.getStringExtra("prefill_student_id");
            if (prefillId != null && !prefillId.isEmpty()) {
                etStudentId.setText(prefillId);
                etPassword.requestFocus();
            }
            String notice = incoming.getStringExtra("login_notice");
            if (notice != null && !notice.isEmpty()) {
                showBanner(notice, false);
            }
        }

        btnLogin.setOnClickListener(v -> attemptLogin());

        tvRegisterLink.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, VerifyAccountActivity.class);
            String currentId = getTextValue(etStudentId);
            if (!currentId.isEmpty()) {
                intent.putExtra("prefill_student_id", currentId);
            }
            startActivity(intent);
        });

        btnServerConfig.setOnClickListener(v -> ServerConfigDialog.show(LoginActivity.this));
    }

    private void attemptLogin() {
        hideBanner();

        String studentId = ValidationUtils.normalizeStudentId(getTextValue(etStudentId));
        String password = etPassword.getText() != null ? etPassword.getText().toString() : "";

        if (studentId.isEmpty()) {
            etStudentId.setError("Please enter your Student ID.");
            etStudentId.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            etPassword.setError("Please enter your password.");
            etPassword.requestFocus();
            return;
        }

        setLoading(true);
        String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

        ApiClient.getService(this)
                .login(studentId, password, deviceName)
                .enqueue(new Callback<ApiResponse<Student>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<Student>> call,
                                           @NonNull Response<ApiResponse<Student>> response) {
                        setLoading(false);

                        if (response.isSuccessful() && response.body() != null && response.body().success) {
                            ApiResponse<Student> body = response.body();
                            Student student = body.data;
                            String token = body.token != null ? body.token : (student != null ? student.token : "");

                            if (student == null || !"approved".equalsIgnoreCase(student.status)) {
                                showBanner("Your account is not yet approved for sign-in.", true);
                                return;
                            }

                            session.saveStudentSession(student, token);
                            Toast.makeText(LoginActivity.this,
                                    "Welcome back, " + student.fullName + "!", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();
                        } else {
                            ApiResponse<Student> err = StudyVaultRepository.parseErrorResponse(
                                    response, Student.class);
                            String msg = (err != null && err.message != null && !err.message.isEmpty())
                                    ? err.message
                                    : "Invalid Student ID or password.";
                            boolean isWarning = err != null && "pending_approval".equals(err.code);
                            showBanner(msg, !isWarning);
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<Student>> call, @NonNull Throwable t) {
                        setLoading(false);
                        showBanner(
                                getString(R.string.error_network) + "\nCurrent URL: " + session.getBaseUrl(),
                                true
                        );
                    }
                });
    }

    private void setLoading(boolean loading) {
        btnLogin.setEnabled(!loading);
        btnLogin.setText(loading ? R.string.signing_in : R.string.sign_in_btn);
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
    }

    private void showBanner(String message, boolean isError) {
        if (tvAlertBanner == null) return;
        tvAlertBanner.setText(message);
        tvAlertBanner.setBackgroundResource(isError ? R.drawable.bg_badge_red : R.drawable.bg_badge_amber);
        tvAlertBanner.setTextColor(ContextCompat.getColor(this,
                isError ? R.color.sv_red : R.color.sv_amber));
        tvAlertBanner.setVisibility(View.VISIBLE);
    }

    private void hideBanner() {
        if (tvAlertBanner != null) {
            tvAlertBanner.setVisibility(View.GONE);
        }
    }

    private static String getTextValue(TextInputEditText editText) {
        return editText != null && editText.getText() != null
                ? editText.getText().toString().trim()
                : "";
    }
}
