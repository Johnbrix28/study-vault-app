package com.example.studyvault.activities;

import android.content.Intent;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studyvault.R;
import com.example.studyvault.adapters.ManuscriptPageAdapter;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.ManuscriptMeta;
import com.example.studyvault.repository.StudyVaultRepository;
import com.example.studyvault.utils.SessionManager;
import com.example.studyvault.utils.WatermarkOverlayView;
import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Protected Native Manuscript Viewer matching study-vault/view-manuscript.php & secure-document.php:
 * - Enforces WindowManager.LayoutParams.FLAG_SECURE (blocks screenshots & screen recording)
 * - Verifies authentication, account approval, and active subscription on the server for every load
 * - Streams PDF bytes privately into internal cache (never exposes public URLs or storage paths)
 * - Deletes temporary cache file immediately on close
 * - Displays diagonal watermark overlay + stamps watermark onto every rendered PDF page bitmap
 * - Supports page navigation and zoom controls; provides no download, share, or export option
 */
public class ManuscriptViewerActivity extends AppCompatActivity {

    private ImageView btnBackViewer;
    private TextView tvViewerTitle;
    private TextView tvViewerSubtitle;

    private RecyclerView rvManuscriptPages;
    private WatermarkOverlayView watermarkOverlay;

    private LinearLayout layoutViewerLoading;
    private TextView tvViewerStatus;

    private LinearLayout layoutViewerError;
    private TextView tvViewerErrorTitle;
    private TextView tvViewerErrorMessage;
    private MaterialButton btnViewerAction;
    private MaterialButton btnViewerRetry;

    private LinearLayout layoutPageControls;
    private TextView btnPrevPdfPage;
    private TextView btnNextPdfPage;
    private TextView tvPdfPageIndicator;
    private TextView btnZoomOut;
    private TextView btnZoomIn;
    private TextView tvZoomLabel;

    private int researchId;
    private String researchTitle;

    private File tempPdfFile;
    private ParcelFileDescriptor fileDescriptor;
    private PdfRenderer pdfRenderer;
    private ManuscriptPageAdapter pageAdapter;
    private LinearLayoutManager layoutManager;

    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private int currentPageIndex = 0;
    private int totalPages = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Apply FLAG_SECURE before setContentView to prevent screenshots and screen recording
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
        );
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manuscript_viewer);

        ApiClient.init(this);
        SessionManager session = new SessionManager(this);

        if (!session.isLoggedIn()) {
            finish();
            return;
        }

        researchId = getIntent().getIntExtra("research_id", 0);
        researchTitle = getIntent().getStringExtra("research_title");

        bindViews();

        if (researchTitle != null && !researchTitle.isEmpty()) {
            tvViewerTitle.setText(researchTitle);
        }

        String defaultSub = "Watermarked · " + session.getEmail() + " (" + session.getNumber() + ")";
        tvViewerSubtitle.setText(defaultSub);

        btnBackViewer.setOnClickListener(v -> finish());
        btnViewerRetry.setOnClickListener(v -> verifyAndLoadManuscript());
        btnViewerAction.setOnClickListener(v -> {
            Intent intent = new Intent(ManuscriptViewerActivity.this, MainActivity.class);
            intent.putExtra("open_tab", "plans");
            startActivity(intent);
            finish();
        });

        btnPrevPdfPage.setOnClickListener(v -> scrollToPage(currentPageIndex - 1));
        btnNextPdfPage.setOnClickListener(v -> scrollToPage(currentPageIndex + 1));

        btnZoomIn.setOnClickListener(v -> adjustZoom(0.25f));
        btnZoomOut.setOnClickListener(v -> adjustZoom(-0.25f));

        if (researchId <= 0) {
            showError("Invalid Manuscript", "No valid research record was specified.", false);
            return;
        }

        verifyAndLoadManuscript();
    }

    private void bindViews() {
        btnBackViewer = findViewById(R.id.btnBackViewer);
        tvViewerTitle = findViewById(R.id.tvViewerTitle);
        tvViewerSubtitle = findViewById(R.id.tvViewerSubtitle);

        rvManuscriptPages = findViewById(R.id.rvManuscriptPages);
        watermarkOverlay = findViewById(R.id.watermarkOverlay);

        layoutViewerLoading = findViewById(R.id.layoutViewerLoading);
        tvViewerStatus = findViewById(R.id.tvViewerStatus);

        layoutViewerError = findViewById(R.id.layoutViewerError);
        tvViewerErrorTitle = findViewById(R.id.tvViewerErrorTitle);
        tvViewerErrorMessage = findViewById(R.id.tvViewerErrorMessage);
        btnViewerAction = findViewById(R.id.btnViewerAction);
        btnViewerRetry = findViewById(R.id.btnViewerRetry);

        layoutPageControls = findViewById(R.id.layoutPageControls);
        btnPrevPdfPage = findViewById(R.id.btnPrevPdfPage);
        btnNextPdfPage = findViewById(R.id.btnNextPdfPage);
        tvPdfPageIndicator = findViewById(R.id.tvPdfPageIndicator);
        btnZoomOut = findViewById(R.id.btnZoomOut);
        btnZoomIn = findViewById(R.id.btnZoomIn);
        tvZoomLabel = findViewById(R.id.tvZoomLabel);

        layoutManager = new LinearLayoutManager(this);
        rvManuscriptPages.setLayoutManager(layoutManager);
        rvManuscriptPages.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int firstVisible = layoutManager.findFirstCompletelyVisibleItemPosition();
                if (firstVisible < 0) {
                    firstVisible = layoutManager.findFirstVisibleItemPosition();
                }
                if (firstVisible >= 0 && totalPages > 0) {
                    currentPageIndex = firstVisible;
                    updatePageControls();
                }
            }
        });
    }

    private void verifyAndLoadManuscript() {
        layoutViewerLoading.setVisibility(View.VISIBLE);
        layoutViewerError.setVisibility(View.GONE);
        tvViewerStatus.setText(R.string.viewer_loading);

        // Step 1: Verify authorization & retrieve server-generated watermark lines
        ApiClient.getService(this)
                .getManuscriptMeta(researchId, "meta")
                .enqueue(new Callback<ApiResponse<ManuscriptMeta>>() {
                    @Override
                    public void onResponse(@NonNull Call<ApiResponse<ManuscriptMeta>> call,
                                           @NonNull Response<ApiResponse<ManuscriptMeta>> response) {
                        if (isFinishing() || isDestroyed()) return;

                        if (response.isSuccessful() && response.body() != null
                                && response.body().success && response.body().data != null) {
                            ManuscriptMeta meta = response.body().data;
                            if (meta.title != null && !meta.title.isEmpty()) {
                                tvViewerTitle.setText(meta.title);
                            }
                            if (meta.authorizedUser != null) {
                                tvViewerSubtitle.setText("Watermarked · "
                                        + meta.authorizedUser + " (" + meta.studentNumber + ")");
                            }

                            List<String> lines = meta.watermarkLines != null && !meta.watermarkLines.isEmpty()
                                    ? meta.watermarkLines
                                    : buildDefaultWatermarkLines();
                            watermarkOverlay.setWatermarkLines(lines);

                            // Step 2: Stream protected PDF binary
                            streamProtectedPdf(lines);
                        } else {
                            ApiResponse<ManuscriptMeta> err = StudyVaultRepository.parseErrorResponse(
                                    response, ManuscriptMeta.class);
                            boolean needsSubscription = err != null && "no_subscription".equals(err.code);
                            String title = needsSubscription
                                    ? "Full Manuscript Access Required"
                                    : "Access Denied";
                            String msg = (err != null && err.message != null)
                                    ? err.message
                                    : "You are not authorized to view this manuscript.";
                            showError(title, msg, needsSubscription);
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ApiResponse<ManuscriptMeta>> call, @NonNull Throwable t) {
                        if (isFinishing() || isDestroyed()) return;
                        showError("Connection Error", getString(R.string.error_network), false);
                    }
                });
    }

    private void streamProtectedPdf(List<String> watermarkLines) {
        tvViewerStatus.setText("Streaming protected manuscript…");

        ApiClient.getService(this)
                .streamManuscript(researchId, "stream")
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(@NonNull Call<ResponseBody> call,
                                           @NonNull Response<ResponseBody> response) {
                        if (isFinishing() || isDestroyed()) return;

                        if (!response.isSuccessful() || response.body() == null) {
                            showError("Manuscript Unavailable",
                                    "Could not stream the protected PDF document (HTTP " + response.code() + ").",
                                    response.code() == 403);
                            return;
                        }

                        final ResponseBody body = response.body();
                        ioExecutor.execute(() -> {
                            try {
                                closeRenderer();
                                File cacheFile = new File(getCacheDir(),
                                        "sv_protected_" + researchId + "_" + System.currentTimeMillis() + ".tmp");
                                try (InputStream in = body.byteStream();
                                     FileOutputStream out = new FileOutputStream(cacheFile)) {
                                    byte[] buffer = new byte[8192];
                                    int read;
                                    while ((read = in.read(buffer)) != -1) {
                                        out.write(buffer, 0, read);
                                    }
                                    out.flush();
                                }

                                ParcelFileDescriptor pfd = ParcelFileDescriptor.open(
                                        cacheFile, ParcelFileDescriptor.MODE_READ_ONLY);
                                PdfRenderer renderer = new PdfRenderer(pfd);

                                tempPdfFile = cacheFile;
                                fileDescriptor = pfd;
                                pdfRenderer = renderer;

                                runOnUiThread(() -> {
                                    if (isFinishing() || isDestroyed()) return;
                                    layoutViewerLoading.setVisibility(View.GONE);
                                    layoutPageControls.setVisibility(View.VISIBLE);
                                    totalPages = pdfRenderer.getPageCount();
                                    currentPageIndex = 0;

                                    pageAdapter = new ManuscriptPageAdapter(
                                            ManuscriptViewerActivity.this, pdfRenderer, watermarkLines);
                                    rvManuscriptPages.setAdapter(pageAdapter);
                                    updatePageControls();
                                });
                            } catch (Exception e) {
                                runOnUiThread(() -> {
                                    if (isFinishing() || isDestroyed()) return;
                                    showError("Viewer Error",
                                            "Unable to render the protected PDF manuscript.", false);
                                });
                            }
                        });
                    }

                    @Override
                    public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                        if (isFinishing() || isDestroyed()) return;
                        showError("Connection Error", getString(R.string.error_network), false);
                    }
                });
    }

    private void scrollToPage(int targetIndex) {
        if (totalPages <= 0) return;
        int clamped = Math.max(0, Math.min(totalPages - 1, targetIndex));
        currentPageIndex = clamped;
        rvManuscriptPages.smoothScrollToPosition(clamped);
        updatePageControls();
    }

    private void adjustZoom(float delta) {
        if (pageAdapter == null) return;
        float nextScale = Math.max(0.75f, Math.min(2.0f, pageAdapter.getZoomScale() + delta));
        pageAdapter.setZoomScale(nextScale);
        int pct = Math.round(nextScale * 100f);
        tvZoomLabel.setText(pct + "%");
    }

    private void updatePageControls() {
        if (totalPages <= 0) {
            tvPdfPageIndicator.setText("Page 0 of 0");
            btnPrevPdfPage.setEnabled(false);
            btnNextPdfPage.setEnabled(false);
            return;
        }
        tvPdfPageIndicator.setText(String.format(Locale.US, "Page %d of %d", currentPageIndex + 1, totalPages));
        btnPrevPdfPage.setEnabled(currentPageIndex > 0);
        btnNextPdfPage.setEnabled(currentPageIndex < totalPages - 1);
        btnPrevPdfPage.setAlpha(currentPageIndex > 0 ? 1.0f : 0.4f);
        btnNextPdfPage.setAlpha(currentPageIndex < totalPages - 1 ? 1.0f : 0.4f);
    }

    private void showError(String title, String message, boolean showUpgrade) {
        layoutViewerLoading.setVisibility(View.GONE);
        layoutViewerError.setVisibility(View.VISIBLE);
        tvViewerErrorTitle.setText(title);
        tvViewerErrorMessage.setText(message);
        btnViewerAction.setVisibility(showUpgrade ? View.VISIBLE : View.GONE);
    }

    private List<String> buildDefaultWatermarkLines() {
        SessionManager sm = new SessionManager(this);
        List<String> lines = new ArrayList<>();
        lines.add("STUDY VAULT · ISABELA STATE UNIVERSITY");
        lines.add("Authorized User: " + sm.getEmail());
        lines.add("Student ID: " + sm.getNumber());
        lines.add("CONFIDENTIAL · DO NOT DISTRIBUTE");
        return lines;
    }

    private void closeRenderer() {
        if (pageAdapter != null) {
            pageAdapter.shutdown();
            pageAdapter = null;
        }
        if (pdfRenderer != null) {
            try {
                pdfRenderer.close();
            } catch (Exception ignored) {
            }
            pdfRenderer = null;
        }
        if (fileDescriptor != null) {
            try {
                fileDescriptor.close();
            } catch (Exception ignored) {
            }
            fileDescriptor = null;
        }
        if (tempPdfFile != null && tempPdfFile.exists()) {
            //noinspection ResultOfMethodCallIgnored
            tempPdfFile.delete();
            tempPdfFile = null;
        }
    }

    @Override
    protected void onDestroy() {
        ioExecutor.shutdownNow();
        closeRenderer();
        super.onDestroy();
    }
}
