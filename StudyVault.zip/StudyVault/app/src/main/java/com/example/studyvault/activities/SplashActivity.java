package com.example.studyvault.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.studyvault.R;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.ProfileData;
import com.example.studyvault.repository.StudyVaultRepository;
import com.example.studyvault.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Splash Screen:
 * - Displays Study Vault & ISU Ilagan Campus branding
 * - Checks existing session state and validates with server before routing
 * - Never exposes protected content to unauthenticated users
 */
public class SplashActivity extends AppCompatActivity {

    private static final long SPLASH_DELAY_MS = 1100L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ApiClient.init(this);
        SessionManager session = new SessionManager(this);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!session.isLoggedIn()) {
                routeToLogin(null);
                return;
            }

            // Verify existing session token & account approval status with server
            ApiClient.getService(SplashActivity.this).getProfile().enqueue(new Callback<ApiResponse<ProfileData>>() {
                @Override
                public void onResponse(@NonNull Call<ApiResponse<ProfileData>> call,
                                       @NonNull Response<ApiResponse<ProfileData>> response) {
                    if (isFinishing() || isDestroyed()) return;

                    if (response.isSuccessful() && response.body() != null
                            && response.body().success && response.body().data != null
                            && response.body().data.student != null) {
                        ProfileData data = response.body().data;
                        session.saveStudentSession(data.student, session.getToken());
                        session.updateSubscriptionStatus(data.hasFullAccess, data.activeSubscription);
                        routeToMain();
                    } else {
                        ApiResponse<ProfileData> err = StudyVaultRepository.parseErrorResponse(
                                response, ProfileData.class);
                        if (StudyVaultRepository.isAuthExpired(response, err)) {
                            session.logout();
                            routeToLogin(err != null ? err.message : null);
                        } else {
                            // Server reachable but non-auth error: allow main view, server still guards all APIs
                            routeToMain();
                        }
                    }
                }

                @Override
                public void onFailure(@NonNull Call<ApiResponse<ProfileData>> call, @NonNull Throwable t) {
                    if (isFinishing() || isDestroyed()) return;
                    // Offline/unreachable: proceed to MainActivity which shows connection error + retry
                    routeToMain();
                }
            });
        }, SPLASH_DELAY_MS);
    }

    private void routeToMain() {
        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void routeToLogin(String notice) {
        Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
        if (notice != null && !notice.isEmpty()) {
            intent.putExtra("login_notice", notice);
        }
        startActivity(intent);
        finish();
    }
}
