package com.example.studyvault.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.studyvault.R;
import com.example.studyvault.activities.CheckoutActivity;
import com.example.studyvault.activities.MainActivity;
import com.example.studyvault.adapters.PlanAdapter;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.AccessPlan;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.PlansData;
import com.example.studyvault.models.Subscription;
import com.example.studyvault.repository.StudyVaultRepository;
import com.example.studyvault.utils.SessionManager;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Access Plans Screen matching study-vault/plans.php and api/plans.php.
 */
public class PlansFragment extends Fragment {

    private SwipeRefreshLayout swipeRefreshPlans;
    private TextView tvCurrentPlanStatus;
    private TextView tvCurrentPlanTitle;
    private TextView tvCurrentPlanExpiry;
    private TextView tvCurrentPlanRef;
    private TextView tvDemoBannerText;

    private ProgressBar progressPlans;
    private RecyclerView rvPlans;

    private LinearLayout layoutPlansError;
    private TextView tvPlansError;
    private MaterialButton btnRetryPlans;

    private SessionManager session;
    private final List<AccessPlan> planList = new ArrayList<>();
    private PlanAdapter planAdapter;

    private final ActivityResultLauncher<Intent> checkoutLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    loadAccessPlans();
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_plans, container, false);

        session = new SessionManager(requireContext());
        bindViews(view);
        setupAdapter();
        loadAccessPlans();

        return view;
    }

    private void bindViews(View view) {
        swipeRefreshPlans = view.findViewById(R.id.swipeRefreshPlans);
        tvCurrentPlanStatus = view.findViewById(R.id.tvCurrentPlanStatus);
        tvCurrentPlanTitle = view.findViewById(R.id.tvCurrentPlanTitle);
        tvCurrentPlanExpiry = view.findViewById(R.id.tvCurrentPlanExpiry);
        tvCurrentPlanRef = view.findViewById(R.id.tvCurrentPlanRef);
        tvDemoBannerText = view.findViewById(R.id.tvDemoBannerText);

        progressPlans = view.findViewById(R.id.progressPlans);
        rvPlans = view.findViewById(R.id.rvPlans);

        layoutPlansError = view.findViewById(R.id.layoutPlansError);
        tvPlansError = view.findViewById(R.id.tvPlansError);
        btnRetryPlans = view.findViewById(R.id.btnRetryPlans);

        swipeRefreshPlans.setColorSchemeResources(R.color.sv_forest_800, R.color.sv_gold);
        swipeRefreshPlans.setOnRefreshListener(this::loadAccessPlans);

        btnRetryPlans.setOnClickListener(v -> loadAccessPlans());
    }

    private void setupAdapter() {
        rvPlans.setLayoutManager(new LinearLayoutManager(getContext()));
        planAdapter = new PlanAdapter(requireContext(), planList, null, plan -> {
            Intent intent = new Intent(requireContext(), CheckoutActivity.class);
            intent.putExtra("access_plan", plan);
            checkoutLauncher.launch(intent);
        });
        rvPlans.setAdapter(planAdapter);
    }

    private void loadAccessPlans() {
        if (!swipeRefreshPlans.isRefreshing()) {
            progressPlans.setVisibility(View.VISIBLE);
        }
        layoutPlansError.setVisibility(View.GONE);

        ApiClient.getService(requireContext()).getPlans().enqueue(new Callback<ApiResponse<PlansData>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<PlansData>> call,
                                   @NonNull Response<ApiResponse<PlansData>> response) {
                if (!isAdded()) return;
                progressPlans.setVisibility(View.GONE);
                swipeRefreshPlans.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null
                        && response.body().success && response.body().data != null) {
                    PlansData data = response.body().data;

                    session.updateSubscriptionStatus(data.hasFullAccess, data.activeSubscription);
                    bindCurrentStatusBanner(data);

                    if (data.demoNotice != null && !data.demoNotice.isEmpty()) {
                        tvDemoBannerText.setText(data.demoNotice);
                    }

                    planList.clear();
                    if (data.plans != null) {
                        planList.addAll(data.plans);
                    }
                    planAdapter.setActiveSubscription(data.activeSubscription);
                    planAdapter.notifyDataSetChanged();
                } else {
                    ApiResponse<PlansData> err = StudyVaultRepository.parseErrorResponse(
                            response, PlansData.class);
                    if (StudyVaultRepository.isAuthExpired(response, err)
                            && getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).handleSessionExpired(err != null ? err.message : null);
                        return;
                    }
                    showError(err != null && err.message != null
                            ? err.message : "Failed to load access plans.");
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<PlansData>> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                progressPlans.setVisibility(View.GONE);
                swipeRefreshPlans.setRefreshing(false);
                showError(getString(R.string.error_network));
            }
        });
    }

    private void bindCurrentStatusBanner(PlansData data) {
        Subscription active = data.activeSubscription;
        Subscription expired = data.expiredSubscription;

        if (active != null && data.hasFullAccess) {
            tvCurrentPlanStatus.setText("Active");
            tvCurrentPlanStatus.setBackgroundResource(R.drawable.bg_badge_green);
            tvCurrentPlanStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.sv_green));

            tvCurrentPlanTitle.setText(active.planName);
            tvCurrentPlanExpiry.setText("Full manuscript viewing is unlocked until "
                    + (active.expirationDateFormatted != null ? active.expirationDateFormatted : active.expirationDate)
                    + ".");
            if (active.referenceCode != null && !active.referenceCode.isEmpty()) {
                tvCurrentPlanRef.setText("Reference: " + active.referenceCode);
                tvCurrentPlanRef.setVisibility(View.VISIBLE);
            } else {
                tvCurrentPlanRef.setVisibility(View.GONE);
            }
        } else if (expired != null) {
            tvCurrentPlanStatus.setText("Expired");
            tvCurrentPlanStatus.setBackgroundResource(R.drawable.bg_badge_amber);
            tvCurrentPlanStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.sv_amber));

            tvCurrentPlanTitle.setText("Free Access (Previous Plan Expired)");
            tvCurrentPlanExpiry.setText("Your " + expired.planName + " subscription expired on "
                    + (expired.expirationDateFormatted != null ? expired.expirationDateFormatted : expired.expirationDate)
                    + ". Select a plan below to restore full manuscript viewing.");
            tvCurrentPlanRef.setVisibility(View.GONE);
        } else {
            tvCurrentPlanStatus.setText("Free Access");
            tvCurrentPlanStatus.setBackgroundResource(R.drawable.bg_badge_gray);
            tvCurrentPlanStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.sv_gray));

            tvCurrentPlanTitle.setText("Abstract Reading Access");
            tvCurrentPlanExpiry.setText(
                    "You can search the archive and read all research abstracts for free. " +
                    "Activate a paid plan below to unlock full manuscript viewing.");
            tvCurrentPlanRef.setVisibility(View.GONE);
        }
    }

    private void showError(String message) {
        layoutPlansError.setVisibility(View.VISIBLE);
        tvPlansError.setText(message);
    }
}
