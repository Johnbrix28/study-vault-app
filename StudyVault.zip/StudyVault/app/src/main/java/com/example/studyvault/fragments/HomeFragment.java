package com.example.studyvault.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.studyvault.activities.MainActivity;
import com.example.studyvault.adapters.CategoryAdapter;
import com.example.studyvault.adapters.ResearchAdapter;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.databinding.FragmentHomeBinding;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.Research;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private ResearchAdapter researchAdapter;
    private CategoryAdapter categoryAdapter;
    private List<Research> allLoadedResearch = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        // Recent research adapter
        researchAdapter = new ResearchAdapter(new ArrayList<>(), requireContext());
        binding.rvRecent.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvRecent.setAdapter(researchAdapter);

        // Categories adapter
        setupCategories();

        // Hero search — click button
        binding.btnHeroSearch.setOnClickListener(v -> performHeroSearch());

        // Hero search — keyboard "Search" button
        binding.etHeroSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performHeroSearch();
                return true;
            }
            return false;
        });

        // View All — Categories
        binding.tvViewAllCategories.setOnClickListener(v -> goToSearchWithCategory(1));

        // View All — Recent Research
        binding.tvViewAllRecent.setOnClickListener(v -> goToSearchAll());

        // Swipe refresh
        binding.swipeRefresh.setOnRefreshListener(this::loadRecent);

        // Load initial data
        loadRecent();
    }

    private void performHeroSearch() {
        String q = binding.etHeroSearch.getText().toString().trim();
        goToSearchWithQuery(q);
    }

    private void setupCategories() {
        List<CategoryAdapter.CategoryItem> cats = new ArrayList<>();
        cats.add(new CategoryAdapter.CategoryItem(1, "Web and Mobile App Dev", 0));
        cats.add(new CategoryAdapter.CategoryItem(2, "Networking Security", 0));

        categoryAdapter = new CategoryAdapter(cats, item -> {
            // Click sa category card → Search tab na may filter
            goToSearchWithCategory(item.id);
        });

        LinearLayoutManager lm = new LinearLayoutManager(requireContext(),
                LinearLayoutManager.HORIZONTAL, false);
        binding.categoriesContainer.setLayoutManager(lm);
        binding.categoriesContainer.setAdapter(categoryAdapter);
    }

    private void loadRecent() {
        binding.swipeRefresh.setRefreshing(true);

        ApiClient.getService().getResearchList(null, null, null)
                .enqueue(new Callback<ApiResponse<List<Research>>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<List<Research>>> call,
                                           Response<ApiResponse<List<Research>>> response) {
                        binding.swipeRefresh.setRefreshing(false);

                        if (response.isSuccessful() && response.body() != null
                                && response.body().data != null) {

                            allLoadedResearch = response.body().data;

                            // Show first 5 only on home
                            List<Research> preview = allLoadedResearch.size() > 5
                                    ? allLoadedResearch.subList(0, 5)
                                    : allLoadedResearch;
                            researchAdapter.setData(new ArrayList<>(preview));

                            // Update category counts
                            updateCategoryCounts();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<List<Research>>> call, Throwable t) {
                        binding.swipeRefresh.setRefreshing(false);
                        Toast.makeText(requireContext(),
                                "Failed to load: " + t.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void updateCategoryCounts() {
        int webCount = 0;
        int netCount = 0;

        for (Research r : allLoadedResearch) {
            if (r.categoryId == 1) webCount++;
            else if (r.categoryId == 2) netCount++;
        }

        List<CategoryAdapter.CategoryItem> cats = new ArrayList<>();
        cats.add(new CategoryAdapter.CategoryItem(1, "Web and Mobile App Dev", webCount));
        cats.add(new CategoryAdapter.CategoryItem(2, "Networking Security", netCount));

        categoryAdapter = new CategoryAdapter(cats, item -> {
            goToSearchWithCategory(item.id);
        });
        binding.categoriesContainer.setAdapter(categoryAdapter);
    }

    // ============================================================
    // NAVIGATION HELPERS
    // ============================================================

    private void goToSearchWithQuery(String query) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).switchToSearchWithQuery(query);
        }
    }

    private void goToSearchWithCategory(int categoryId) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).switchToSearchWithCategory(categoryId);
        }
    }

    private void goToSearchAll() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).switchToSearchWithQuery("");
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}