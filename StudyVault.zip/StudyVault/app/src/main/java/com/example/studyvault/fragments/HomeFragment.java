package com.example.studyvault.fragments;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.studyvault.R;
import com.example.studyvault.activities.MainActivity;
import com.example.studyvault.adapters.CategoryAdapter;
import com.example.studyvault.adapters.ResearchAdapter;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.Category;
import com.example.studyvault.models.HomeData;
import com.example.studyvault.models.Research;
import com.example.studyvault.models.Subscription;
import com.example.studyvault.repository.StudyVaultRepository;
import com.example.studyvault.utils.SessionManager;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Home Screen matching study-vault/index.php and api/home.php.
 */
public class HomeFragment extends Fragment {

    private SwipeRefreshLayout swipeRefresh;
    private TextView tvGreetingName;
    private TextView tvUserTypeBadge;
    private EditText etHeroSearch;
    private ImageView btnHeroSearch;
    private TextView tvExploreArchive;

    private TextView tvHomePlanName;
    private TextView tvHomePlanBadge;
    private TextView tvHomePlanDesc;
    private MaterialButton btnHomePlanAction;

    private TextView tvStatApprovedWorks;
    private TextView tvStatCategories;
    private TextView tvViewAllCategories;
    private TextView tvViewAllRecent;

    private RecyclerView categoriesContainer;
    private RecyclerView rvRecent;
    private ProgressBar progressHome;
    private TextView tvHomeEmpty;

    private LinearLayout layoutHomeError;
    private TextView tvHomeError;
    private MaterialButton btnHomeRetry;

    private SessionManager session;
    private final List<Category> categoryList = new ArrayList<>();
    private final List<Research> recentList = new ArrayList<>();
    private CategoryAdapter categoryAdapter;
    private ResearchAdapter researchAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        session = new SessionManager(requireContext());
        bindViews(view);
        setupAdapters();
        populateCachedHeader();
        loadHomeDashboard();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (session != null) {
            populateCachedHeader();
        }
    }

    private void bindViews(View view) {
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
        tvGreetingName = view.findViewById(R.id.tvGreetingName);
        tvUserTypeBadge = view.findViewById(R.id.tvUserTypeBadge);
        etHeroSearch = view.findViewById(R.id.etHeroSearch);
        btnHeroSearch = view.findViewById(R.id.btnHeroSearch);
        tvExploreArchive = view.findViewById(R.id.tvExploreArchive);

        tvHomePlanName = view.findViewById(R.id.tvHomePlanName);
        tvHomePlanBadge = view.findViewById(R.id.tvHomePlanBadge);
        tvHomePlanDesc = view.findViewById(R.id.tvHomePlanDesc);
        btnHomePlanAction = view.findViewById(R.id.btnHomePlanAction);

        tvStatApprovedWorks = view.findViewById(R.id.tvStatApprovedWorks);
        tvStatCategories = view.findViewById(R.id.tvStatCategories);
        tvViewAllCategories = view.findViewById(R.id.tvViewAllCategories);
        tvViewAllRecent = view.findViewById(R.id.tvViewAllRecent);

        categoriesContainer = view.findViewById(R.id.categoriesContainer);
        rvRecent = view.findViewById(R.id.rvRecent);
        progressHome = view.findViewById(R.id.progressHome);
        tvHomeEmpty = view.findViewById(R.id.tvHomeEmpty);

        layoutHomeError = view.findViewById(R.id.layoutHomeError);
        tvHomeError = view.findViewById(R.id.tvHomeError);
        btnHomeRetry = view.findViewById(R.id.btnHomeRetry);

        swipeRefresh.setColorSchemeResources(R.color.sv_forest_800, R.color.sv_gold);
        swipeRefresh.setOnRefreshListener(this::loadHomeDashboard);

        btnHomePlanAction.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).openAccessPlans();
            }
        });

        btnHeroSearch.setOnClickListener(v -> triggerHomeSearch());
        etHeroSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                triggerHomeSearch();
                return true;
            }
            return false;
        });

        View.OnClickListener openAllArchive = v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).openSearchWithFilter(null, 0);
            }
        };
        tvExploreArchive.setOnClickListener(openAllArchive);
        tvViewAllCategories.setOnClickListener(openAllArchive);
        tvViewAllRecent.setOnClickListener(openAllArchive);

        btnHomeRetry.setOnClickListener(v -> loadHomeDashboard());
    }

    private void setupAdapters() {
        categoriesContainer.setLayoutManager(
                new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        categoryAdapter = new CategoryAdapter(getContext(), categoryList, category -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).openSearchWithFilter(null, category.categoryId);
            }
        });
        categoriesContainer.setAdapter(categoryAdapter);

        rvRecent.setLayoutManager(new LinearLayoutManager(getContext()));
        researchAdapter = new ResearchAdapter(getContext(), recentList);
        rvRecent.setAdapter(researchAdapter);
    }

    private void populateCachedHeader() {
        String name = session.getName();
        tvGreetingName.setText(!name.isEmpty() ? "Hello, " + name : "Hello, Student");
        tvUserTypeBadge.setText(session.getUserTypeLabel());

        updateAccessBanner(session.hasFullAccess(), session.getActivePlanName(), session.getActivePlanExpiry());
    }

    private void updateAccessBanner(boolean hasFullAccess, String planName, String expiry) {
        if (!isAdded()) return;
        if (hasFullAccess) {
            tvHomePlanName.setText(planName != null && !planName.isEmpty() ? planName : "Research Access");
            tvHomePlanBadge.setText("Full-text Active");
            tvHomePlanBadge.setBackgroundResource(R.drawable.bg_badge_green);
            tvHomePlanBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.sv_green));
            tvHomePlanDesc.setText(expiry != null && !expiry.isEmpty()
                    ? "Full manuscript viewing is unlocked until " + expiry + "."
                    : "Full manuscript viewing is active on your account.");
            btnHomePlanAction.setText("My Plan");
        } else {
            tvHomePlanName.setText("Free Access");
            tvHomePlanBadge.setText("Abstract Access");
            tvHomePlanBadge.setBackgroundResource(R.drawable.bg_badge_gray);
            tvHomePlanBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.sv_gray));
            tvHomePlanDesc.setText("Browse and read abstracts for free. Unlock full manuscripts with an access plan.");
            btnHomePlanAction.setText("Plans →");
        }
    }

    private void triggerHomeSearch() {
        String q = etHeroSearch.getText() != null ? etHeroSearch.getText().toString().trim() : "";
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).openSearchWithFilter(q, 0);
        }
    }

    private void loadHomeDashboard() {
        if (!swipeRefresh.isRefreshing()) {
            progressHome.setVisibility(View.VISIBLE);
        }
        layoutHomeError.setVisibility(View.GONE);
        tvHomeEmpty.setVisibility(View.GONE);

        ApiClient.getService(requireContext()).getHomeData().enqueue(new Callback<ApiResponse<HomeData>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<HomeData>> call,
                                   @NonNull Response<ApiResponse<HomeData>> response) {
                if (!isAdded()) return;
                progressHome.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null
                        && response.body().success && response.body().data != null) {
                    HomeData data = response.body().data;

                    if (data.student != null) {
                        session.saveStudentSession(data.student, session.getToken());
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).refreshTopBarUserPill();
                        }
                    }
                    session.updateSubscriptionStatus(data.hasFullAccess, data.activeSubscription);
                    populateCachedHeader();

                    Subscription sub = data.activeSubscription;
                    updateAccessBanner(
                            data.hasFullAccess,
                            sub != null ? sub.planName : "Free Access",
                            sub != null ? sub.expirationDateFormatted : ""
                    );

                    if (data.stats != null) {
                        tvStatApprovedWorks.setText(String.valueOf(data.stats.totalApprovedResearch));
                        tvStatCategories.setText(String.valueOf(data.stats.totalCategories));
                    }

                    categoryList.clear();
                    if (data.categories != null) {
                        categoryList.addAll(data.categories);
                    }
                    categoryAdapter.notifyDataSetChanged();

                    recentList.clear();
                    if (data.recentResearch != null) {
                        recentList.addAll(data.recentResearch);
                    }
                    researchAdapter.notifyDataSetChanged();

                    tvHomeEmpty.setVisibility(recentList.isEmpty() ? View.VISIBLE : View.GONE);
                } else {
                    ApiResponse<HomeData> err = StudyVaultRepository.parseErrorResponse(
                            response, HomeData.class);
                    if (StudyVaultRepository.isAuthExpired(response, err)
                            && getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).handleSessionExpired(err != null ? err.message : null);
                        return;
                    }
                    showError(err != null && err.message != null
                            ? err.message : "Failed to load home dashboard.");
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<HomeData>> call, @NonNull Throwable t) {
                if (!isAdded()) return;
                progressHome.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                showError(getString(R.string.error_network));
            }
        });
    }

    private void showError(String message) {
        layoutHomeError.setVisibility(View.VISIBLE);
        tvHomeError.setText(message);
    }
}
