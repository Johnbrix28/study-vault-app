package com.example.studyvault.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ApiResponse<T> implements Serializable {
    @SerializedName("success")
    public boolean success;

    @SerializedName("code")
    public String code;

    @SerializedName("message")
    public String message;

    @SerializedName("token")
    public String token;

    @SerializedName("data")
    public T data;

    @SerializedName("meta")
    public PaginationMeta meta;

    @SerializedName("filters")
    public FilterOptions filters;

    @SerializedName("errors")
    public Map<String, String> errors;

    @SerializedName("restart")
    public boolean restart;

    @SerializedName("show_login")
    public boolean showLogin;

    public static class PaginationMeta implements Serializable {
        @SerializedName("page")
        public int page = 1;

        @SerializedName("per_page")
        public int perPage = 20;

        @SerializedName("total")
        public int total = 0;

        @SerializedName("total_pages")
        public int totalPages = 1;

        @SerializedName("has_more")
        public boolean hasMore = false;
    }

    public static class FilterOptions implements Serializable {
        @SerializedName("categories")
        public List<Category> categories;

        @SerializedName("years")
        public List<Integer> years;
    }
}
