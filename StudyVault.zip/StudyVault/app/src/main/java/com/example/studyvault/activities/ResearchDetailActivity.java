package com.example.studyvault.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.studyvault.R;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.RelatedResearch;
import com.example.studyvault.models.Research;
import com.example.studyvault.repository.StudyVaultRepository;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Research Details Screen matching study-vault/research-details.php and api/research-detail.php.
 */
public class ResearchDetailActivity extends AppCompatActivity {

    private ImageView btnBack;
    private TextView tvCategoryBadge;
    private TextView tvYearBadge;
    private TextView tvTitle;
    private TextView tvAuthors;
    private TextView tvMetaProgram;
    private TextView tvMetaPublishedDate;

    private TextView tvManuscriptStatusItem;
    private TextView tvReaderAccessItem;
    private MaterialButton btnOpenManuscript;
    private LinearLayout layoutLockBox;
    private TextView tvLockReason;
    private MaterialButton btnViewPlansFromDetail;
    private TextView tvNoPdf;

    private TextView tvAbstract;
    private LinearLayout keywordsCard;
    private ChipGroup chipGroupKeywords;

    private LinearLayout relatedCard;
    private TextView tvViewAllRelated;
    private LinearLayout relatedContainer;

    private int researchId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_research_detail);

        ApiClient.init(this);
        bindViews();

        btnBack.setOnClickListener(v -> finish());

        researchId = getIntent().getIntExtra("research_id", 0);
        if (researchId <= 0) {
            Toast.makeText(this, "Invalid research record ID.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadDetail(researchId);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (researchId > 0) {
            loadDetail(researchId);
        }
    }

    private void bindViews() {
        btnBack = findViewById(R.id.btnBack);
        tvCategoryBadge = findViewById(R.id.tvCategoryBadge);
        tvYearBadge = findViewById(R.id.tvYearBadge);
        tvTitle = findViewById(R.id.tvTitle);
        tvAuthors = findViewById(R.id.tvAuthors);
        tvMetaProgram = findViewById(R.id.tvMetaProgram);
        tvMetaPublishedDate = findViewById(R.id.tvMetaPublishedDate);

        tvManuscriptStatusItem = findViewById(R.id.tvManuscriptStatusItem);
        tvReaderAccessItem = findViewById(R.id.tvReaderAccessItem);
        btnOpenManuscript = findViewById(R.id.btnOpenManuscript);
        layoutLockBox = findViewById(R.id.layoutLockBox);
        tvLockReason = findViewById(R.id.tvLockReason);
        btnViewPlansFromDetail = findViewById(R.id.btnViewPlansFromDetail);
        tvNoPdf = findViewById(R.id.tvNoPdf);

        tvAbstract = findViewById(R.id.tvAbstract);
        keywordsCard = findViewById(R.id.keywordsCard);
        chipGroupKeywords = findViewById(R.id.chipGroupKeywords);

        relatedCard = findViewById(R.id.relatedCard);
        tvViewAllRelated = findViewById(R.id.tvViewAllRelated);
        relatedContainer = findViewById(R.id.relatedContainer);
    }

    private void loadDetail(int id) {
        ApiClient.getService(this).getResearchDetail(id).enqueue(new Callback<ApiResponse<Research>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<Research>> call,
                                   @NonNull Response<ApiResponse<Research>> response) {
                if (isFinishing() || isDestroyed()) return;

                if (response.isSuccessful() && response.body() != null
                        && response.body().success && response.body().data != null) {
                    bindResearch(response.body().data);
                } else {
                    ApiResponse<Research> err = StudyVaultRepository.parseErrorResponse(
                            response, Research.class);
                    Toast.makeText(ResearchDetailActivity.this,
                            err != null && err.message != null ? err.message : "Failed to load research details.",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<Research>> call, @NonNull Throwable t) {
                if (isFinishing() || isDestroyed()) return;
                Toast.makeText(ResearchDetailActivity.this,
                        getString(R.string.error_network), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void bindResearch(Research r) {
        String cat = (r.categoryName != null && !r.categoryName.isEmpty())
                ? r.categoryName : "Uncategorized";
        tvCategoryBadge.setText(cat);
        tvYearBadge.setText(r.year > 0 ? String.valueOf(r.year) : "N/A");
        tvTitle.setText(r.title != null ? r.title : "Untitled Research");

        String authors = (r.researchers != null && !r.researchers.trim().isEmpty())
                ? r.researchers.trim()
                : "Researchers not listed";
        tvAuthors.setText(authors);

        tvMetaProgram.setText(r.programName != null && !r.programName.isEmpty()
                ? r.programName : "Bachelor of Science in Information Technology");

        String pubDate = (r.publishedDateFormatted != null && !r.publishedDateFormatted.isEmpty())
                ? r.publishedDateFormatted
                : (r.publishedDate != null && !r.publishedDate.isEmpty() ? r.publishedDate : String.valueOf(r.year));
        tvMetaPublishedDate.setText(pubDate);

        tvAbstract.setText(r.abstractText != null && !r.abstractText.isEmpty()
                ? r.abstractText : "No abstract text provided.");

        // Manuscript Access Section (matches research-details.php)
        if (!r.hasManuscript) {
            tvManuscriptStatusItem.setText("○  Abstract-only entry (no PDF uploaded)");
            tvManuscriptStatusItem.setTextColor(ContextCompat.getColor(this, R.color.sv_amber));
            tvReaderAccessItem.setVisibility(View.GONE);
            btnOpenManuscript.setVisibility(View.GONE);
            layoutLockBox.setVisibility(View.GONE);
            tvNoPdf.setVisibility(View.VISIBLE);
        } else if (r.canViewManuscript) {
            tvManuscriptStatusItem.setText("●  Full manuscript PDF on file");
            tvManuscriptStatusItem.setTextColor(ContextCompat.getColor(this, R.color.sv_green));
            tvReaderAccessItem.setText("●  Protected watermarked reader unlocked");
            tvReaderAccessItem.setTextColor(ContextCompat.getColor(this, R.color.sv_green));
            tvReaderAccessItem.setVisibility(View.VISIBLE);

            btnOpenManuscript.setVisibility(View.VISIBLE);
            layoutLockBox.setVisibility(View.GONE);
            tvNoPdf.setVisibility(View.GONE);

            btnOpenManuscript.setOnClickListener(v -> {
                Intent viewerIntent = new Intent(ResearchDetailActivity.this, ManuscriptViewerActivity.class);
                viewerIntent.putExtra("research_id", r.researchId);
                viewerIntent.putExtra("research_title", r.title);
                startActivity(viewerIntent);
            });
        } else {
            tvManuscriptStatusItem.setText("●  Full manuscript PDF on file");
            tvManuscriptStatusItem.setTextColor(ContextCompat.getColor(this, R.color.sv_green));
            tvReaderAccessItem.setText("🔒  Requires active Research Access plan");
            tvReaderAccessItem.setTextColor(ContextCompat.getColor(this, R.color.sv_amber));
            tvReaderAccessItem.setVisibility(View.VISIBLE);

            btnOpenManuscript.setVisibility(View.GONE);
            layoutLockBox.setVisibility(View.VISIBLE);
            tvNoPdf.setVisibility(View.GONE);

            String reason = (r.accessReason != null && !r.accessReason.isEmpty())
                    ? r.accessReason + " "
                    : "";
            tvLockReason.setText(reason +
                    "Read the abstract and research metadata for free. Activate Research Access (₱99 / 30 days) or Research Access Plus (₱249 / 90 days) to read the complete watermarked manuscript.");

            btnViewPlansFromDetail.setOnClickListener(v -> {
                Intent plansIntent = new Intent(ResearchDetailActivity.this, MainActivity.class);
                plansIntent.putExtra("open_tab", "plans");
                startActivity(plansIntent);
            });
        }

        // Keywords
        List<String> keywords = new ArrayList<>();
        if (r.keywordList != null && !r.keywordList.isEmpty()) {
            keywords.addAll(r.keywordList);
        } else if (r.keywords != null && !r.keywords.trim().isEmpty()) {
            for (String k : r.keywords.split(",")) {
                if (!k.trim().isEmpty()) keywords.add(k.trim());
            }
        }

        chipGroupKeywords.removeAllViews();
        if (!keywords.isEmpty()) {
            keywordsCard.setVisibility(View.VISIBLE);
            for (String kw : keywords) {
                Chip chip = new Chip(this);
                chip.setText(kw);
                chip.setTextSize(11f);
                chip.setChipBackgroundColorResource(R.color.sv_forest_050);
                chip.setTextColor(ContextCompat.getColor(this, R.color.sv_forest_800));
                chip.setOnClickListener(v -> {
                    Intent intent = new Intent(ResearchDetailActivity.this, MainActivity.class);
                    intent.putExtra("open_tab", "search");
                    intent.putExtra("search_query", kw);
                    startActivity(intent);
                });
                chipGroupKeywords.addView(chip);
            }
        } else {
            keywordsCard.setVisibility(View.GONE);
        }

        // View all in subject shortcut
        tvViewAllRelated.setOnClickListener(v -> {
            Intent intent = new Intent(ResearchDetailActivity.this, MainActivity.class);
            intent.putExtra("open_tab", "search");
            intent.putExtra("category_id", r.categoryId);
            startActivity(intent);
        });

        // Related Research
        relatedContainer.removeAllViews();
        if (r.related != null && !r.related.isEmpty()) {
            relatedCard.setVisibility(View.VISIBLE);
            LayoutInflater inflater = LayoutInflater.from(this);
            for (RelatedResearch rel : r.related) {
                View row = inflater.inflate(R.layout.item_related, relatedContainer, false);
                TextView tvRelTitle = row.findViewById(R.id.tvRelatedTitle);
                TextView tvRelAuthors = row.findViewById(R.id.tvRelatedAuthors);
                TextView tvRelYear = row.findViewById(R.id.tvRelatedYear);

                tvRelTitle.setText(rel.title != null ? rel.title : "Untitled Research");
                tvRelAuthors.setText(rel.researchers != null && !rel.researchers.isEmpty()
                        ? "By " + rel.researchers : "Researchers not listed");
                tvRelYear.setText(rel.year > 0 ? String.valueOf(rel.year) : "N/A");

                row.setOnClickListener(v -> {
                    Intent detailIntent = new Intent(ResearchDetailActivity.this, ResearchDetailActivity.class);
                    detailIntent.putExtra("research_id", rel.researchId);
                    startActivity(detailIntent);
                });
                relatedContainer.addView(row);
            }
        } else {
            relatedCard.setVisibility(View.GONE);
        }
    }
}
