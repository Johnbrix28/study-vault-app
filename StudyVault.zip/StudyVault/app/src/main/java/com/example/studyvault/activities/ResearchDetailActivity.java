package com.example.studyvault.activities;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.studyvault.R;
import com.example.studyvault.api.ApiClient;
import com.example.studyvault.databinding.ActivityResearchDetailBinding;
import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.RelatedResearch;
import com.example.studyvault.models.Research;
import com.google.android.material.chip.Chip;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResearchDetailActivity extends AppCompatActivity {

    private ActivityResearchDetailBinding binding;
    private Research research;

    // ⚠️ Palitan mo ng actual PC IP
    private static final String SERVER_BASE = "http://192.168.100.197/study-vault/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityResearchDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        research = (Research) getIntent().getSerializableExtra("research");
        if (research == null) { finish(); return; }

        // Basic info
        binding.tvTitle.setText(research.title);
        binding.tvAuthors.setText(research.researchers != null ? research.researchers : "Not recorded");
        binding.tvCategoryBadge.setText(research.categoryName != null ? research.categoryName : "Uncategorized");
        binding.tvYearBadge.setText(String.valueOf(research.year));
        binding.tvAbstract.setText(research.abstractText);

        // Keywords
        showKeywords(research.keywords);

        // Download button
        setupDownloadButton();

        // Back button only (no share)
        binding.btnBack.setOnClickListener(v -> finish());

        // View All related
        binding.tvViewAllRelated.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("category_filter", research.categoryId);
            startActivity(intent);
        });

        // Fetch related research
        loadRelatedResearch();
    }

    private void showKeywords(String keywords) {
        binding.chipGroupKeywords.removeAllViews();

        if (keywords == null || keywords.trim().isEmpty()) {
            binding.keywordsCard.setVisibility(View.GONE);
            return;
        }

        binding.keywordsCard.setVisibility(View.VISIBLE);

        for (String part : keywords.split(",")) {
            String kw = part.trim();
            if (kw.isEmpty()) continue;

            Chip chip = new Chip(this);
            chip.setText(kw);
            chip.setChipBackgroundColorResource(R.color.sv_wash);
            chip.setTextColor(getResources().getColor(R.color.sv_dark));
            chip.setChipStrokeColorResource(R.color.sv_line);
            chip.setChipStrokeWidth(2f);
            chip.setClickable(false);
            chip.setCheckable(false);

            binding.chipGroupKeywords.addView(chip);
        }
    }

    private void setupDownloadButton() {
        if (research.filePath == null || research.filePath.trim().isEmpty()) {
            binding.btnDownload.setVisibility(View.GONE);
            binding.tvNoPdf.setVisibility(View.VISIBLE);
        } else {
            binding.btnDownload.setVisibility(View.VISIBLE);
            binding.tvNoPdf.setVisibility(View.GONE);
            binding.btnDownload.setOnClickListener(v -> downloadSoftcopy());
        }
    }

    private void downloadSoftcopy() {
        if (research.filePath == null || research.filePath.trim().isEmpty()) {
            Toast.makeText(this, "No softcopy available", Toast.LENGTH_SHORT).show();
            return;
        }

        String cleanPath = research.filePath.startsWith("/")
                ? research.filePath.substring(1)
                : research.filePath;
        String fullUrl = SERVER_BASE + cleanPath;

        String safeTitle = research.title.replaceAll("[^a-zA-Z0-9]+", "_");
        if (safeTitle.length() > 40) safeTitle = safeTitle.substring(0, 40);
        String fileName = "StudyVault_" + safeTitle + "_" + research.year + ".pdf";

        try {
            DownloadManager.Request request =
                    new DownloadManager.Request(Uri.parse(fullUrl));

            request.setTitle(research.title);
            request.setDescription("Downloading softcopy...");
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, fileName);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);

            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                Toast.makeText(this, "Downloading...", Toast.LENGTH_SHORT).show();
            } else {
                openInBrowser(fullUrl);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show();
            openInBrowser(fullUrl);
        }
    }

    private void openInBrowser(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ex) {
            Toast.makeText(this, "Cannot open file", Toast.LENGTH_LONG).show();
        }
    }

    private void loadRelatedResearch() {
        ApiClient.getService().getResearchDetail(research.researchId)
                .enqueue(new Callback<ApiResponse<Research>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Research>> call,
                                           Response<ApiResponse<Research>> response) {
                        if (response.isSuccessful() && response.body() != null
                                && response.body().data != null) {
                            List<RelatedResearch> related = response.body().data.related;
                            showRelatedResearch(related);
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Research>> call, Throwable t) {
                        // Silent fail
                    }
                });
    }

    private void showRelatedResearch(List<RelatedResearch> related) {
        binding.relatedContainer.removeAllViews();

        if (related == null || related.isEmpty()) {
            binding.relatedCard.setVisibility(View.GONE);
            return;
        }

        binding.relatedCard.setVisibility(View.VISIBLE);

        LayoutInflater inflater = LayoutInflater.from(this);

        for (RelatedResearch item : related) {
            View cardView = inflater.inflate(R.layout.item_related,
                    binding.relatedContainer, false);

            TextView tvTitle = cardView.findViewById(R.id.tvRelatedTitle);
            TextView tvMeta = cardView.findViewById(R.id.tvRelatedMeta);

            tvTitle.setText(item.title);
            tvMeta.setText(item.categoryName + " • " + item.year);

            cardView.setOnClickListener(v -> openRelatedDetail(item.researchId));

            binding.relatedContainer.addView(cardView);
        }
    }

    private void openRelatedDetail(int id) {
        ApiClient.getService().getResearchDetail(id)
                .enqueue(new Callback<ApiResponse<Research>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Research>> call,
                                           Response<ApiResponse<Research>> response) {
                        if (response.isSuccessful() && response.body() != null
                                && response.body().data != null) {
                            Intent intent = new Intent(ResearchDetailActivity.this,
                                    ResearchDetailActivity.class);
                            intent.putExtra("research", response.body().data);
                            startActivity(intent);
                            finish();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Research>> call, Throwable t) {
                        Toast.makeText(ResearchDetailActivity.this,
                                "Failed to load", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}