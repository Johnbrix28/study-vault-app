package com.example.studyvault.api;

import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.Research;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {

    @FormUrlEncoded
    @POST("login.php")
    Call<ApiResponse<Object>> login(
            @Field("student_number") String studentNumber,
            @Field("password") String password
    );

    @FormUrlEncoded
    @POST("register.php")
    Call<ApiResponse<Object>> register(
            @Field("student_number") String studentNumber,
            @Field("first_name") String firstName,
            @Field("last_name") String lastName,
            @Field("password") String password
    );

    @GET("research-list.php")
    Call<ApiResponse<List<Research>>> getResearchList(
            @Query("q") String query,
            @Query("category") Integer categoryId,
            @Query("year") Integer year
    );

    @GET("research-detail.php")
    Call<ApiResponse<Research>> getResearchDetail(@Query("id") int id);

    @GET("suggestions.php")
    Call<List<String>> getSuggestions(@Query("q") String query);
}