package com.example.studyvault.api;

import com.example.studyvault.models.ApiResponse;
import com.example.studyvault.models.HomeData;
import com.example.studyvault.models.ManuscriptMeta;
import com.example.studyvault.models.PlansData;
import com.example.studyvault.models.ProfileData;
import com.example.studyvault.models.Research;
import com.example.studyvault.models.Student;
import com.example.studyvault.models.Subscription;
import com.example.studyvault.models.VerificationData;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.Streaming;

public interface ApiService {

    @FormUrlEncoded
    @POST("login.php")
    Call<ApiResponse<Student>> login(
            @Field("student_id") String studentId,
            @Field("password") String password,
            @Field("device_name") String deviceName
    );

    @POST("logout.php")
    Call<ApiResponse<Object>> logout();

    @FormUrlEncoded
    @POST("verify.php")
    Call<ApiResponse<VerificationData>> verifyStudentId(
            @Field("action") String action,
            @Field("student_id") String studentId,
            @Field("verification_token") String verificationToken,
            @Field("code") String code,
            @Field("password") String password,
            @Field("confirm_password") String confirmPassword
    );

    @GET("home.php")
    Call<ApiResponse<HomeData>> getHomeData();

    @GET("research-list.php")
    Call<ApiResponse<List<Research>>> getResearchList(
            @Query("q") String query,
            @Query("category") Integer categoryId,
            @Query("year") Integer year,
            @Query("sort") String sort,
            @Query("page") Integer page,
            @Query("per_page") Integer perPage
    );

    @GET("research-detail.php")
    Call<ApiResponse<Research>> getResearchDetail(@Query("id") int id);

    @GET("suggestions.php")
    Call<List<String>> getSuggestions(@Query("q") String query);

    @GET("plans.php")
    Call<ApiResponse<PlansData>> getPlans();

    @FormUrlEncoded
    @POST("checkout.php")
    Call<ApiResponse<Subscription>> activateDemoPlan(
            @Field("plan_id") int planId,
            @Field("confirm_demo") int confirmDemo
    );

    @GET("profile.php")
    Call<ApiResponse<ProfileData>> getProfile();

    @GET("manuscript.php")
    Call<ApiResponse<ManuscriptMeta>> getManuscriptMeta(
            @Query("id") int researchId,
            @Query("mode") String mode
    );

    @Streaming
    @GET("manuscript.php")
    Call<ResponseBody> streamManuscript(
            @Query("id") int researchId,
            @Query("mode") String mode
    );
}
