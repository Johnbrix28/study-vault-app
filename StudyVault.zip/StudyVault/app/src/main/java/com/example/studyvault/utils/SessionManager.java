package com.example.studyvault.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import com.example.studyvault.models.Student;
import com.example.studyvault.models.Subscription;

/**
 * Manages authenticated student session state and API base URL.
 * Uses EncryptedSharedPreferences for token & identity storage with safe fallback.
 * Never stores user passwords.
 */
public class SessionManager {
    private static final String PREF_SECURE = "studyvault_secure_session";
    private static final String PREF_FALLBACK = "studyvault_session";

    // Emulator 10.0.2.2 maps to host PC's 127.0.0.1 (XAMPP Apache)
    public static final String EMULATOR_BASE_URL = "http://10.0.2.2/study-vault/api/";
    // Default physical device LAN IP for XAMPP on local Wi-Fi
    public static final String DEFAULT_LAN_BASE_URL = "http://192.168.100.197/study-vault/api/";

    private static final String KEY_STUDENT_ID = "student_id";
    private static final String KEY_NUMBER = "student_number";
    private static final String KEY_NAME = "full_name";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_USER_TYPE = "user_type";
    private static final String KEY_USER_TYPE_LABEL = "user_type_label";
    private static final String KEY_PROGRAM_NAME = "program_name";
    private static final String KEY_STATUS = "status";
    private static final String KEY_HAS_FULL_ACCESS = "has_full_access";
    private static final String KEY_PLAN_NAME = "active_plan_name";
    private static final String KEY_PLAN_EXPIRY = "active_plan_expiry";
    private static final String KEY_TOKEN = "auth_token";
    private static final String KEY_BASE_URL = "api_base_url";

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        Context appCtx = context.getApplicationContext();
        SharedPreferences resolved;
        try {
            MasterKey masterKey = new MasterKey.Builder(appCtx)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            resolved = EncryptedSharedPreferences.create(
                    appCtx,
                    PREF_SECURE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            resolved = appCtx.getSharedPreferences(PREF_FALLBACK, Context.MODE_PRIVATE);
        }
        this.prefs = resolved;
    }

    public void saveStudentSession(Student student, String token) {
        if (student == null) return;

        String resolvedToken = (token != null && !token.trim().isEmpty())
                ? token.trim()
                : (student.token != null ? student.token.trim() : getToken());

        String planName = "Free Access";
        String planExpiry = "";
        if (student.subscription != null) {
            if (student.subscription.planName != null) {
                planName = student.subscription.planName;
            }
            if (student.subscription.expirationDateFormatted != null) {
                planExpiry = student.subscription.expirationDateFormatted;
            } else if (student.subscription.expirationDate != null) {
                planExpiry = student.subscription.expirationDate;
            }
        }

        prefs.edit()
                .putInt(KEY_STUDENT_ID, student.studentId)
                .putString(KEY_NUMBER, safe(student.studentNumber))
                .putString(KEY_NAME, safe(student.fullName))
                .putString(KEY_EMAIL, safe(student.email))
                .putString(KEY_USER_TYPE, safe(student.userType))
                .putString(KEY_USER_TYPE_LABEL, safe(student.userTypeLabel))
                .putString(KEY_PROGRAM_NAME, safe(student.programName))
                .putString(KEY_STATUS, safe(student.status))
                .putBoolean(KEY_HAS_FULL_ACCESS, student.hasFullAccess)
                .putString(KEY_PLAN_NAME, planName)
                .putString(KEY_PLAN_EXPIRY, planExpiry)
                .putString(KEY_TOKEN, safe(resolvedToken))
                .apply();
    }

    public void updateSubscriptionStatus( boolean hasFullAccess, Subscription activeSub) {
        String planName = "Free Access";
        String planExpiry = "";
        if (activeSub != null) {
            if (activeSub.planName != null) planName = activeSub.planName;
            if (activeSub.expirationDateFormatted != null) {
                planExpiry = activeSub.expirationDateFormatted;
            } else if (activeSub.expirationDate != null) {
                planExpiry = activeSub.expirationDate;
            }
        }
        prefs.edit()
                .putBoolean(KEY_HAS_FULL_ACCESS, hasFullAccess)
                .putString(KEY_PLAN_NAME, planName)
                .putString(KEY_PLAN_EXPIRY, planExpiry)
                .apply();
    }

    public boolean isLoggedIn() {
        return prefs.getInt(KEY_STUDENT_ID, 0) > 0 && !getToken().isEmpty();
    }

    public int getStudentId() {
        return prefs.getInt(KEY_STUDENT_ID, 0);
    }

    public String getNumber() {
        return prefs.getString(KEY_NUMBER, "");
    }

    public String getName() {
        return prefs.getString(KEY_NAME, "");
    }

    public String getEmail() {
        return prefs.getString(KEY_EMAIL, "");
    }

    public String getUserType() {
        return prefs.getString(KEY_USER_TYPE, "enrolled");
    }

    public String getUserTypeLabel() {
        String label = prefs.getString(KEY_USER_TYPE_LABEL, "");
        if (label != null && !label.isEmpty()) return label;
        return "alumni".equalsIgnoreCase(getUserType()) ? "IT Alumni" : "Enrolled IT Student";
    }

    public String getProgramName() {
        String prog = prefs.getString(KEY_PROGRAM_NAME, "");
        return (prog != null && !prog.isEmpty())
                ? prog
                : "Bachelor of Science in Information Technology";
    }

    public String getStatus() {
        return prefs.getString(KEY_STATUS, "approved");
    }

    public boolean hasFullAccess() {
        return prefs.getBoolean(KEY_HAS_FULL_ACCESS, false);
    }

    public String getActivePlanName() {
        return prefs.getString(KEY_PLAN_NAME, "Free Access");
    }

    public String getActivePlanExpiry() {
        return prefs.getString(KEY_PLAN_EXPIRY, "");
    }

    public String getToken() {
        return prefs.getString(KEY_TOKEN, "");
    }

    public String getBaseUrl() {
        String saved = prefs.getString(KEY_BASE_URL, "");
        if (saved != null && !saved.trim().isEmpty()) {
            return normalizeBaseUrl(saved);
        }
        return isRunningOnEmulator() ? EMULATOR_BASE_URL : DEFAULT_LAN_BASE_URL;
    }

    public void setBaseUrl(String url) {
        if (url == null || url.trim().isEmpty()) {
            prefs.edit().remove(KEY_BASE_URL).apply();
            return;
        }
        prefs.edit().putString(KEY_BASE_URL, normalizeBaseUrl(url)).apply();
    }

    public static String normalizeBaseUrl(String raw) {
        String u = raw.trim();
        if (!u.startsWith("http://") && !u.startsWith("https://")) {
            u = "http://" + u;
        }
        if (!u.endsWith("/")) {
            u = u + "/";
        }
        if (!u.endsWith("/api/")) {
            if (u.endsWith("/study-vault/")) {
                u = u + "api/";
            } else if (!u.contains("/study-vault/")) {
                u = u + "study-vault/api/";
            }
        }
        return u;
    }

    public static boolean isRunningOnEmulator() {
        return Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MODEL.contains("sdk_gphone")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || "google_sdk".equals(Build.PRODUCT)
                || Build.PRODUCT.contains("sdk")
                || Build.HARDWARE.contains("goldfish")
                || Build.HARDWARE.contains("ranchu");
    }

    public void logout() {
        String savedUrl = prefs.getString(KEY_BASE_URL, "");
        prefs.edit().clear().apply();
        if (savedUrl != null && !savedUrl.isEmpty()) {
            prefs.edit().putString(KEY_BASE_URL, savedUrl).apply();
        }
    }

    private static String safe(String v) {
        return v != null ? v.trim() : "";
    }
}
