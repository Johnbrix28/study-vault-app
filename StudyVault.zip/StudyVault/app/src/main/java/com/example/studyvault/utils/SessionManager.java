package com.example.studyvault.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF = "studyvault_session";
    private static final String KEY_STUDENT_ID = "student_id";
    private static final String KEY_NAME = "name";
    private static final String KEY_NUMBER = "student_number";
    private static final String KEY_FIRST_NAME = "first_name";
    private static final String KEY_LAST_NAME = "last_name";
    private static final String KEY_TOKEN = "token";

    private final SharedPreferences prefs;

    public SessionManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void saveSession(int studentId, String number, String firstName,
                            String lastName, String token) {
        prefs.edit()
                .putInt(KEY_STUDENT_ID, studentId)
                .putString(KEY_NUMBER, number)
                .putString(KEY_FIRST_NAME, firstName)
                .putString(KEY_LAST_NAME, lastName)
                .putString(KEY_NAME, firstName + " " + lastName)
                .putString(KEY_TOKEN, token)
                .apply();
    }

    // Keep old method for backward compatibility
    public void saveSession(int studentId, String number, String name, String token) {
        prefs.edit()
                .putInt(KEY_STUDENT_ID, studentId)
                .putString(KEY_NUMBER, number)
                .putString(KEY_NAME, name)
                .putString(KEY_TOKEN, token)
                .apply();
    }

    public boolean isLoggedIn() {
        return prefs.getInt(KEY_STUDENT_ID, 0) > 0;
    }

    public String getName()      { return prefs.getString(KEY_NAME, ""); }
    public String getFirstName() { return prefs.getString(KEY_FIRST_NAME, ""); }
    public String getLastName()  { return prefs.getString(KEY_LAST_NAME, ""); }
    public String getNumber()    { return prefs.getString(KEY_NUMBER, ""); }
    public String getToken()     { return prefs.getString(KEY_TOKEN, ""); }
    public int    getStudentId() { return prefs.getInt(KEY_STUDENT_ID, 0); }

    public void logout() {
        prefs.edit().clear().apply();
    }
}