<?php

/* ============================================================
   Auth state checks
   ============================================================ */
function is_logged_in(): bool
{
    return !empty($_SESSION['admin_id']);
}

function is_student_logged_in(): bool
{
    return !empty($_SESSION['student_id']);
}

/* ============================================================
   Current user accessors (values cached in the session)
   ============================================================ */
function current_admin(): array
{
    return [
        'admin_id' => $_SESSION['admin_id'] ?? null,
        'name'     => $_SESSION['admin_name'] ?? '',
        'username' => $_SESSION['admin_username'] ?? '',
        'role'     => $_SESSION['admin_role'] ?? '',
    ];
}

function current_student(): array
{
    return [
        'student_id'     => $_SESSION['student_id'] ?? null,
        'student_number' => $_SESSION['student_number'] ?? '',
        'name'           => $_SESSION['student_name'] ?? '',
        'email'          => $_SESSION['student_email'] ?? '',
    ];
}

/** Fresh student row from the database (never trust the session for status). */
function load_student(PDO $pdo, int $id): ?array
{
    $s = $pdo->prepare(
        'SELECT s.*, p.program_name
           FROM students s LEFT JOIN programs p ON p.program_id = s.program_id
          WHERE s.student_id = ? LIMIT 1'
    );
    $s->execute([$id]);
    $row = $s->fetch();
    return $row ?: null;
}

/* ============================================================
   Login handlers
   ============================================================ */
function login_admin(array $a): void
{
    session_regenerate_id(true);

    $_SESSION['admin_id']       = (int) $a['admin_id'];
    $_SESSION['admin_name']     = $a['name'];
    $_SESSION['admin_username'] = $a['username'];
    $_SESSION['admin_role']     = $a['role'];
    $_SESSION['last_activity']  = time();
}

function login_student(array $s): void
{
    session_regenerate_id(true);

    $_SESSION['student_id']            = (int) $s['student_id'];
    $_SESSION['student_number']        = $s['student_number'];
    $_SESSION['student_name']          = $s['full_name'];
    $_SESSION['student_email']         = $s['email'];
    $_SESSION['student_last_activity'] = time();
}

/**
 * Verify Student ID + password for a student.
 * Returns ['ok' => bool, 'student' => ?array, 'error' => string, 'code' => string].
 * Pending / rejected accounts are refused AFTER the password is verified, so
 * the account status is not revealed to someone who does not know the password.
 */
function authenticate_student(PDO $pdo, string $studentIdInput, string $password): array
{
    $studentId = normalize_student_id($studentIdInput);
    $loginKey = 'student-id:' . strtoupper(substr($studentId, 0, 50));

    if ($studentId === '' || $password === '') {
        return [
            'ok'      => false,
            'student' => null,
            'error'   => 'Enter your Student ID and password.',
            'code'    => 'missing_fields',
        ];
    }

    if (login_throttled($pdo, $loginKey)) {
        return [
            'ok'      => false,
            'student' => null,
            'error'   => 'Too many failed attempts. Please wait ' . LOGIN_WINDOW_MINUTES . ' minutes and try again.',
            'code'    => 'throttled',
        ];
    }

    $student = null;
    if (valid_student_id_format($studentId)) {
        $s = $pdo->prepare('SELECT * FROM students WHERE student_number = ? LIMIT 1');
        $s->execute([$studentId]);
        $student = $s->fetch() ?: null;
    }

    // Always run one password check so response time does not reveal unknown IDs.
    $hash = $student['password'] ?? '$2y$10$TybSxSeYHSAJ1KQFBik5zu55FmnXa4hbldYcuXS6bV7bNxtQ5ReMe';
    $passwordOk = password_verify($password, $hash);

    if (!$student || !$passwordOk) {
        record_login_failure($pdo, $loginKey);
        return [
            'ok'      => false,
            'student' => null,
            'error'   => 'Invalid Student ID or password.',
            'code'    => 'invalid_credentials',
        ];
    }

    if ($student['status'] === 'pending') {
        return [
            'ok'      => false,
            'student' => null,
            'error'   => 'Your account is still pending administrator approval. You will be able to log in once it is approved.',
            'code'    => 'pending_approval',
        ];
    }
    if ($student['status'] !== 'approved') {
        return [
            'ok'      => false,
            'student' => null,
            'error'   => 'Your registration was not approved. Please contact the Study Vault administrator.',
            'code'    => 'account_rejected',
        ];
    }

    clear_login_failures($pdo, $loginKey);
    return ['ok' => true, 'student' => $student, 'error' => '', 'code' => 'ok'];
}

/* ============================================================
   Logout handlers
   ============================================================ */
function logout_admin(): void
{
    foreach (['admin_id', 'admin_name', 'admin_username', 'admin_role', 'last_activity'] as $k) {
        unset($_SESSION[$k]);
    }
}

function logout_student(): void
{
    foreach (['student_id', 'student_number', 'student_name', 'student_email', 'student_last_activity'] as $k) {
        unset($_SESSION[$k]);
    }
}

/* ============================================================
   Mobile Bearer Token Authentication (revocable, server-checked)
   ============================================================ */
function ensure_mobile_tokens_table(PDO $pdo): void
{
    static $ensured = false;
    if ($ensured) {
        return;
    }
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `mobile_tokens` (
              `token_id` int NOT NULL AUTO_INCREMENT,
              `student_id` int NOT NULL,
              `token_hash` char(64) NOT NULL,
              `device_name` varchar(120) DEFAULT NULL,
              `expires_at` datetime NOT NULL,
              `revoked` tinyint(1) NOT NULL DEFAULT 0,
              `last_used_at` datetime DEFAULT NULL,
              `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`token_id`),
              UNIQUE KEY `uq_mobile_token_hash` (`token_hash`),
              KEY `idx_mt_student` (`student_id`, `revoked`, `expires_at`),
              CONSTRAINT `fk_mt_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        $ensured = true;
    } catch (PDOException $e) {
        error_log('ensure_mobile_tokens_table failed: ' . $e->getMessage());
    }
}

/** Issue a new 64-character hex token for a signed-in student (valid 30 days). */
function issue_mobile_token(PDO $pdo, int $studentId, ?string $deviceName = null): string
{
    ensure_mobile_tokens_table($pdo);

    $rawToken  = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $rawToken);
    $now       = date('Y-m-d H:i:s');
    $expiresAt = date('Y-m-d H:i:s', time() + 30 * 86400);
    $device    = $deviceName !== null ? mb_substr(clean_text($deviceName), 0, 120) : 'Android Client';

    // Clean up expired or revoked tokens for this student.
    $pdo->prepare('DELETE FROM mobile_tokens WHERE student_id = ? AND (revoked = 1 OR expires_at <= ?)')
        ->execute([$studentId, $now]);

    $stmt = $pdo->prepare(
        'INSERT INTO mobile_tokens (student_id, token_hash, device_name, expires_at, revoked, last_used_at, created_at)
         VALUES (?, ?, ?, ?, 0, ?, ?)'
    );
    $stmt->execute([$studentId, $tokenHash, $device, $expiresAt, $now, $now]);

    return $rawToken;
}

/** Extract Bearer token from Authorization or X-Auth-Token headers. */
function extract_bearer_token(): ?string
{
    $header = '';
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $header = (string) $_SERVER['HTTP_AUTHORIZATION'];
    } elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $header = (string) $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    } elseif (function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) {
            if (strcasecmp((string) $k, 'Authorization') === 0) {
                $header = (string) $v;
                break;
            }
        }
    }

    if ($header !== '' && preg_match('/^\s*Bearer\s+([A-Fa-f0-9]{64})\s*$/', $header, $m)) {
        return strtolower($m[1]);
    }

    $xToken = trim((string) ($_SERVER['HTTP_X_AUTH_TOKEN'] ?? ''));
    if (preg_match('/^[A-Fa-f0-9]{64}$/', $xToken)) {
        return strtolower($xToken);
    }

    return null;
}

/**
 * Look up a mobile token and return the fresh student row.
 * Returns ['status' => 'ok'|'invalid'|'inactive', 'student' => ?array]
 */
function verify_mobile_token_state(PDO $pdo, string $rawToken): array
{
    if (!preg_match('/^[a-f0-9]{64}$/i', $rawToken)) {
        return ['status' => 'invalid', 'student' => null];
    }

    ensure_mobile_tokens_table($pdo);

    $tokenHash = hash('sha256', strtolower($rawToken));
    $now       = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare(
        'SELECT token_id, student_id
           FROM mobile_tokens
          WHERE token_hash = ? AND revoked = 0 AND expires_at > ?
          LIMIT 1'
    );
    $stmt->execute([$tokenHash, $now]);
    $row = $stmt->fetch();

    if (!$row) {
        return ['status' => 'invalid', 'student' => null];
    }

    $student = load_student($pdo, (int) $row['student_id']);
    if (!$student || ($student['status'] ?? '') !== 'approved') {
        // Immediately revoke tokens if the student account was rejected or deleted.
        $pdo->prepare('UPDATE mobile_tokens SET revoked = 1 WHERE student_id = ?')
            ->execute([(int) $row['student_id']]);
        return ['status' => 'inactive', 'student' => $student];
    }

    $pdo->prepare('UPDATE mobile_tokens SET last_used_at = ? WHERE token_id = ?')
        ->execute([$now, (int) $row['token_id']]);

    return ['status' => 'ok', 'student' => $student];
}

function authenticate_mobile_token(PDO $pdo, string $rawToken): ?array
{
    $res = verify_mobile_token_state($pdo, $rawToken);
    return $res['status'] === 'ok' ? $res['student'] : null;
}

function revoke_mobile_token(PDO $pdo, ?string $rawToken = null, ?int $studentId = null): void
{
    ensure_mobile_tokens_table($pdo);

    if ($rawToken !== null && preg_match('/^[a-f0-9]{64}$/i', $rawToken)) {
        $tokenHash = hash('sha256', strtolower($rawToken));
        $pdo->prepare('UPDATE mobile_tokens SET revoked = 1 WHERE token_hash = ?')
            ->execute([$tokenHash]);
    } elseif ($studentId !== null && $studentId > 0) {
        $pdo->prepare('UPDATE mobile_tokens SET revoked = 1 WHERE student_id = ?')
            ->execute([$studentId]);
    }
}

/* ============================================================
   Route guards
   ============================================================ */
function require_admin(): void
{
    if (!is_logged_in()) {
        set_flash('warning', 'Sign in as administrator to continue.');
        redirect(BASE_URL . 'admin/login.php');
    }

    if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > ADMIN_IDLE_TIMEOUT) {
        logout_admin();
        set_flash('warning', 'Your administrator session expired. Please sign in again.');
        redirect(BASE_URL . 'admin/login.php');
    }

    $_SESSION['last_activity'] = time();
}

/**
 * Require a signed-in, APPROVED student. Status is re-checked in the database
 * on every request, so rejecting or deleting an account takes effect immediately.
 * Returns the fresh student row.
 */
function require_student(): array
{
    global $pdo;

    if (!is_student_logged_in()) {
        set_flash('warning', 'Please sign in to access Study Vault.');
        redirect(BASE_URL . 'login.php');
    }

    $idle = time() - (int) ($_SESSION['student_last_activity'] ?? 0);
    if ($idle > STUDENT_IDLE_TIMEOUT) {
        logout_student();
        set_flash('warning', 'Your session expired. Please sign in again.');
        redirect(BASE_URL . 'login.php');
    }

    $student = load_student($pdo, (int) $_SESSION['student_id']);
    if (!$student || $student['status'] !== 'approved') {
        logout_student();
        set_flash('warning', 'Your account is not active. Please contact the administrator.');
        redirect(BASE_URL . 'login.php');
    }

    $_SESSION['student_last_activity'] = time();
    return $student;
}

/**
 * Pages that browsing students AND administrators may open.
 * Returns the student row, or null when an administrator is browsing.
 */
function require_viewer(): ?array
{
    if (is_logged_in() && !is_student_logged_in()) {
        require_admin();
        return null;
    }
    return require_student();
}

/**
 * API guard: supports both Bearer token (native mobile client) and PHP session
 * cookies (web client). Re-verifies account approval on every request.
 */
function api_require_student(): array
{
    global $pdo;

    $bearer = extract_bearer_token();
    if ($bearer !== null) {
        $tokenState = verify_mobile_token_state($pdo, $bearer);
        if ($tokenState['status'] === 'ok' && $tokenState['student']) {
            return $tokenState['student'];
        }
        if ($tokenState['status'] === 'inactive') {
            logout_student();
            json_out([
                'success' => false,
                'code'    => 'account_inactive',
                'message' => 'Your account is no longer active or approved. Please contact the administrator.',
            ], 403);
        }
    }

    if (!is_student_logged_in()) {
        json_out([
            'success' => false,
            'code'    => 'unauthenticated',
            'message' => 'Authentication required. Please sign in again.',
        ], 401);
    }

    $idle = time() - (int) ($_SESSION['student_last_activity'] ?? time());
    if ($idle > STUDENT_IDLE_TIMEOUT) {
        logout_student();
        json_out([
            'success' => false,
            'code'    => 'session_expired',
            'message' => 'Your session expired. Please sign in again.',
        ], 401);
    }

    $student = load_student($pdo, (int) $_SESSION['student_id']);
    if (!$student || $student['status'] !== 'approved') {
        logout_student();
        json_out([
            'success' => false,
            'code'    => 'account_inactive',
            'message' => 'Your account is not active.',
        ], 403);
    }

    $_SESSION['student_last_activity'] = time();
    return $student;
}

/** Read request parameters from either POST form fields or JSON body. */
function api_input(): array
{
    if (!empty($_POST)) {
        return $_POST;
    }
    $raw = file_get_contents('php://input');
    if (is_string($raw) && trim($raw) !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }
    }
    return [];
}
