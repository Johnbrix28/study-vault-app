<?php
require_once __DIR__ . '/includes/bootstrap.php';
$student = is_student_logged_in() ? require_student() : null;
$plans = get_plans($pdo);
$subscription = $student ? get_active_subscription($pdo, (int) $student['student_id']) : null;
$pageTitle = 'Access plans';
require __DIR__ . '/includes/header.php';
?>

<section class="container section plans-section" id="access-plans">
    <div class="section-head">
        <div>
            <p class="eyebrow">Read beyond the abstract</p>
            <h1>Choose your research access</h1>
            <p>Browse approved work for free, or choose a plan to unlock protected full manuscripts.</p>
        </div>
        <span class="access-assurance"><span aria-hidden="true">◈</span> Protected, watermarked reading</span>
    </div>
    <?php if ($plans): ?>
        <?php require __DIR__ . '/includes/plan-options.php'; ?>
    <?php else: ?>
        <p class="text-muted">No access plans are available right now.</p>
    <?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
