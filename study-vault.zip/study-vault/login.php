<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (is_student_logged_in()) {
    redirect(BASE_URL . 'index.php');
}

$error = '';
$studentId = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Your session expired. Please try again.';
    } else {
        $studentId = normalize_student_id($_POST['student_id'] ?? '');
        $password = (string) ($_POST['password'] ?? '');

        $result = authenticate_student($pdo, $studentId, $password);

        if ($result['ok']) {
            login_student($result['student']);
            log_student_activity($pdo, (int) $result['student']['student_id'], 'Student signed in');
            set_flash('success', 'Welcome to Study Vault, ' . $result['student']['full_name'] . '!');
            redirect(BASE_URL . 'index.php');
        }
        $error = $result['error'];
    }
}
$pageTitle = 'Student sign in';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="theme-color" content="#123b2b">
    <title>Student sign in &middot; Study Vault</title>
    <link rel="icon" href="<?= BASE_URL ?>assets/images/isu-logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
</head>
<body class="auth-page student-login-page">
<div class="auth-wrap">
    <div class="auth-layout student-login-layout">
        <aside class="auth-story student-login-story">
            <a class="student-login-brand" href="<?= BASE_URL ?>login.php">
                <img src="<?= BASE_URL ?>assets/images/isu-logo.png" alt="Isabela State University seal">
                <strong>Study Vault</strong>
                <span>Digital Thesis &amp; Research Repository</span>
            </a>
            <div class="student-login-intro">
                <p>Isabela State University's centralized platform for accessing and managing academic research, theses, and dissertations.</p>
                <ul class="student-login-features">
                    <li><span aria-hidden="true">▤</span> Extensive research database</li>
                    <li><span aria-hidden="true">⌕</span> Easy search &amp; discovery</li>
                    <li><span aria-hidden="true">▣</span> Verified student access</li>
                </ul>
            </div>
        </aside>

        <section class="auth-card student-login-card" aria-labelledby="login-heading">
            <p class="auth-kicker">Student &amp; alumni access</p>
            <h1 id="login-heading">Welcome Back</h1>
            <p class="login-sub">Sign in with your Student ID and password.</p>

            <?php render_flashes(); ?>
            <?php if ($error): ?>
                <div class="alert alert-danger" role="alert"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="post" data-validate novalidate>
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label" for="student_id">Student ID</label>
                    <input class="form-control" type="text" id="student_id" name="student_id" required autofocus
                           autocomplete="username" placeholder="e.g. 24-01048" maxlength="50" value="<?= e($studentId) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="password">Password</label>
                    <input class="form-control" type="password" id="password" name="password" required autocomplete="current-password">
                </div>
                <button class="btn btn-primary w-100 auth-submit" type="submit">Sign In</button>
            </form>

            <p class="student-login-create">New to Study Vault? <a href="<?= BASE_URL ?>verify.php">Verify your Student ID</a></p>
            <a class="login-back" href="<?= BASE_URL ?>admin/login.php">Administrator sign in <span aria-hidden="true">&rarr;</span></a>
        </section>
    </div>
</div>
</body>
</html>
