<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../includes/bootstrap.php';

$dryRun = in_array('--dry-run', $argv, true);
$marker = 'FICTIONAL DEMO SAMPLE SET 2026-10-16';
$expected = [
    '[SAMPLE] Campus Network Segmentation Blueprint for a Small Academic Laboratory' => 'storage/manuscripts/sv-demo-2022-networking-security.pdf',
    '[SAMPLE] Offline-First Campus Service Request Portal for Student Support' => 'storage/manuscripts/sv-demo-2023-web-mobile-development.pdf',
    '[SAMPLE] Role-Based Access Control Dashboard for Shared Computing Laboratories' => 'storage/manuscripts/sv-demo-2024-networking-security.pdf',
    '[SAMPLE] Accessible Study Planner for Information Technology Students' => 'storage/manuscripts/sv-demo-2025-web-mobile-development.pdf',
    '[SAMPLE] Lightweight Network Anomaly Monitoring Dashboard: A Demonstration Design' => 'storage/manuscripts/sv-demo-2026-networking-security.pdf',
];

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare(
        'SELECT research_id, title, file_path
           FROM research
          WHERE review_note = ?
          FOR UPDATE'
    );
    $stmt->execute([$marker]);
    $records = $stmt->fetchAll();

    if (count($records) !== count($expected)) {
        throw new RuntimeException('Expected exactly five marked sample records; no changes were made.');
    }

    $files = [];
    foreach ($records as $record) {
        $title = (string) $record['title'];
        if (!isset($expected[$title]) || $record['file_path'] !== $expected[$title]) {
            throw new RuntimeException('A marked record did not match the expected sample set; no changes were made.');
        }
        $files[] = (string) $record['file_path'];
    }

    if ($dryRun) {
        $pdo->rollBack();
        fwrite(STDOUT, 'Dry run: found exactly five marked sample records and their expected PDFs. Nothing was removed.' . PHP_EOL);
        exit(0);
    }

    $delete = $pdo->prepare('DELETE FROM research WHERE research_id = ? AND review_note = ?');
    foreach ($records as $record) {
        $delete->execute([(int) $record['research_id'], $marker]);
        if ($delete->rowCount() !== 1) {
            throw new RuntimeException('A sample record changed during undo; no changes were committed.');
        }
    }

    $pdo->prepare(
        "DELETE FROM authors
          WHERE full_name = 'Study Vault Demonstration Team'
            AND NOT EXISTS (
                SELECT 1 FROM research_authors ra WHERE ra.author_id = authors.author_id
            )"
    )->execute();

    $pdo->commit();
} catch (Throwable $error) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    fwrite(STDOUT, 'Undo failed: ' . $error->getMessage() . PHP_EOL);
    exit(1);
}

$deletedFiles = 0;
foreach ($files as $path) {
    $fullPath = resolve_manuscript_file($path);
    if ($fullPath !== null) {
        if (!unlink($fullPath)) {
            fwrite(STDOUT, 'Database records were removed, but a PDF could not be deleted: ' . basename($path) . PHP_EOL);
            exit(1);
        }
        $deletedFiles++;
    }
}

fwrite(STDOUT, 'Removed five sample research records and ' . $deletedFiles . ' attached PDF files.' . PHP_EOL);
