<?php
/** Local SMTP credentials. Do not commit this file. */
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'jgantala911@gmail.com');
define('MAIL_PASSWORD', 'PASTE_A_NEW_GMAIL_APP_PASSWORD_HERE');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', MAIL_USERNAME);
define('MAIL_FROM_NAME', 'Study Vault');

define('MAIL_SMTP_DEBUG', false);
define('MAIL_DEV_LOG_CODE', false);
define('MAIL_ALLOW_SELF_SIGNED', false);
