<?php
/**
 * Access plans & current subscription status endpoint for Study Vault mobile app.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

$student    = api_require_student();
$studentId  = (int) $student['student_id'];
$activeSub  = get_active_subscription($pdo, $studentId);
$allSubs    = get_student_subscriptions($pdo, $studentId);
$latestSub  = $allSubs[0] ?? null;
$rawPlans   = get_plans($pdo, true);

$plans = [];
foreach ($rawPlans as $p) {
    $isFree     = (int) $p['full_access'] === 0 || (float) $p['price'] <= 0;
    $isCurrent  = $activeSub
        ? ((int) $activeSub['plan_id'] === (int) $p['plan_id'])
        : $isFree;
    $isFeatured = (int) $p['sort_order'] === 2;

    $features = [
        'Browse approved research',
        'Search by title, author, keyword and more',
        'Read abstracts and research details',
    ];
    if (!$isFree) {
        $features[] = 'Protected full manuscript viewing';
        $features[] = ((int) $p['duration_days']) . ' days of access';
    } else {
        $features[] = 'Full manuscripts not included';
    }

    $plans[] = [
        'plan_id'         => (int) $p['plan_id'],
        'plan_name'       => $p['plan_name'],
        'description'     => $p['description'],
        'price'           => (float) $p['price'],
        'price_formatted' => format_price($p['price']),
        'duration_days'   => (int) $p['duration_days'],
        'full_access'     => (int) $p['full_access'] === 1,
        'is_free'         => $isFree,
        'is_current'      => $isCurrent,
        'is_featured'     => $isFeatured,
        'sort_order'      => (int) $p['sort_order'],
        'features'        => $features,
    ];
}

$activeSubPayload = null;
if ($activeSub) {
    $activeSubPayload = [
        'subscription_id'           => (int) $activeSub['subscription_id'],
        'plan_id'                   => (int) $activeSub['plan_id'],
        'plan_name'                 => $activeSub['plan_name'],
        'status'                    => $activeSub['status'],
        'reference_code'            => $activeSub['reference_code'],
        'amount_paid'               => (float) $activeSub['amount_paid'],
        'amount_formatted'          => format_price($activeSub['amount_paid']),
        'payment_mode'              => $activeSub['payment_mode'],
        'start_date'                => $activeSub['start_date'],
        'start_date_formatted'      => format_datetime($activeSub['start_date']),
        'expiration_date'           => $activeSub['expiration_date'],
        'expiration_date_formatted' => format_datetime($activeSub['expiration_date']),
    ];
}

$expiredSubPayload = null;
if (!$activeSub && $latestSub && $latestSub['status'] === 'expired') {
    $expiredSubPayload = [
        'plan_name'                 => $latestSub['plan_name'],
        'status'                    => 'expired',
        'expiration_date'           => $latestSub['expiration_date'],
        'expiration_date_formatted' => format_datetime($latestSub['expiration_date']),
    ];
}

json_out([
    'success' => true,
    'data'    => [
        'plans'                => $plans,
        'has_full_access'      => $activeSub !== null,
        'active_subscription'  => $activeSubPayload,
        'expired_subscription' => $expiredSubPayload,
        'payment_mode'         => PAYMENT_MODE,
        'demo_notice'          => 'Prototype only. This is a demonstration checkout. No card or e-wallet is charged and no payment gateway is connected. A real payment provider must be integrated before production use.',
    ],
]);
