<?php
/**
 * Protected manuscript endpoint for the native Study Vault mobile app:
 *   GET api/manuscript.php?id=123&mode=meta   -> returns watermark lines & authorization metadata
 *   GET api/manuscript.php?id=123&mode=stream -> streams the protected PDF binary (never exposes file_path)
 *
 * Re-verifies authentication, account approval, research approval, and active unexpired
 * paid subscription on EVERY request.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

$student = api_require_student();
$id      = valid_id($_GET['id'] ?? null);
$mode    = ($_GET['mode'] ?? 'stream') === 'meta' ? 'meta' : 'stream';

if (!$id) {
    json_out([
        'success' => false,
        'code'    => 'invalid_id',
        'message' => 'Invalid research record ID.',
    ], 400);
}

$stmt = $pdo->prepare(
    'SELECT r.research_id, r.title, r.year, r.status, r.file_path, c.category_name
       FROM research r
       JOIN categories c ON c.category_id = r.category_id
      WHERE r.research_id = ?
      LIMIT 1'
);
$stmt->execute([$id]);
$record = $stmt->fetch();

if (!$record || $record['status'] !== 'approved') {
    json_out([
        'success' => false,
        'code'    => 'not_found',
        'message' => 'This research manuscript is not available.',
    ], 404);
}

$access = check_manuscript_access($pdo, $record, $student, false);
if (!$access['allowed']) {
    $httpCode = $access['code'] === 'no_file' ? 404 : 403;
    json_out([
        'success' => false,
        'code'    => $access['code'],
        'message' => $access['reason'],
    ], $httpCode);
}

$path = resolve_manuscript_file($record['file_path']);
if ($path === null) {
    json_out([
        'success' => false,
        'code'    => 'no_file',
        'message' => 'No manuscript has been uploaded for this record.',
    ], 404);
}

$activeSub  = get_active_subscription($pdo, (int) $student['student_id']);
$userIdent  = !empty($student['email']) ? $student['email'] : $student['full_name'];
$timestamp  = date('M j, Y g:i A');
$wmLines    = [
    'STUDY VAULT',
    'Authorized User: ' . $userIdent,
    'Student ID: ' . $student['student_number'],
    'CONFIDENTIAL',
    $timestamp,
];

if ($mode === 'meta') {
    json_out([
        'success' => true,
        'data'    => [
            'research_id'             => (int) $record['research_id'],
            'title'                   => $record['title'],
            'year'                    => (int) $record['year'],
            'category_name'           => $record['category_name'],
            'authorized_user'         => $userIdent,
            'student_number'          => $student['student_number'],
            'timestamp'               => $timestamp,
            'watermark_lines'         => $wmLines,
            'subscription_plan'       => $activeSub['plan_name'] ?? 'Research Access',
            'subscription_expires_at' => isset($activeSub['expiration_date']) ? format_datetime($activeSub['expiration_date']) : null,
        ],
    ]);
}

log_student_activity(
    $pdo,
    (int) $student['student_id'],
    'Opened protected manuscript #' . $id . ' (Mobile): ' . $record['title']
);

session_write_close();

while (ob_get_level() > 0) {
    ob_end_clean();
}

header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="manuscript-' . (int) $id . '.pdf"');
header('Content-Length: ' . filesize($path));
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex, noarchive');
header('X-Watermark-User: ' . rawurlencode((string) $userIdent));
header('X-Watermark-Student-Id: ' . rawurlencode((string) $student['student_number']));
header('X-Watermark-Timestamp: ' . rawurlencode($timestamp));

readfile($path);
exit;
