<?php
/**
 * PROTOTYPE checkout endpoint for Study Vault mobile application.
 * No money moves and no payment gateway is connected.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_out(['success' => false, 'message' => 'Use POST.'], 405);
}

$student = api_require_student();
$in      = api_input();

$planId      = valid_id($in['plan_id'] ?? $in['plan'] ?? null);
$confirmDemo = !empty($in['confirm_demo']) && $in['confirm_demo'] !== 'false' && $in['confirm_demo'] !== '0';

if (!$confirmDemo) {
    json_out([
        'success' => false,
        'code'    => 'confirm_required',
        'message' => 'Please confirm that you understand this is a demo checkout and no real payment is made.',
    ], 400);
}

$plan = $planId ? get_plan($pdo, (int) $planId) : null;
if (!$plan || $plan['status'] !== 'active' || (int) $plan['full_access'] !== 1 || (float) $plan['price'] <= 0) {
    json_out([
        'success' => false,
        'code'    => 'invalid_plan',
        'message' => 'That access plan is not available.',
    ], 400);
}

try {
    $completed = create_demo_subscription($pdo, (int) $student['student_id'], $plan);
    log_student_activity(
        $pdo,
        (int) $student['student_id'],
        'Demo checkout (API): activated "' . $plan['plan_name'] . '" (' . $completed['reference_code'] . ')'
    );

    json_out([
        'success' => true,
        'message' => 'Your ' . $plan['plan_name'] . ' plan is now active (demo). No real payment was taken.',
        'data'    => [
            'subscription_id'           => (int) $completed['subscription_id'],
            'plan_id'                   => (int) $plan['plan_id'],
            'plan_name'                 => $plan['plan_name'],
            'duration_days'             => (int) $plan['duration_days'],
            'reference_code'            => $completed['reference_code'],
            'amount_paid'               => (float) $completed['amount_paid'],
            'amount_formatted'          => format_price($completed['amount_paid']),
            'payment_mode'              => $completed['payment_mode'],
            'status'                    => $completed['status'],
            'start_date'                => $completed['start_date'],
            'start_date_formatted'      => format_datetime($completed['start_date']),
            'expiration_date'           => $completed['expiration_date'],
            'expiration_date_formatted' => format_datetime($completed['expiration_date']),
        ],
    ]);
} catch (Throwable $ex) {
    error_log('Mobile demo checkout failed: ' . $ex->getMessage());
    json_out([
        'success' => false,
        'code'    => 'checkout_failed',
        'message' => 'The plan could not be activated. Please try again.',
    ], 500);
}
