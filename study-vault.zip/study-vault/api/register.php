<?php
require_once __DIR__ . '/../includes/bootstrap.php';

// Registration requires Student ID verification by email code (verify.php / api/verify.php).
// If a client sends a verification step action here, delegate to api/verify.php;
// otherwise reject direct unverified registration requests with HTTP 410.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_out(['success' => false, 'message' => 'Use POST.'], 405);
}

$in = api_input();
if (!empty($in['action'])) {
    require __DIR__ . '/verify.php';
    exit;
}

json_out([
    'success' => false,
    'code'    => 'verification_required',
    'message' => 'Registration now requires Student ID verification. Use the Student ID verification workflow.',
], 410);
