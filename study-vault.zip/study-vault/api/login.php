<?php
require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_out(['success' => false, 'message' => 'Use POST.'], 405);
}

$in = api_input();
$studentIdInput = (string) ($in['student_id'] ?? $in['student_number'] ?? '');
$password       = (string) ($in['password'] ?? '');
$deviceName     = isset($in['device_name']) ? (string) $in['device_name'] : 'Study Vault Android';

$result = authenticate_student($pdo, $studentIdInput, $password);

if (!$result['ok']) {
    $code = (string) ($result['code'] ?? 'invalid_credentials');
    $httpStatus = 401;
    if (in_array($code, ['pending_approval', 'account_rejected'], true)) {
        $httpStatus = 403;
    } elseif ($code === 'throttled') {
        $httpStatus = 429;
    }
    json_out([
        'success' => false,
        'code'    => $code,
        'message' => $result['error'],
    ], $httpStatus);
}

$s = load_student($pdo, (int) $result['student']['student_id']) ?: $result['student'];
login_student($s);

$token = issue_mobile_token($pdo, (int) $s['student_id'], $deviceName);
$sub   = get_active_subscription($pdo, (int) $s['student_id']);

log_student_activity($pdo, (int) $s['student_id'], 'Student signed in (API)');

$subData = null;
if ($sub) {
    $subData = [
        'subscription_id'           => (int) $sub['subscription_id'],
        'plan_id'                   => (int) $sub['plan_id'],
        'plan_name'                 => $sub['plan_name'],
        'status'                    => $sub['status'],
        'reference_code'            => $sub['reference_code'],
        'start_date'                => $sub['start_date'],
        'start_date_formatted'      => format_datetime($sub['start_date']),
        'expiration_date'           => $sub['expiration_date'],
        'expiration_date_formatted' => format_datetime($sub['expiration_date']),
    ];
}

// Only the signed-in user's OWN basic profile is returned. No password, no file paths.
json_out([
    'success' => true,
    'message' => 'Login successful',
    'token'   => $token,
    'data'    => [
        'student_id'      => (int) $s['student_id'],
        'full_name'       => $s['full_name'],
        'email'           => $s['email'],
        'student_number'  => $s['student_number'],
        'user_type'       => $s['user_type'],
        'user_type_label' => user_type_label($s['user_type']),
        'program_id'      => isset($s['program_id']) ? (int) $s['program_id'] : null,
        'program_name'    => $s['program_name'] ?? 'Bachelor of Science in Information Technology',
        'status'          => $s['status'],
        'has_full_access' => $sub !== null,
        'subscription'    => $subData,
        'token'           => $token,
    ],
]);
