<?php
/**
 * Mobile & JSON API for the 3-step Student ID Verification & Registration workflow.
 * Mirrors verify.php and uses all server-side rules in includes/verification.php.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_out(['success' => false, 'message' => 'Use POST.'], 405);
}

function verify_hmac_key(): string
{
    return hash_hmac(
        'sha256',
        BASE_PATH . '|' . DB_HOST . '|' . DB_NAME . '|' . DB_USER,
        'study-vault-verify-token-v1-' . DB_PASS
    );
}

function pack_verify_token(array $state): string
{
    $payload = base64_encode((string) json_encode([
        'record_id'   => (int) ($state['record_id'] ?? 0),
        'sent_at'     => (int) ($state['sent_at'] ?? 0),
        'verified_at' => (int) ($state['verified_at'] ?? 0),
        'exp'         => time() + VERIFY_PASSWORD_WINDOW + 300,
    ]));
    $sig = hash_hmac('sha256', $payload, verify_hmac_key());
    return $payload . '.' . $sig;
}

function unpack_verify_token(string $token): ?array
{
    $parts = explode('.', trim($token), 2);
    if (count($parts) !== 2) {
        return null;
    }
    [$payload, $sig] = $parts;
    $expected = hash_hmac('sha256', $payload, verify_hmac_key());
    if (!hash_equals($expected, $sig)) {
        return null;
    }
    $raw = base64_decode($payload, true);
    if ($raw === false) {
        return null;
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || empty($data['record_id']) || ($data['exp'] ?? 0) < time()) {
        return null;
    }
    return $data;
}

function build_student_preview(array $record): array
{
    $userType = ($record['status'] ?? '') === 'alumni' ? 'alumni' : 'enrolled';
    return [
        'student_id'      => $record['student_id'],
        'full_name'       => $record['full_name'],
        'masked_email'    => mask_email((string) ($record['email'] ?? '')),
        'program'         => $record['program'] ?? 'BSIT',
        'section'         => $record['section'] ?? '',
        'user_type'       => $userType,
        'user_type_label' => user_type_label($userType),
        'graduation_year' => $record['graduation_year'] !== null ? (int) $record['graduation_year'] : null,
    ];
}

$in     = api_input();
$action = trim((string) ($in['action'] ?? ''));

// Resolve verification state from HMAC token or server session.
$tokenInput = trim((string) ($in['verification_token'] ?? ''));
$state = [];
if ($tokenInput !== '') {
    $unpacked = unpack_verify_token($tokenInput);
    if ($unpacked !== null) {
        $state = $unpacked;
        verify_state_set($state);
    }
}
if (empty($state)) {
    $state = verify_state();
}

if ($action === 'restart') {
    verify_state_clear();
    json_out([
        'success' => true,
        'message' => 'Verification reset.',
        'data'    => ['step' => 1],
    ]);
}

/* ---------- STEP 1: Student ID -> send verification code ---------- */
if ($action === 'send_code') {
    $studentId = normalize_student_id($in['student_id'] ?? $in['student_number'] ?? '');

    if (verify_lookup_throttled($pdo)) {
        json_out([
            'success' => false,
            'code'    => 'throttled',
            'message' => 'Too many attempts. Please wait ' . LOGIN_WINDOW_MINUTES . ' minutes and try again.',
        ], 429);
    }

    if (!valid_student_id_format($studentId)) {
        json_out([
            'success' => false,
            'code'    => 'invalid_student_id',
            'message' => 'Enter a valid Student ID (for example 24-01048).',
        ], 400);
    }

    $rec = find_school_record($pdo, $studentId);
    if (!$rec) {
        verify_lookup_failed($pdo);
        json_out([
            'success' => false,
            'code'    => 'not_found',
            'message' => 'Student ID not found in the school database.',
        ], 404);
    }

    if (!school_record_eligibility($rec)['ok']) {
        verify_lookup_failed($pdo);
        json_out([
            'success' => false,
            'code'    => 'not_eligible',
            'message' => 'Not eligible for Study Vault. Only enrolled students and alumni of the IT programs can register.',
        ], 403);
    }

    $acct = school_record_account_state($pdo, $rec);
    if ($acct['state'] === 'linked') {
        json_out([
            'success'    => false,
            'code'       => 'already_linked',
            'show_login' => true,
            'message'    => 'This Student ID is already linked to an account. Please log in.',
        ], 409);
    }
    if ($acct['state'] === 'email_taken') {
        json_out([
            'success' => false,
            'code'    => 'email_taken',
            'message' => 'The school email address for this Student ID is already used by another account. Please contact the administrator.',
        ], 409);
    }

    if (verification_hourly_limit_reached($pdo, (int) $rec['id'])) {
        json_out([
            'success' => false,
            'code'    => 'hourly_limit',
            'message' => 'Too many codes were requested for this Student ID. Please try again in an hour.',
        ], 429);
    }

    $wait = verification_resend_wait($pdo, (int) $rec['id']);
    if ($wait > 0) {
        $newState = ['record_id' => (int) $rec['id'], 'sent_at' => time() - (VERIFY_RESEND_SECONDS - $wait), 'verified_at' => 0];
        verify_state_set($newState);
        json_out([
            'success' => true,
            'code'    => 'cooldown_active',
            'message' => 'A verification code was recently sent to ' . mask_email((string) $rec['email']) . '. Please check your inbox or wait ' . $wait . ' seconds to resend.',
            'data'    => [
                'step'               => 2,
                'verification_token' => pack_verify_token($newState),
                'masked_email'       => mask_email((string) $rec['email']),
                'resend_wait'        => (int) $wait,
                'ttl_minutes'        => (int) VERIFY_CODE_TTL_MINUTES,
                'student_preview'    => build_student_preview($rec),
            ],
        ]);
    }

    $sent = issue_and_send_code($pdo, $rec);
    if (!$sent['ok']) {
        json_out([
            'success' => false,
            'code'    => 'mail_error',
            'message' => $sent['error'],
        ], 500);
    }

    $newState = ['record_id' => (int) $rec['id'], 'sent_at' => time(), 'verified_at' => 0];
    verify_state_set($newState);
    log_student_activity($pdo, null, 'Verification code sent for Student ID ' . $rec['student_id'] . ' (API)');

    $masked = mask_email((string) $rec['email']);
    json_out([
        'success' => true,
        'message' => 'A 6-digit verification code was sent to ' . $masked . '. It expires in ' . VERIFY_CODE_TTL_MINUTES . ' minutes.',
        'data'    => [
            'step'               => 2,
            'verification_token' => pack_verify_token($newState),
            'masked_email'       => $masked,
            'resend_wait'        => (int) VERIFY_RESEND_SECONDS,
            'ttl_minutes'        => (int) VERIFY_CODE_TTL_MINUTES,
            'student_preview'    => build_student_preview($rec),
        ],
    ]);
}

/* ---------- STEP 2A: Resend verification code ---------- */
if ($action === 'resend') {
    $recordId = (int) ($state['record_id'] ?? 0);
    $record   = $recordId > 0 ? get_school_record($pdo, $recordId) : null;

    if (!$record) {
        verify_state_clear();
        json_out([
            'success' => false,
            'code'    => 'session_expired',
            'restart' => true,
            'message' => 'Your verification session expired. Please enter your Student ID again.',
        ], 400);
    }

    if (verification_hourly_limit_reached($pdo, (int) $record['id'])) {
        json_out([
            'success' => false,
            'code'    => 'hourly_limit',
            'message' => 'Too many codes were requested for this Student ID. Please try again in an hour.',
        ], 429);
    }

    $wait = verification_resend_wait($pdo, (int) $record['id']);
    if ($wait > 0) {
        json_out([
            'success' => false,
            'code'    => 'resend_wait',
            'message' => 'Please wait ' . $wait . ' seconds before requesting another code.',
            'data'    => [
                'step'               => 2,
                'verification_token' => pack_verify_token($state),
                'masked_email'       => mask_email((string) $record['email']),
                'resend_wait'        => (int) $wait,
                'ttl_minutes'        => (int) VERIFY_CODE_TTL_MINUTES,
                'student_preview'    => build_student_preview($record),
            ],
        ], 429);
    }

    $sent = issue_and_send_code($pdo, $record);
    if (!$sent['ok']) {
        json_out([
            'success' => false,
            'code'    => 'mail_error',
            'message' => $sent['error'],
        ], 500);
    }

    $newState = ['record_id' => (int) $record['id'], 'sent_at' => time(), 'verified_at' => 0];
    verify_state_set($newState);
    $masked = mask_email((string) $record['email']);

    json_out([
        'success' => true,
        'message' => 'A new code was sent to ' . $masked . '. Earlier codes no longer work.',
        'data'    => [
            'step'               => 2,
            'verification_token' => pack_verify_token($newState),
            'masked_email'       => $masked,
            'resend_wait'        => (int) VERIFY_RESEND_SECONDS,
            'ttl_minutes'        => (int) VERIFY_CODE_TTL_MINUTES,
            'student_preview'    => build_student_preview($record),
        ],
    ]);
}

/* ---------- STEP 2B: Verify 6-digit email code ---------- */
if ($action === 'verify_code') {
    $recordId = (int) ($state['record_id'] ?? 0);
    $record   = $recordId > 0 ? get_school_record($pdo, $recordId) : null;

    if (!$record) {
        verify_state_clear();
        json_out([
            'success' => false,
            'code'    => 'session_expired',
            'restart' => true,
            'message' => 'Your verification session expired. Please enter your Student ID again.',
        ], 400);
    }

    $codeInput = (string) ($in['code'] ?? '');
    $result    = check_verification_code($pdo, (int) $record['id'], $codeInput);

    if (!$result['ok']) {
        json_out([
            'success' => false,
            'code'    => 'invalid_code',
            'restart' => (bool) ($result['restart'] ?? false),
            'message' => $result['error'],
            'data'    => [
                'step'               => 2,
                'verification_token' => pack_verify_token($state),
                'masked_email'       => mask_email((string) $record['email']),
                'resend_wait'        => verification_resend_wait($pdo, (int) $record['id']),
                'student_preview'    => build_student_preview($record),
            ],
        ], 400);
    }

    session_regenerate_id(true);
    $newState = ['record_id' => (int) $record['id'], 'sent_at' => (int) ($state['sent_at'] ?? time()), 'verified_at' => time()];
    verify_state_set($newState);

    json_out([
        'success' => true,
        'message' => 'Email verified. Now create your password.',
        'data'    => [
            'step'               => 3,
            'verification_token' => pack_verify_token($newState),
            'masked_email'       => mask_email((string) $record['email']),
            'student_preview'    => build_student_preview($record),
        ],
    ]);
}

/* ---------- STEP 3: Create password & finalize account ---------- */
if ($action === 'create_account') {
    $recordId   = (int) ($state['record_id'] ?? 0);
    $verifiedAt = (int) ($state['verified_at'] ?? 0);
    $record     = $recordId > 0 ? get_school_record($pdo, $recordId) : null;

    if (!$record || $verifiedAt <= 0 || (time() - $verifiedAt > VERIFY_PASSWORD_WINDOW)) {
        verify_state_clear();
        json_out([
            'success' => false,
            'code'    => 'session_expired',
            'restart' => true,
            'message' => 'Your verification window expired. Please verify your Student ID again.',
        ], 400);
    }

    $password = (string) ($in['password'] ?? '');
    $confirm  = (string) ($in['confirm_password'] ?? '');

    $result = create_verified_account($pdo, (int) $record['id'], $password, $confirm);

    if (!$result['ok']) {
        $errors = $result['errors'] ?? [];
        $firstError = reset($errors) ?: 'Could not create account.';
        json_out([
            'success' => false,
            'code'    => 'validation_error',
            'message' => (string) $firstError,
            'errors'  => $errors,
            'data'    => [
                'step'               => 3,
                'verification_token' => pack_verify_token($state),
                'student_preview'    => build_student_preview($record),
            ],
        ], 400);
    }

    verify_state_clear();
    $createdStudent = $result['student_id'] ? load_student($pdo, (int) $result['student_id']) : null;
    $acctStatus     = $createdStudent['status'] ?? 'approved';
    $isPending      = $acctStatus === 'pending';

    $msg = $isPending
        ? 'Your account was created and is pending administrator approval. You will be able to sign in once approved.'
        : 'Your account was created and verified! Sign in with Student ID ' . $record['student_id'] . ' and your new password.';

    json_out([
        'success' => true,
        'message' => $msg,
        'data'    => [
            'step'              => 4,
            'student_number'    => $record['student_id'],
            'full_name'         => $record['full_name'],
            'account_status'    => $acctStatus,
            'requires_approval' => $isPending,
        ],
    ]);
}

json_out([
    'success' => false,
    'code'    => 'invalid_action',
    'message' => 'Specify a valid verification action (send_code, verify_code, resend, create_account).',
], 400);
