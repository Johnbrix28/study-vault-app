<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$student    = api_require_student();
$fullAccess = student_has_full_access($pdo, (int) $student['student_id']);

$q        = clean_text($_GET['q'] ?? '');
$category = valid_id($_GET['category'] ?? null);
$year     = filter_var($_GET['year'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1990, 'max_range' => 2100]]);
$sort     = ($_GET['sort'] ?? 'newest') === 'oldest' ? 'oldest' : 'newest';
$page     = max(1, (int) ($_GET['page'] ?? 1));
$perPage  = min(50, max(1, (int) ($_GET['per_page'] ?? 20)));

// Approved research only.
$where  = ["r.status = 'approved'"];
$params = [];

if ($q !== '') {
    $where[] = '(r.title LIKE :q1 OR r.abstract LIKE :q2 OR r.keywords LIKE :q3 OR c.category_name LIKE :q4
                 OR CAST(r.year AS CHAR) = :q5
                 OR EXISTS(SELECT 1 FROM research_authors ra JOIN authors a ON a.author_id = ra.author_id
                            WHERE ra.research_id = r.research_id AND a.full_name LIKE :q6))';
    $like = '%' . $q . '%';
    $params += [
        ':q1' => $like,
        ':q2' => $like,
        ':q3' => $like,
        ':q4' => $like,
        ':q5' => $q,
        ':q6' => $like,
    ];
}
if ($category) {
    $where[]        = 'r.category_id = :cat';
    $params[':cat'] = $category;
}
if ($year) {
    $where[]       = 'r.year = :yr';
    $params[':yr'] = $year;
}

$ws = 'WHERE ' . implode(' AND ', $where);

$cnt = $pdo->prepare("SELECT COUNT(*) FROM research r JOIN categories c ON c.category_id = r.category_id $ws");
$cnt->execute($params);
$total      = (int) $cnt->fetchColumn();
$totalPages = max(1, (int) ceil($total / $perPage));
$offset     = ($page - 1) * $perPage;

$orderBy = $sort === 'oldest'
    ? 'ORDER BY r.published_date ASC, r.research_id ASC'
    : 'ORDER BY r.published_date DESC, r.research_id DESC';

$stmt = $pdo->prepare("
    SELECT r.research_id, r.title, r.abstract, r.year, r.published_date, r.keywords,
           r.file_path, c.category_id, c.category_name, p.program_name,
           (SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
              FROM research_authors ra JOIN authors a ON a.author_id = ra.author_id
             WHERE ra.research_id = r.research_id) AS researchers
      FROM research r
      JOIN categories c ON c.category_id = r.category_id
      LEFT JOIN programs p ON p.program_id = r.program_id
      $ws
      $orderBy
      LIMIT " . (int) $perPage . ' OFFSET ' . (int) $offset);
$stmt->execute($params);

$rows = [];
foreach ($stmt->fetchAll() as $row) {
    $has = research_file_exists($row['file_path']);
    unset($row['file_path']);

    $row['research_id']              = (int) $row['research_id'];
    $row['category_id']              = (int) $row['category_id'];
    $row['year']                     = (int) $row['year'];
    $row['excerpt']                  = excerpt($row['abstract'], 180);
    $row['published_date_formatted'] = format_date($row['published_date']);
    $row['program_name']             = $row['program_name'] ?? 'Bachelor of Science in Information Technology';
    $row['has_manuscript']           = $has;
    $row['can_view_manuscript']      = $has && $fullAccess;
    // No file_path. The protected route is given ONLY to users who may use it.
    $row['manuscript_url']           = ($has && $fullAccess) ? manuscript_viewer_url($row['research_id']) : null;
    $rows[] = $row;
}

$cats = [];
foreach (get_categories($pdo) as $c) {
    $cats[] = [
        'category_id'   => (int) $c['category_id'],
        'category_name' => $c['category_name'],
        'description'   => $c['description'],
    ];
}

json_out([
    'success' => true,
    'data'    => $rows,
    'meta'    => [
        'page'        => $page,
        'per_page'    => $perPage,
        'total'       => $total,
        'total_pages' => $totalPages,
        'has_more'    => $page < $totalPages,
    ],
    'filters' => [
        'categories' => $cats,
        'years'      => array_map('intval', get_research_years($pdo, true)),
    ],
]);
