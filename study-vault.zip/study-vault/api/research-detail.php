<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$student = api_require_student();

$id = valid_id($_GET['id'] ?? null);
if (!$id) {
    json_out(['success' => false, 'message' => 'Missing or invalid ID.'], 400);
}

$stmt = $pdo->prepare("
    SELECT r.research_id, r.title, r.abstract, r.year, r.published_date, r.keywords, r.category_id,
           r.status, r.file_path, r.view_count, c.category_name, p.program_name,
           (SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
              FROM research_authors ra JOIN authors a ON a.author_id = ra.author_id
             WHERE ra.research_id = r.research_id) AS researchers
      FROM research r
      JOIN categories c ON c.category_id = r.category_id
      LEFT JOIN programs p ON p.program_id = r.program_id
     WHERE r.research_id = ? AND r.status = 'approved'
     LIMIT 1");
$stmt->execute([$id]);
$row = $stmt->fetch();

if (!$row) {
    json_out(['success' => false, 'message' => 'Research record not found.'], 404);
}

$pdo->prepare('UPDATE research SET view_count = view_count + 1 WHERE research_id = ?')->execute([$id]);

$access  = check_manuscript_access($pdo, $row, $student, false);
$hasFile = research_file_exists($row['file_path']);

$rel = $pdo->prepare("
    SELECT r.research_id, r.title, r.year, r.file_path, c.category_id, c.category_name,
           (SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
              FROM research_authors ra JOIN authors a ON a.author_id = ra.author_id
             WHERE ra.research_id = r.research_id) AS researchers
      FROM research r
      JOIN categories c ON c.category_id = r.category_id
     WHERE r.category_id = ? AND r.research_id <> ? AND r.status = 'approved'
     ORDER BY r.published_date DESC
     LIMIT 4");
$rel->execute([$row['category_id'], $id]);

$relatedList = [];
foreach ($rel->fetchAll() as $relRow) {
    $relatedList[] = [
        'research_id'    => (int) $relRow['research_id'],
        'title'          => $relRow['title'],
        'year'           => (int) $relRow['year'],
        'category_id'    => (int) $relRow['category_id'],
        'category_name'  => $relRow['category_name'],
        'researchers'    => $relRow['researchers'],
        'has_manuscript' => research_file_exists($relRow['file_path']),
    ];
}

$data = [
    'research_id'              => (int) $row['research_id'],
    'title'                    => $row['title'],
    'abstract'                 => $row['abstract'],
    'year'                     => (int) $row['year'],
    'published_date'           => $row['published_date'],
    'published_date_formatted' => format_date($row['published_date']),
    'keywords'                 => $row['keywords'],
    'keyword_list'             => keyword_list($row['keywords']),
    'category_id'              => (int) $row['category_id'],
    'category_name'            => $row['category_name'],
    'program_name'             => $row['program_name'] ?? 'Bachelor of Science in Information Technology',
    'researchers'              => $row['researchers'],
    'has_manuscript'           => $hasFile,
    'can_view_manuscript'      => $access['allowed'],
    'access_code'              => $access['code'],
    'access_reason'            => $access['reason'],
    'manuscript_url'           => $access['allowed'] ? manuscript_viewer_url((int) $row['research_id']) : null,
    'related'                  => $relatedList,
];
// Deliberately NOT returned: file_path, status internals, other users' data.

json_out(['success' => true, 'data' => $data]);
