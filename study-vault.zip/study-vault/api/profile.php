<?php
/**
 * Authenticated student profile & subscription history endpoint.
 * Never returns another user's data or password hashes.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

$student    = api_require_student();
$studentId  = (int) $student['student_id'];
$activeSub  = get_active_subscription($pdo, $studentId);
$historyRaw = get_student_subscriptions($pdo, $studentId);

$activeSubPayload = null;
if ($activeSub) {
    $activeSubPayload = [
        'subscription_id'           => (int) $activeSub['subscription_id'],
        'plan_id'                   => (int) $activeSub['plan_id'],
        'plan_name'                 => $activeSub['plan_name'],
        'status'                    => $activeSub['status'],
        'reference_code'            => $activeSub['reference_code'],
        'amount_paid'               => (float) $activeSub['amount_paid'],
        'amount_formatted'          => format_price($activeSub['amount_paid']),
        'payment_mode'              => $activeSub['payment_mode'],
        'start_date'                => $activeSub['start_date'],
        'start_date_formatted'      => format_datetime($activeSub['start_date']),
        'expiration_date'           => $activeSub['expiration_date'],
        'expiration_date_formatted' => format_datetime($activeSub['expiration_date']),
    ];
}

$history = [];
foreach ($historyRaw as $h) {
    $history[] = [
        'subscription_id'           => (int) $h['subscription_id'],
        'plan_id'                   => (int) $h['plan_id'],
        'plan_name'                 => $h['plan_name'],
        'reference_code'            => $h['reference_code'],
        'status'                    => $h['status'],
        'amount_paid'               => (float) $h['amount_paid'],
        'amount_formatted'          => format_price($h['amount_paid']),
        'payment_mode'              => $h['payment_mode'],
        'start_date'                => $h['start_date'],
        'start_date_formatted'      => format_date($h['start_date']),
        'expiration_date'           => $h['expiration_date'],
        'expiration_date_formatted' => format_date($h['expiration_date']),
    ];
}

json_out([
    'success' => true,
    'data'    => [
        'student' => [
            'student_id'          => $studentId,
            'student_number'      => $student['student_number'],
            'full_name'           => $student['full_name'],
            'email'               => $student['email'],
            'user_type'           => $student['user_type'],
            'user_type_label'     => user_type_label($student['user_type']),
            'program_id'          => isset($student['program_id']) ? (int) $student['program_id'] : null,
            'program_name'        => $student['program_name'] ?? 'Bachelor of Science in Information Technology',
            'status'              => $student['status'],
            'verification_status' => $student['verification_status'] ?? 'verified',
            'graduation_year'     => $student['graduation_year'] !== null ? (int) $student['graduation_year'] : null,
            'created_at'          => $student['created_at'],
            'created_at_formatted'=> format_date($student['created_at']),
        ],
        'has_full_access'     => $activeSub !== null,
        'active_subscription' => $activeSubPayload,
        'subscriptions'       => $history,
    ],
]);
