<?php
/**
 * Home dashboard endpoint for the Study Vault mobile application.
 * Returns authenticated user summary, subscription status, real repository counts,
 * research categories with counts, and recently added approved research.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

$student    = api_require_student();
$studentId  = (int) $student['student_id'];
$activeSub  = get_active_subscription($pdo, $studentId);
$allSubs    = get_student_subscriptions($pdo, $studentId);
$latestSub  = $allSubs[0] ?? null;
$fullAccess = $activeSub !== null;

$totalApproved = (int) $pdo->query("SELECT COUNT(*) FROM research WHERE status = 'approved'")->fetchColumn();

$catRows = $pdo->query("
    SELECT c.category_id, c.category_name, c.description, COUNT(r.research_id) AS total
      FROM categories c
      LEFT JOIN research r ON r.category_id = c.category_id AND r.status = 'approved'
     GROUP BY c.category_id, c.category_name, c.description
     ORDER BY c.category_id
")->fetchAll();

$categories = [];
foreach ($catRows as $c) {
    $categories[] = [
        'category_id'   => (int) $c['category_id'],
        'category_name' => $c['category_name'],
        'description'   => $c['description'],
        'total'         => (int) $c['total'],
    ];
}

$recentStmt = $pdo->query("
    SELECT r.research_id, r.title, r.abstract, r.year, r.published_date, r.keywords,
           r.file_path, c.category_id, c.category_name, p.program_name,
           (SELECT GROUP_CONCAT(a.full_name ORDER BY a.full_name SEPARATOR ', ')
              FROM research_authors ra JOIN authors a ON a.author_id = ra.author_id
             WHERE ra.research_id = r.research_id) AS researchers
      FROM research r
      JOIN categories c ON c.category_id = r.category_id
      LEFT JOIN programs p ON p.program_id = r.program_id
     WHERE r.status = 'approved'
     ORDER BY r.published_date DESC, r.research_id DESC
     LIMIT 6
");

$recent = [];
foreach ($recentStmt->fetchAll() as $row) {
    $has = research_file_exists($row['file_path']);
    $recent[] = [
        'research_id'              => (int) $row['research_id'],
        'title'                    => $row['title'],
        'abstract'                 => $row['abstract'],
        'excerpt'                  => excerpt($row['abstract'], 180),
        'year'                     => (int) $row['year'],
        'published_date'           => $row['published_date'],
        'published_date_formatted' => format_date($row['published_date']),
        'keywords'                 => $row['keywords'],
        'category_id'              => (int) $row['category_id'],
        'category_name'            => $row['category_name'],
        'program_name'             => $row['program_name'] ?? 'Bachelor of Science in Information Technology',
        'researchers'              => $row['researchers'],
        'has_manuscript'           => $has,
        'can_view_manuscript'      => $has && $fullAccess,
        'manuscript_url'           => ($has && $fullAccess) ? manuscript_viewer_url((int) $row['research_id']) : null,
    ];
}

$subPayload = null;
if ($activeSub) {
    $subPayload = [
        'subscription_id'           => (int) $activeSub['subscription_id'],
        'plan_id'                   => (int) $activeSub['plan_id'],
        'plan_name'                 => $activeSub['plan_name'],
        'status'                    => $activeSub['status'],
        'reference_code'            => $activeSub['reference_code'],
        'start_date'                => $activeSub['start_date'],
        'start_date_formatted'      => format_datetime($activeSub['start_date']),
        'expiration_date'           => $activeSub['expiration_date'],
        'expiration_date_formatted' => format_datetime($activeSub['expiration_date']),
    ];
}

$latestExpiredPayload = null;
if (!$activeSub && $latestSub && $latestSub['status'] === 'expired') {
    $latestExpiredPayload = [
        'plan_name'                 => $latestSub['plan_name'],
        'status'                    => 'expired',
        'expiration_date'           => $latestSub['expiration_date'],
        'expiration_date_formatted' => format_date($latestSub['expiration_date']),
    ];
}

json_out([
    'success' => true,
    'data'    => [
        'student' => [
            'student_id'      => $studentId,
            'student_number'  => $student['student_number'],
            'full_name'       => $student['full_name'],
            'email'           => $student['email'],
            'user_type'       => $student['user_type'],
            'user_type_label' => user_type_label($student['user_type']),
            'program_name'    => $student['program_name'] ?? 'Bachelor of Science in Information Technology',
            'status'          => $student['status'],
        ],
        'has_full_access'     => $fullAccess,
        'active_subscription' => $subPayload,
        'expired_subscription'=> $latestExpiredPayload,
        'stats'               => [
            'total_approved_research' => $totalApproved,
            'total_categories'        => count($categories),
        ],
        'categories'          => $categories,
        'years'               => array_map('intval', get_research_years($pdo, true)),
        'recent_research'     => $recent,
    ],
]);
