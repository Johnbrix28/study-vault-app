<?php
require_once __DIR__ . '/../includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_out(['success' => false, 'message' => 'Use POST.'], 405);
}

$studentId = null;
$bearer = extract_bearer_token();
if ($bearer !== null) {
    $student = authenticate_mobile_token($pdo, $bearer);
    if ($student) {
        $studentId = (int) $student['student_id'];
    }
    revoke_mobile_token($pdo, $bearer);
}

if ($studentId === null && is_student_logged_in()) {
    $studentId = (int) $_SESSION['student_id'];
}

if ($studentId !== null) {
    log_student_activity($pdo, $studentId, 'Student signed out (API)');
}

logout_student();

json_out([
    'success' => true,
    'message' => 'Signed out successfully.',
]);
