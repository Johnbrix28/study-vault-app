<?php
require_once __DIR__ . '/../includes/bootstrap.php';

api_require_student();

$catRows = $pdo->query("
    SELECT c.category_id, c.category_name, c.description, COUNT(r.research_id) AS total
      FROM categories c
      LEFT JOIN research r ON r.category_id = c.category_id AND r.status = 'approved'
     GROUP BY c.category_id, c.category_name, c.description
     ORDER BY c.category_id
")->fetchAll();

$categories = [];
foreach ($catRows as $c) {
    $categories[] = [
        'category_id'   => (int) $c['category_id'],
        'category_name' => $c['category_name'],
        'description'   => $c['description'],
        'total'         => (int) $c['total'],
    ];
}

json_out([
    'success' => true,
    'data'    => [
        'categories' => $categories,
        'years'      => array_map('intval', get_research_years($pdo, true)),
    ],
]);
